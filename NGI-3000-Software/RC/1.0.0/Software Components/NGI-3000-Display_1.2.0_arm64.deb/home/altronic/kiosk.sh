#!/bin/bash
# X should already be up by the time this runs (ordered After=display.service), but
# wait defensively in case the unit is started on its own.
export DISPLAY=:0
while ! xset q &>/dev/null; do
  sleep 1
done

while :
do
  chromium-browser --kiosk --force-device-scale-factor=1 --compact_on_every_full_gc=true --gc_global=true --predictable_gc_schedule=true --user-data-dir="/tmp/profile2" --window-position=0,0 http://169.254.254.2/awi/top.html &
  chromium-browser --kiosk --force-device-scale-factor=1 --compact_on_every_full_gc=true --gc_global=true --predictable_gc_schedule=true --user-data-dir="/tmp/profile1" --window-position=0,480  http://169.254.254.2/awi/bottom.html &
  sleep 43200
  sudo killall chromium-browser
done
