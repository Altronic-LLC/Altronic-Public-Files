#!/bin/bash
# Turn on the second display after it was disabled in cmdline.txt to prevent
# flipped/corrupted startup messages.

# Wait for the X server to be ready before touching xrandr.
export DISPLAY=:0
while ! xset q &>/dev/null; do
  sleep 1
done

# Enable HDMI-A-2. Try both cards - the wildcard didn't work so one of these
# is guaranteed to be the right device.
sudo sh -c 'echo on > /sys/class/drm/card0-HDMI-A-1/status'
sudo sh -c 'echo on > /sys/class/drm/card1-HDMI-A-1/status'

# Force correct mode and orientation on the now-enabled output.
xrandr --output HDMI-1 --auto --rotate inverted #--primary 
