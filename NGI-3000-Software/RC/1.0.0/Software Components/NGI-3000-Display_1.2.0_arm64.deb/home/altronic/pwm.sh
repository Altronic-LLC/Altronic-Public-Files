#!/bin/bash
# Configure pwm inputs to the displays to reduce heat/brightness.
# Runs as root, so no sudo is needed. Exports are guarded so a re-run
# (e.g. a manual restart) doesn't abort on an already-exported channel.

[ -d /sys/class/pwm/pwmchip0/pwm0 ] || echo 0 > /sys/class/pwm/pwmchip0/export
[ -d /sys/class/pwm/pwmchip0/pwm1 ] || echo 1 > /sys/class/pwm/pwmchip0/export

DUTY_CYCLE=$(cat /home/altronic/duty_cycle 2>/dev/null || echo 350000)

echo 500000 > /sys/class/pwm/pwmchip0/pwm0/period
echo 500000 > /sys/class/pwm/pwmchip0/pwm1/period
echo 1 > /sys/class/pwm/pwmchip0/pwm0/enable
echo 1 > /sys/class/pwm/pwmchip0/pwm1/enable
echo $DUTY_CYCLE > /sys/class/pwm/pwmchip0/pwm0/duty_cycle
echo $DUTY_CYCLE > /sys/class/pwm/pwmchip0/pwm1/duty_cycle
