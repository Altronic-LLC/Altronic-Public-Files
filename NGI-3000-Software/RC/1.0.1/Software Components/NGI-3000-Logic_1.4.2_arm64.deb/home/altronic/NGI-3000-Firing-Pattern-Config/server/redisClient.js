// ── Redis client for MDI-Gateway's live config store ─────────────────────
// MDI-Gateway keeps its live config in Redis (the `mdi-settings` hash and the
// per-device `mdi-device-<id>` hashes). The gateway itself talks to Redis on
// localhost:6379. We use the official `redis` (node-redis) client and expose a
// few thin helpers so the rest of the server stays decoupled from the client
// API. A single lazily-connected client is shared across calls; node-redis
// handles reconnection on its own.
const { createClient } = require('redis');

const REDIS_HOST = process.env.REDIS_HOST || '127.0.0.1';
const REDIS_PORT = Number(process.env.REDIS_PORT || 6379);
const REDIS_TIMEOUT_MS = Number(process.env.REDIS_TIMEOUT_MS || 3000);

let client = null;
let connectPromise = null;

// Lazily create and connect a shared client. If a connection attempt fails the
// cached state is cleared so the next call retries with a fresh client.
async function getClient() {
  if (client && client.isOpen) return client;
  if (!connectPromise) {
    client = createClient({
      socket: {
        host: REDIS_HOST,
        port: REDIS_PORT,
        connectTimeout: REDIS_TIMEOUT_MS,
        // Back off on reconnect; cap the delay so we keep retrying quietly.
        reconnectStrategy: retries => Math.min(retries * 200, 2000),
      },
    });
    // node-redis emits 'error' on connection trouble; swallow-and-log so an
    // unhandled event never crashes the config server.
    client.on('error', err => console.error('Redis client error:', err.message));
    connectPromise = client.connect();
  }
  try {
    await connectPromise;
  } catch (err) {
    connectPromise = null;
    client = null;
    throw err;
  }
  return client;
}

// Return all fields of a hash as a plain object (empty object if absent).
async function redisHGetAll(key) {
  const c = await getClient();
  return c.hGetAll(key);
}

// Return a single hash field, or null when the field/key is absent.
async function redisHGet(key, field) {
  const c = await getClient();
  const v = await c.hGet(key, field);
  return v === undefined ? null : v;
}

// Set one or more hash fields from an object; values are coerced to strings.
async function redisHSet(key, fields) {
  const c = await getClient();
  const flat = {};
  for (const [k, v] of Object.entries(fields)) flat[k] = String(v);
  return c.hSet(key, flat);
}

// Return the full contents of a list (empty array if absent).
async function redisLRange(key) {
  const c = await getClient();
  const r = await c.lRange(key, 0, -1);
  return Array.isArray(r) ? r : [];
}

// Publish a message to a pub/sub channel.
async function redisPublish(channel, message) {
  const c = await getClient();
  return c.publish(channel, message);
}

// Escape hatch for arbitrary commands, e.g. redisCommand('FLUSHALL').
async function redisCommand(...args) {
  const c = await getClient();
  return c.sendCommand(args.map(String));
}

// Close the shared connection (mainly for graceful shutdown / tests).
async function redisQuit() {
  if (client && client.isOpen) await client.quit();
  client = null;
  connectPromise = null;
}

module.exports = {
  redisHGetAll,
  redisHGet,
  redisHSet,
  redisLRange,
  redisPublish,
  redisCommand,
  redisQuit,
  REDIS_HOST,
  REDIS_PORT,
  REDIS_TIMEOUT_MS,
};
