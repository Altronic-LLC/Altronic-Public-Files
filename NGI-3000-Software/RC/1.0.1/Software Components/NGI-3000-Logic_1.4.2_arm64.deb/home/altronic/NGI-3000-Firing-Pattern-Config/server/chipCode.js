// Keep in sync with client/src/chipCode.js (the server ships separately from the client)
const FEATURE_WEIGHTS = {
  timing: { misc: 1, rpm: 16 },
  energy: { misc: 2, rpm: 32 },
  fire: { misc: 4, rpm: 64 },
};

function specialFeaturesCode({ timingValue, energyValue, fireValue }) {
  const selections = { timing: timingValue, energy: energyValue, fire: fireValue };
  let sum = 0;
  for (const [feature, weights] of Object.entries(FEATURE_WEIGHTS)) {
    const index = selections[feature]?.index;
    if (index === 3) sum += weights.misc;
    else if (index === 2) sum += weights.rpm;
  }
  return sum;
}

function buildChipCode({ firingPattern, gearTeeth, currentMapCode, ...features }) {
  const special = String(specialFeaturesCode(features)).padStart(3, '0');
  return `${firingPattern?.code ?? ''}${gearTeeth ?? ''}.F${currentMapCode ?? ''}#${special}`;
}

// Chip code from a saved config.json, or null if it has no CPU firing pattern settings
function chipCodeFromConfig(config) {
  const pickup = config?.pickupConfig?.[config?.selectedPickupName];
  if (config?.selectedPickupName !== 'cpu_firing_pattern' || !pickup?.firingPattern?.code) {
    return null;
  }
  return buildChipCode({
    firingPattern: pickup.firingPattern,
    gearTeeth: pickup.gearTeeth,
    currentMapCode: config.selectedCurrentLoopConfigOption?.code,
    timingValue: config.advanced?.timingValue,
    energyValue: config.advanced?.energyValue,
    fireValue: config.advanced?.fireValue,
  });
}

module.exports = { buildChipCode, chipCodeFromConfig };
