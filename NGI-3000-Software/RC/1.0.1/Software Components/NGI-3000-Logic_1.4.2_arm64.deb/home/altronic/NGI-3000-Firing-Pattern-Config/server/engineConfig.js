// ── Config -> engine register upload ──────────────────────────────────────
// Ports the register-building logic that used to live in the separate
// engine_config_go repo (main.go), which was launched by monitor.sh watching
// /home/altronic/config.json for changes via inotifywait. That indirection is
// gone: server.js now calls sendConfigToEngine() directly once it has written
// config.json, so the config is pushed to the engine within the same request.
//
// IMPORTANT: reqValues/coilValues below must stay in the exact call order used
// by the original script. There is no sorting by register number before the
// values are sent — the Modbus write assumes coredata.json assigns registers
// to these keys in the same ascending sequence this function calls them in.
// Reordering these calls will silently write values to the wrong registers.
const fs = require('fs');

const GATEWAY_FUNCTION_CODES = {
  writeMultipleCoils: 15, // 0x0F
  writeMultipleRegisters: 16, // 0x10
};

const GATEWAY_REQUEST_TIMEOUT_MS = 5000;

function boolToInt(value) {
  return value ? 1 : 0;
}

// Mirrors Go's strconv.Atoi: the whole string must be a valid base-10
// integer, unlike parseInt which happily parses a numeric prefix.
function strictAtoi(value) {
  if (typeof value !== 'string' || !/^-?\d+$/.test(value)) return NaN;
  return parseInt(value, 10);
}

function loadCoredata(coredataPath) {
  const raw = fs.readFileSync(coredataPath, 'utf8');
  const parsed = JSON.parse(raw);

  // unified: register index -> record (block/register/key/factor/offset/...)
  // stringDict: register key (e.g. "cNumCyl") -> index, for buildRequest lookups
  const unified = {};
  const stringDict = {};
  for (const record of Object.values(parsed)) {
    unified[record.index] = record;
    stringDict[record.key] = record.index;
  }
  return { unified, stringDict };
}

async function gatewayGet(url) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), GATEWAY_REQUEST_TIMEOUT_MS);
  try {
    const res = await fetch(url, { signal: controller.signal });
    if (!res.ok) {
      const body = await res.text().catch(() => '');
      throw new Error(`HTTP ${res.status} from ${url}: ${body.slice(0, 200)}`);
    }
    return res;
  } finally {
    clearTimeout(timer);
  }
}

// Sends `config` (the same object saved to config.json) to the engine as a
// sequence of Modbus register/coil writes via the local MDI-Gateway, finishing
// with a checksum + "config complete" write that tells the ST to commit
// everything it received. Throws if coredata.json can't be read/parsed or if
// any gateway write fails.
async function sendConfigToEngine(config, options = {}) {
  const coredataPath =
    options.coredataPath || process.env.COREDATA_PATH || '/home/altronic/coredata.json';
  const gatewayHost = options.gatewayHost || process.env.GATEWAY_HOST || '127.0.0.1';
  const gatewayPort = options.gatewayPort || Number(process.env.GATEWAY_PORT || 8080);
  const gatewayBase = `http://${gatewayHost}:${gatewayPort}`;

  const { unified, stringDict } = loadCoredata(coredataPath);

  // Holding-register batch state
  let reqValues = [];
  let minReg = 65535;
  let minIndex = 65535;
  let maxReg = 0;
  let regCnt = 0;
  // Coil batch state (coredata block "00000")
  let coilValues = [];
  let minRegCoil = 65535;
  let regCntCoil = 0;
  // Running checksum across the whole send (not reset between batches)
  let checksum = 0;

  function buildRequestRaw(key, val) {
    const idx = stringDict[key];
    if (idx === undefined) {
      console.warn('Unknown key:', key);
      return;
    }
    const reg = unified[idx];
    const val16 = val & 0xffff; // uint16 truncation, incl. sentinel -1 -> 65535
    checksum = (checksum + (val16 >> 8) + (val16 & 0xff)) & 0xffff;

    if (reg.block === '00000') {
      if (reg.register < minRegCoil) minRegCoil = reg.register;
      regCntCoil += 1;
      coilValues.push(val16);
    } else {
      if (reg.register < minReg) minReg = reg.register;
      if (idx < minIndex) minIndex = idx;
      if (reg.register > maxReg) maxReg = reg.register;
      regCnt += 1;
      reqValues.push(val16);
    }
  }

  // Converts an engineering-units value (what a human enters / what a display
  // shows) to the raw register value: raw = (engineeringValue - offset) / factor.
  function buildRequest(key, engineeringValue) {
    const idx = stringDict[key];
    if (idx === undefined) {
      console.warn('Unknown key:', key);
      return;
    }
    const reg = unified[idx];
    const factor = reg.factor || 1; // guard divide-by-zero on bad/missing entries
    const offset = reg.offset ?? 0;
    const raw = Math.round((engineeringValue - offset) / factor);
    buildRequestRaw(key, raw);
  }

  function resetBatch() {
    reqValues = [];
    minReg = 65535;
    minIndex = 65535;
    maxReg = 0;
    regCnt = 0;
    coilValues = [];
    minRegCoil = 65535;
    regCntCoil = 0;
  }

  async function flushBatch() {
    const url = `${gatewayBase}/fc/1/${GATEWAY_FUNCTION_CODES.writeMultipleRegisters}/${
      minReg - 1
    }/${regCnt}/${reqValues.join(',')}`;
    console.log('[config] Register batch sent:', url);
    await gatewayGet(url);
    if (regCntCoil > 0) {
      const coilURL = `${gatewayBase}/fc/1/${GATEWAY_FUNCTION_CODES.writeMultipleCoils}/${
        minRegCoil - 1
      }/${regCntCoil}/${coilValues.join(',')}`;
      await gatewayGet(coilURL);
    }
  }

  const selectedPickupConfig =
    { cpu_firing_pattern: 0, event_triggered: 1, gear_calculated: 2 }[config.selectedPickupName] ??
    -1;

  // Cylinders/type/coils-per-cylinder/gear-teeth/fire-enum come from gear_calculated
  // when that pickup is selected, and from cpu_firing_pattern otherwise (including
  // when event_triggered is selected) -- matches the original script exactly.
  const primaryPickupKey = selectedPickupConfig === 2 ? 'gear_calculated' : 'cpu_firing_pattern';
  const firingPattern = config.pickupConfig?.[primaryPickupKey]?.firingPattern ?? {};

  // --- Batch 1: firing pattern, gear/output config, angle table, current/RPM maps ---
  buildRequest('cNumCyl', firingPattern.cylinders ?? 0);
  buildRequest('cType', firingPattern.engineType ?? 0);
  buildRequest('cCoilPerCyl', firingPattern.coilsPerCylinder ?? 0);
  buildRequest('cMaxRpm', config.maxRPM ?? 0);
  buildRequest('cFp2cyl', boolToInt(!!firingPattern.twoCylinders));

  buildRequest('cFp2ndCylOfst', config.advanced?.cutOffValue?.index ?? 0);
  buildRequest('cGearTeeth', config.pickupConfig?.[primaryPickupKey]?.gearTeeth ?? 0);
  buildRequest('cOutputMod', config.filters?.output_module ?? 0);
  buildRequest('cCoilPerOutp', config.filters?.coilsPerOutput ?? 0);

  for (let lp = 0; lp < 20; lp++) {
    const angle = config.firingPatternData?.fire_a?.[lp]?.angle;
    if (angle === null || angle === undefined) {
      // -1 is a wire-level sentinel meaning "no angle set", sent as-is
      buildRequestRaw(`cFireA${lp}`, -1);
    } else {
      buildRequest(`cFireA${lp}`, Number(angle));
    }
  }

  // Fire B is no longer used, but is still expected in the register map.
  for (let lp = 0; lp < 20; lp++) buildRequestRaw(`cFireB${lp}`, -1);

  for (let lp = 0; lp <= 14; lp++) {
    const entry = config.currentMapData?.[lp] ?? {};
    buildRequest(`cCurMap${lp}c`, entry.current ?? 0);
    buildRequest(`cCurMap${lp}r`, entry.retard ?? 0);
  }
  for (let lp = 0; lp <= 14; lp++) {
    const entry = config.RPMMapData?.[lp] ?? {};
    buildRequest(`cRpmMap${lp}s`, entry.rpm ?? 0);
    buildRequest(`cRpmMap${lp}r`, entry.retard ?? 0);
  }

  buildRequest('cAtv', config.advanced?.timingValue?.index ?? 0);
  buildRequest('cAev', config.advanced?.energyValue?.index ?? 0);
  buildRequest('cAfv', config.advanced?.fireValue?.index ?? 0);
  buildRequest('cTmPermit', boolToInt(!!config.advanced?.permitTestMode));
  buildRequest('cFireEnum', firingPattern.enum ?? 0);

  const outputCode = config.selectedOutputModule?.code || '';
  buildRequest('cOutMod', outputCode.length > 0 ? outputCode.charCodeAt(0) : 0);

  await flushBatch();
  resetBatch();

  // --- Batch 2: pickup type, gear/event-triggered specifics, coil kV map ---
  buildRequest('cPType', selectedPickupConfig);
  buildRequest('cGearTeethMinus', config.pickupConfig?.gear_calculated?.resetTeethCount ?? 0);
  buildRequest(
    'cMissingTeethMode',
    config.pickupConfig?.gear_calculated?.resetTeethType === 'missing' ? 1 : 0
  );

  const eventTriggered = config.pickupConfig?.event_triggered ?? {};
  const nPlusOne = strictAtoi(eventTriggered.discType);
  buildRequest('cNPlusOne', nPlusOne >= 2 && nPlusOne <= 12 ? nPlusOne : 0);
  buildRequest('cLineupAngle', eventTriggered.lineUpAngle ?? 0);
  buildRequest('cInsertionRet', eventTriggered.insertionRetard ?? 0);
  buildRequest('cPurgeDelay', eventTriggered.purgeDelay ?? 0);
  buildRequest('cSlaveAngle', eventTriggered.slaveFiringAngle ?? 0);
  buildRequest('cDiskCrank', boolToInt(!!eventTriggered.discLocationOnCrank));
  buildRequest('cTestDisk', boolToInt(!!eventTriggered.checkDiscType));
  buildRequest('cSlaveFiring', boolToInt(!!eventTriggered.slaveFiringEnable));
  buildRequest('cPickupType', boolToInt(!!eventTriggered.pickupTypeHallEffect));

  for (let lp = 0; lp < 10; lp++) {
    buildRequest(`cKVC${lp + 1}`, config.coilKvCountMap?.[lp] ?? 0);
  }
  for (let lp = 0; lp < 10; lp++) {
    buildRequest(`cKV${lp + 1}`, config.coilKvMap?.[lp] ?? 0);
  }

  await flushBatch();

  // Final checksum + "config complete" write. chkSum is the 8-bit two's
  // complement of the running checksum's low byte (equivalent to the original
  // ^(low byte)+1 bit-twiddling, just written as arithmetic).
  checksum =
    (checksum + (minIndex >> 8) + (minIndex & 0xff) + (regCnt >> 8) + (regCnt & 0xff)) & 0xffff;
  const chkSum = (0x100 - (checksum & 0xff)) % 0x100;
  const completeURL = `${gatewayBase}/fc/1/16/${maxReg}/2/${chkSum},12345`;
  await gatewayGet(completeURL);

  return { checksum: chkSum, registersWritten: regCnt, coilsWritten: regCntCoil };
}

module.exports = { sendConfigToEngine };
