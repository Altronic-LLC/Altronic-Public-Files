const fs = require('fs');
const fsPromises = require('fs/promises');
const http = require('http');
const crypto = require('crypto');
const path = require('path');
const multer = require('multer');
const express = require('express');
const app = express();
const { execSync, exec, execFileSync } = require('child_process');
const ipaddr = require('ipaddr.js');
const Transform = require('stream').Transform;
const { NodeSSH } = require('node-ssh');
const Mutex = require('async-mutex').Mutex;
const net = require('net');

const httpServer = http.createServer(app);

const PORT = process.env.PORT || 80;

// Fixed eth1 link-local IPs — these are hardwired and never change.
// All inter-module SSH and forwarding uses these rather than the user-configurable eth0 IPs.
const DISPLAY_ETH1_IP = '169.254.254.3';
const LOGIC_ETH1_IP = '169.254.254.2';
const SSH_ARGS_BASE = [
  '-i',
  '/home/altronic/.ssh/id_rsa',
  '-o',
  'BatchMode=yes',
  '-o',
  'ConnectTimeout=10',
  `altronic@${DISPLAY_ETH1_IP}`,
];

const IRIS_FORCE_WRITE_PORT = '1479';
const IRIS_BRIDGE_NODE_ID = Number(process.env.IRIS_BRIDGE_NODE_ID || 1);

// iris_go_3000's IP-address registers: four consecutive octet registers per
// address, block 30000 (FC 4) per coredata.json. These are Logic-owned input
// registers — read-only to a real Modbus client — written locally over the
// fc4p bridge below.
const IRIS_IP_REGISTERS = {
  LLIPADDR: 216, // Logic's own eth0 IP
  LDIPADDR: 220, // Display proxy alias on Logic's eth0
  DDIPADDR: 224, // Display's own eth0 IP
  DLIPADDR: 228, // Logic proxy alias on Display's eth0
};

async function isDisplayReachable(timeoutMs = 2000) {
  return new Promise(resolve => {
    const socket = new net.Socket();

    const onDone = result => {
      socket.destroy();
      resolve(result);
    };

    socket.setTimeout(timeoutMs);
    socket.once('connect', () => onDone(true));
    socket.once('timeout', () => onDone(false));
    socket.once('error', () => onDone(false));

    socket.connect(22, DISPLAY_ETH1_IP);
  });
}

// Redis client for MDI-Gateway's live config store (see server/redisClient.js).
const { redisHGetAll, redisHGet, redisHSet, redisLRange, redisPublish } = require('./redisClient');

// Sends a saved config to the engine over the gateway's Modbus HTTP API (see
// server/engineConfig.js). Replaces the old inotifywait + engine_config_go flow.
const { sendConfigToEngine } = require('./engineConfig');
const { chipCodeFromConfig } = require('./chipCode');

// The RS-485 slave port is bound to a single fixed device in this application.
// The gateway's RTU slave server answers for whatever proxy node IDs exist in
// its device map, so the "slave ID" is really this device's deviceProxyNodeId.
// The device is always named the same, so we locate it by name.
const RS485_DEVICE_NAME = process.env.RS485_DEVICE_NAME || 'NGI-3000';

const GATEWAY_HOST = process.env.GATEWAY_HOST || '127.0.0.1';
const GATEWAY_PORT = Number(process.env.GATEWAY_PORT || 8080);
const RS485_NODE_ID_REGISTER = 235; // 40235
const RS485_BAUD_REGISTER = 236; // 40236

const RS485_BAUD_REGISTER_VALUES = {
  9600: 0,
  19200: 1,
  38400: 2,
  57600: 3,
  115200: 4,
};

const GATEWAY_WAIT_TIMEOUT_MS = Number(process.env.GATEWAY_WAIT_TIMEOUT_MS || 20000);
const GATEWAY_WAIT_INTERVAL_MS = Number(process.env.GATEWAY_WAIT_INTERVAL_MS || 1000);

// Poll the gateway's HTTP API until it responds.
async function waitForGatewayOnline({
  timeoutMs = GATEWAY_WAIT_TIMEOUT_MS,
  intervalMs = GATEWAY_WAIT_INTERVAL_MS,
} = {}) {
  const deadline = Date.now() + timeoutMs;
  do {
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 2000);
      const res = await fetch(`http://${GATEWAY_HOST}:${GATEWAY_PORT}/baud`, {
        signal: controller.signal,
      });
      clearTimeout(timer);
      if (res.ok) return true;
    } catch {
      // Not up yet (connection refused, reset, timed out) — keep polling.
    }
    await new Promise(r => setTimeout(r, intervalMs));
  } while (Date.now() < deadline);
  return false;
}

async function writeGatewayHoldingRegister(node, register, value) {
  const url = `http://${GATEWAY_HOST}:${GATEWAY_PORT}/fc/${node}/6/${register}/1/${value}`;
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 5000);
    const res = await fetch(url, { signal: controller.signal });
    clearTimeout(timer);
    if (!res.ok) {
      const body = await res.text().catch(() => '');
      throw new Error(`HTTP ${res.status}: ${body.slice(0, 200)}`);
    }
    return true;
  } catch (exception) {
    console.error(`Error writing register ${register} via ${url}:`, exception.message);
    return false;
  }
}

// Writes a dotted-quad IP into iris_go_3000's four consecutive octet
// registers over its fc4p bridge (localhost:1479), bypassing the Modbus
// gateway entirely — these are FC4 input registers, so a real Modbus client
// could never write them. Best-effort: a failure just leaves the register
// stale until iris_go_3000 next restarts and re-pulls /getComms itself.
async function writeIrisIPRegisters(register, ip) {
  const octets = (ip || '').split('.').map(Number);
  if (octets.length !== 4 || octets.some(o => !Number.isInteger(o) || o < 0 || o > 255)) {
    console.error(`Skipping iris register ${register}: "${ip}" is not a valid IPv4 address`);
    return false;
  }
  const url = `http://localhost:${IRIS_FORCE_WRITE_PORT}/fc/${IRIS_BRIDGE_NODE_ID}/4/${register}/4/${octets.join(',')}/`;
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 5000);
    const res = await fetch(url, { method: 'POST', signal: controller.signal });
    clearTimeout(timer);
    if (!res.ok) {
      const body = await res.text().catch(() => '');
      throw new Error(`HTTP ${res.status}: ${body.slice(0, 200)}`);
    }
    return true;
  } catch (exception) {
    console.error(`Error writing IP register ${register} via ${url}:`, exception.message);
    return false;
  }
}

// Pushes the current live IP settings into iris_go_3000's registers so a
// comms save takes effect immediately, instead of waiting for iris_go_3000's
// next restart to re-pull them from /getComms.
async function pushIPRegistersToIris(comms) {
  await writeIrisIPRegisters(IRIS_IP_REGISTERS.LLIPADDR, comms.Gbt_Eth_IP_Address);
  await writeIrisIPRegisters(IRIS_IP_REGISTERS.LDIPADDR, comms.Disp_Proxy_IP);
  await writeIrisIPRegisters(IRIS_IP_REGISTERS.DDIPADDR, comms.Disp_Eth_IP_Address);
  await writeIrisIPRegisters(IRIS_IP_REGISTERS.DLIPADDR, comms.Logic_Proxy_IP);
}

// After an RS485 save, the gateway restarts to pick up the new serial
// config (see saveRs485ToRedis). Once it's back online, mirror the new
// slave node id and baud rate into holding registers.
async function syncRs485RegistersToGateway(node, baud) {
  const online = await waitForGatewayOnline();
  if (!online) {
    console.warn(
      'MDI-Gateway did not come back online in time; RS485 holding registers 40236/40237 were not updated.'
    );
    return;
  }

  await writeGatewayHoldingRegister(node, RS485_NODE_ID_REGISTER, node);

  const baudValue = RS485_BAUD_REGISTER_VALUES[Number(baud)];
  if (baudValue === undefined) {
    console.warn(`Unrecognized RS485 baud rate "${baud}"; register 40237 was not updated.`);
    return;
  }
  await writeGatewayHoldingRegister(node, RS485_BAUD_REGISTER, baudValue);
}

const CYLINDER_LABEL_REGISTER_START = 215;
const MAX_CYLINDER_LABEL_REGISTERS = 20;
const CYLINDER_LABEL_NODE = 1;

function packTwoCharLabel(label) {
  const text = String(label || '')
    .padEnd(2, ' ')
    .slice(0, 2);
  return (text.charCodeAt(0) << 8) | text.charCodeAt(1);
}

// Best-effort: logs and continues past individual register failures rather
// than failing the whole config send over a backwards-compatibility feature.
async function writeCylinderLabelRegisters(config) {
  const cylinders = config?.firingPatternData?.fire_a || [];
  for (let lp = 0; lp < MAX_CYLINDER_LABEL_REGISTERS; lp++) {
    const value = packTwoCharLabel(cylinders[lp]?.label);
    const register = CYLINDER_LABEL_REGISTER_START + lp;
    await writeGatewayHoldingRegister(CYLINDER_LABEL_NODE, register, value);
  }
}

// Locate the fixed RS-485 device's hash key by walking the device list and
// matching on deviceName. Returns the device id (e.g. "kfx639") or null.
async function findRs485DeviceId() {
  const ids = await redisLRange('mdi-devices-list');
  for (const id of ids) {
    const name = await redisHGet(`mdi-device-${id}`, 'deviceName');
    if (name === RS485_DEVICE_NAME) return id;
  }
  return null;
}

// Read the RS-485 slave node id (the device's proxy node id) from Redis.
// Falls back to the slave unit id, then to "1", and never throws.
async function readRs485SlaveNodeID() {
  try {
    const devId = await findRs485DeviceId();
    if (!devId) return '1';
    const dev = await redisHGetAll(`mdi-device-${devId}`);
    return String(dev.deviceProxyNodeId || dev.deviceSlaveUnitId || '1');
  } catch (exception) {
    console.error('Error reading RS485 slave node id from Redis:', exception.message);
    return '1';
  }
}

// Fields the gateway's settings handler decodes as JSON booleans rather than
// strings. When we echo the current `mdi-settings` back on the update publish,
// these must be real booleans or the gateway's network-change comparison will
// see a spurious diff and needlessly re-run networkConfig.sh.
const MDI_SETTINGS_BOOL_FIELDS = new Set([
  'eth1BridgeEnabled',
  'eth2BridgeEnabled',
  'ethgbitBridgeEnabled',
  'datalogFifoEnabled',
  'CM4Statistics',
]);

// Convert a raw `mdi-settings` string map into the typed payload the gateway's
// settings-updates handler expects (booleans typed, everything else string).
function buildSettingsPayload(hash) {
  const out = {};
  for (const [k, v] of Object.entries(hash)) {
    out[k] = MDI_SETTINGS_BOOL_FIELDS.has(k) ? v === 'true' : v;
  }
  return out;
}

// Persist the RS-485 settings coming from the Comms page.
//   1. Serial params -> `mdi-settings` (port 1 is always a slave here).
//   2. Slave ID       -> the fixed device's `mdi-device-<id>` hash
//                        (deviceProxyNodeId is what the RTU slave matches on).
//   3. Publish `settings-updates` echoing the full current settings so the
//      gateway restarts and re-reads both mdi-settings and the device hashes,
//      applying the change — without triggering a network reconfigure.
async function saveRs485ToRedis(message) {
  let baud = String(message.RS485_Baud || '9600');
  if (RS485_BAUD_REGISTER_VALUES[Number(baud)] === undefined) baud = '9600';
  // let parity = message.RS2485_Parity;
  // if (parity !== 'Even' && parity !== 'Odd') parity = 'None';
  // let dataBits = parseInt(message.RS485_DataBits, 10);
  // if (dataBits !== 7 && dataBits !== 8) dataBits = 8;
  // let stopBits = parseInt(message.RS485_StopBits, 10);
  // if (stopBits !== 1 && stopBits !== 2) stopBits = 1;
  let node = parseInt(message.RS485_Node, 10);
  if (!Number.isInteger(node) || node < 1 || node > 247) node = 1;

  await redisHSet('mdi-settings', {
    rs4851BaudRate: baud,
    // rs4851Parity: parity,
    // rs4851DataBits: String(dataBits),
    // rs4851StopBits: String(stopBits),
    rs4851Mode: 'slave',
  });

  const devId = await findRs485DeviceId();
  if (devId) {
    await redisHSet(`mdi-device-${devId}`, {
      deviceProxyNodeId: String(node),
      deviceSlaveUnitId: String(node),
    });
  } else {
    console.warn(
      `RS485 device "${RS485_DEVICE_NAME}" not found in mdi-devices-list; slave ID not updated.`
    );
  }

  const current = await redisHGetAll('mdi-settings');
  await redisPublish(
    'settings-updates',
    JSON.stringify({
      message: 'RS485 settings updated from NGI-3000 config',
      updatedSettings: buildSettingsPayload(current),
    })
  );

  // Best-effort: wait for the gateway to restart, then mirror the new node
  // id / baud into its holding registers. Never lets a failure here fail
  // the overall save — the settings are already durably in Redis above.
  try {
    await syncRs485RegistersToGateway(node, baud);
  } catch (exception) {
    console.error('Error syncing RS485 registers to gateway:', exception.message);
  }
}

app.use('/', express.static(path.join(__dirname, '../client/dist')));
app.use(express.json());

const UPLOADS_DIR = '/home/altronic/uploads'; // Directory to store uploaded files
const MAX_UPLOAD_FILES = 8; // Maximum number of uploaded files to keep
// Custom directories can be specified for test deployments
const AWI_DIR = process.env.ADIR || '/home/altronic/awi-screens/';
const TEMPLATE_DIR = process.env.TDIR || '/home/altronic/template-screens/';

// Mutex should be acquired before reading or modifying the template screens folder
// Mutex should be released after all operations relying on the view of the
//   template screens folder have completed
// Mutex is not needed when ONLY READING template screens folder or ONLY READING OR
//   MODIFYING AWI screens folder
const screensMutex = new Mutex();

let selectedOutputModule = '';

// Generate a unique filename for uploaded files
function generateUploadFilename(originalname) {
  const ext = path.extname(originalname || '').toLowerCase();
  const originalNameWithoutExt = path.basename(originalname || '', ext);

  const rand = crypto.randomBytes(8).toString('hex');
  const timestamp = Date.now();

  return `${originalNameWithoutExt}-${timestamp}-${rand}${ext}`;
}

// Ensure uploads directory exists
try {
  if (!fs.existsSync(UPLOADS_DIR)) {
    fs.mkdirSync(UPLOADS_DIR, { recursive: true });
    console.log(`Created uploads directory at ${UPLOADS_DIR}`);
  }
} catch (err) {
  console.error(`Error ensuring uploads directory exists: ${err}`);
}

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, UPLOADS_DIR);
  },
  filename: function (req, file, cb) {
    // Generate a unique file name. The original file name is still available as file.originalname
    cb(null, generateUploadFilename(file.originalname));
  },
});

const upload = multer({ storage: storage });

const awiStorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, AWI_DIR);
  },
  filename: function (req, file, cb) {
    // Use temporary name as to not break later collision detection
    cb(null, generateUploadFilename(req.params.fname));
  },
});

const awiUpload = multer({ storage: awiStorage });

async function pruneUploadsDir() {
  try {
    const entries = await fsPromises.readdir(UPLOADS_DIR, {
      withFileTypes: true,
    });

    const files = await Promise.all(
      entries
        .filter(file => file.isFile())
        .map(async file => {
          const filePath = path.join(UPLOADS_DIR, file.name);
          const stats = await fsPromises.stat(filePath);
          return { name: file.name, path: filePath, mtime: stats.mtime };
        })
    );

    // Sort files by modification time, newest first
    files.sort((a, b) => b.mtime - a.mtime);

    const filesToDelete = files.slice(MAX_UPLOAD_FILES);
    for (const file of filesToDelete) {
      console.log(`Deleting old upload file: ${file.name}`);
      await fsPromises.unlink(file.path);
    }
  } catch (err) {
    console.error('Error pruning uploads directory:', err);
  }
}

const withPrune = handler => async (req, res) => {
  try {
    await handler(req, res);
  } finally {
    // Prune uploads directory after handling the request
    pruneUploadsDir();
  }
};

// Every 6 hours, prune the uploads directory as a safety measure in case the upload endpoints fail
setInterval(pruneUploadsDir, 6 * 60 * 60 * 1000);

function validateUploadedFilePath(uploadedFilePath, uploadsDir) {
  if (!uploadedFilePath || typeof uploadedFilePath !== 'string') {
    throw new Error('Invalid upload path');
  }

  // Resolve symlinks
  const absoluteUploadsDir = fs.realpathSync(uploadsDir);
  const absoluteUploadedFilePath = fs.realpathSync(uploadedFilePath);

  // Ensure the uploaded file path is within the uploads directory
  if (!absoluteUploadedFilePath.startsWith(absoluteUploadsDir + path.sep)) {
    throw new Error('Uploaded file path is outside of uploads directory');
  }

  // Check that the uploaded file is not a symlink
  const lstat = fs.lstatSync(uploadedFilePath);
  if (lstat.isSymbolicLink()) {
    throw new Error('Uploaded file is a symbolic link');
  }

  // Check that the uploaded file is a regular file and not empty
  const stat = fs.statSync(absoluteUploadedFilePath);
  if (!stat.isFile()) {
    throw new Error('Uploaded file is not a file');
  }
  if (stat.size <= 0) {
    throw new Error('Uploaded file is empty');
  }

  return absoluteUploadedFilePath;
}

function validateAndGetUploadedFilePath(file, expectedExtension) {
  if (!file) {
    const error = new Error('No update file selected');
    error.statusCode = 400;
    throw error;
  }

  const ext = path.extname(file.originalname || '').toLowerCase();
  if (ext !== expectedExtension) {
    const error = new Error(`Invalid file type. Please select a ${expectedExtension} file.`);
    error.statusCode = 400;
    throw error;
  }

  try {
    return validateUploadedFilePath(file.path, UPLOADS_DIR);
  } catch (e) {
    const error = new Error(`Uploaded file validation failed: ${e.message}`);
    error.statusCode = 400;
    throw error;
  }
}

// Wrapper function to use exec with Promises to maintain compatibility with node v12
// If compatibility is not needed, execAsync can be used directly
const execPromise = command => {
  return new Promise((resolve, reject) => {
    exec(command, (err, stdout, stderr) => {
      if (err) {
        reject(err); // Reject if there's an error
      } else {
        resolve(stdout || stderr); // Resolve with output
      }
    });
  });
};

// Save config file
app.post('/configLogicModule', async (req, res) => {
  console.log('Running /configLogicModule');

  const outputModule = req.body.selectedOutputModule
    ? req.body.selectedOutputModule.name
    : undefined;

  if (outputModule !== 'NGI3K') {
    console.log('Invalid output module:', outputModule);
    return res.status(500).json({
      status: 'error',
      message: 'Invalid output module',
      error: 'Output module must be NGI3K',
    });
  }

  // Set global output module variable
  selectedOutputModule = outputModule;

  // Save config file
  const configPath = '/home/altronic/config.json';
  try {
    await fsPromises.writeFile(configPath, JSON.stringify(req.body));
    console.log('Successfully wrote config file');
  } catch (err) {
    console.error('Error writing config file:', err);
    return res.status(500).json({
      status: 'error',
      message: 'Error writing config file',
      error: err,
    });
  }

  // Push the config to the engine over the gateway. This used to happen out-of-band:
  // monitor.sh watched config.json via inotifywait and ran the engine_config_go binary
  // when it changed. That indirection is gone — we send it directly from here instead.
  try {
    const engineResult = await sendConfigToEngine(req.body, {
      gatewayHost: GATEWAY_HOST,
      gatewayPort: GATEWAY_PORT,
    });
    console.log('Configuration sent to engine:', engineResult);
  } catch (err) {
    console.error('Error sending configuration to engine:', err);
    return res.status(500).json({
      status: 'error',
      message: 'Error sending configuration to the engine',
      error: err.message,
    });
  }

  try {
    await writeCylinderLabelRegisters(req.body);
  } catch (err) {
    console.error('Error writing cylinder label registers:', err);
  }

  // Prepare screen folder
  console.log('Preparing screens folder...');
  const release = await screensMutex.acquire();
  try {
    const folderName = req.body.selectedPickupName;

    if (fs.existsSync(AWI_DIR)) {
      // NOTE FOR NOTE: Below comment referred to the now un-commented line.
      //                 If something breaks, we should go back.
      // NOTE: this function is deprecated, but is necessary for compatibility with node v12.
      // This currently works on newer versions of node, but the recommended syntax is:
      fs.rmSync('/home/altronic/awi-screens', { recursive: true, force: true });
      // fs.rmdirSync(AWI_DIR, { recursive: true });
    }

    try {
      await fsPromises.mkdir(AWI_DIR, { recursive: true });
      console.log('Screens folder created successfully');
    } catch (err) {
      console.error('Error creating screens folder:', err);
      return res.status(500).json({
        status: 'error',
        message: 'Error creating screens folder',
        error: err,
      });
    }

    try {
      replaceAllLabels(folderName, req.body);
    } catch (replaceErr) {
      console.error('Error on replace and copy screens:', replaceErr);
      return res.status(500).json({
        status: 'error',
        message: 'Error on replace and copy screens',
        error: replaceErr,
      });
    }

    // Set ownership
    try {
      await fsPromises.chown(AWI_DIR, 1000, 1000);
      console.log('Ownership set successfully');
    } catch (err) {
      console.error('Error setting ownership:', err);
      return res.status(500).json({
        status: 'error',
        message: 'Error setting ownership',
        error: err,
      });
    }

    // Flush filesystem buffer
    try {
      await execPromise('sync');
    } catch (err) {
      console.error('Error flushing filesystem buffer:', err);
      return res.status(500).json({
        status: 'error',
        message: 'Error flushing filesystem buffer',
        error: err,
      });
    }
  } finally {
    release();
  }
  console.log('Logic Module configuration process completed successfully');
  // Sleep gives time for config to finish on ST
  await new Promise(r => setTimeout(r, 3000));
  res.json({ status: 'success', message: 'Config received' });
});

// Important: replaceAllLabels and replaceLabels do not need to acquire screensMutex
//   because they are used as helper functions in places where screensMutex is already
//   acquired. If either function is used elsewhere, you must first acquire screensMutex.
const replaceAllLabels = (folderName, config) => {
  const templateFolder = path.join(TEMPLATE_DIR, folderName);
  if (!fs.existsSync(templateFolder)) {
    console.error(`WARNING: Could not find ${folderName} directory.`);
    return;
  }
  const files = fs.readdirSync(templateFolder);
  if (!files) {
    console.error(`WARNING: No files present in ${folderName} directory.`);
    return;
  }
  files.forEach(fileName => replaceLabels(folderName, fileName, config));
};

const replaceLabels = (folderName, fileName, config) => {
  try {
    let text = fs.readFileSync(path.join(TEMPLATE_DIR, folderName, fileName), 'utf8');
    if (config && config.firingPatternData) {
      for (let i = 1; i <= config.firingPatternData.fire_a.length; i++) {
        const regex = new RegExp(`\\*C${i}\\*`, 'g');
        const angle = config.firingPatternData['fire_a'][i - 1].angle;
        const label = config.firingPatternData['fire_a'][i - 1].label;
        //Use != instead of !== in case angle is undefined
        if (label && angle != null) {
          text = text.replace(regex, label);
        }
      }
    }

    // Inside the screens' JSON strings, so the newline is the two characters \n
    const chipCode = chipCodeFromConfig(config);
    if (chipCode) {
      text = text.split('NGI-3000 IGNITION').join(`NGI-3000 IGNITION\\n${chipCode}`);
    }

    const baseName = path.basename(fileName, path.extname(fileName));
    fs.writeFileSync(`${AWI_DIR}${baseName}.html`, text);
    fs.chownSync(`${AWI_DIR}${baseName}.html`, 1000, 1000);
  } catch (e) {
    console.error('Error on replace template file labels, error:', e);
  }
};

const readConfigFile = () => {
  try {
    const data = fs.readFileSync('/home/altronic/config.json', { encoding: 'utf8' });
    try {
      const parsedData = JSON.parse(data);
      console.log('Successfully read config file: \n', parsedData);
      return parsedData;
    } catch (parseErr) {
      console.error('Error parsing config file JSON:', parseErr);
      return { status: 'error', message: 'Error parsing config file JSON' };
    }
  } catch (e) {
    console.log('Error reading config file', e);
    return { status: 'error', message: 'Error reading config file' };
  }
};

// The live AWI screens are built from a single template folder: the one named after the pickup
// type in the active config. Template edits are only mirrored into the live screens when they are
// made in that folder - edits elsewhere stay staged until a Send Config selects that folder.
const isLiveTemplateFolder = folder => {
  const config = readConfigFile();
  return config.status !== 'error' && config.selectedPickupName === folder;
};

// Send config file
app.get('/fetch', (req, res) => {
  console.log('Running /fetch');

  if (!fs.existsSync('/home/altronic/config.json')) {
    console.log('Error: file not found');
    return res.status(404).json({ status: 'error', message: 'Config file not found' });
  }

  const config = readConfigFile();
  if (config.status === 'error') {
    return res.status(500).json(config);
  } else {
    selectedOutputModule = config.selectedOutputModule?.name;
    return res.json(config);
  }
});

app.get('/configExists', (req, res) => {
  const configPath = '/home/altronic/config.json';
  res.json({ exists: fs.existsSync(configPath) });
});

// Coil types (built-in placeholders + any added) are persisted
// here so new coils survive a page reload, the same way comms and FPD settings do. The
// client falls back to its bundled CoilTypes.json defaults if this file doesn't exist yet.
const COIL_TYPES_PATH = '/home/altronic/coilTypes.json';

app.get('/getCoilTypes', (req, res) => {
  console.log('Running /getCoilTypes');

  if (!fs.existsSync(COIL_TYPES_PATH)) {
    return res.status(404).json({ status: 'error', message: 'Coil types file not found' });
  }

  try {
    const data = fs.readFileSync(COIL_TYPES_PATH, { encoding: 'utf8' });
    const parsedData = JSON.parse(data);
    console.log('Successfully read coil types file');
    return res.json(parsedData);
  } catch (err) {
    console.error('Error reading coil types file:', err);
    return res.status(500).json({ status: 'error', message: 'Error reading coil types file' });
  }
});

app.post('/saveCoilTypes', async (req, res) => {
  console.log('Running /saveCoilTypes');

  if (!Array.isArray(req.body)) {
    return res.status(400).json({ status: 'error', message: 'Expected an array of coil types' });
  }

  try {
    await fsPromises.writeFile(COIL_TYPES_PATH, JSON.stringify(req.body));
    console.log('Successfully wrote coil types file');
    return res.json({ status: 'success', message: 'Coil types saved' });
  } catch (err) {
    console.error('Error writing coil types file:', err);
    return res.status(500).json({
      status: 'error',
      message: 'Error writing coil types file',
      error: err.message,
    });
  }
});

// Writes the system clock to the DS3231 RTC (hwclock -w) and clears its OSF flag.
// The status register (0x0f) is claimed by the kernel driver, so i2c needs -f.
const RTC_PERSIST_SCRIPT = [
  'hwclock -w',
  'prev=$(i2cget -f -y 10 0x68 0x0f)',
  'i2cset -f -y 10 0x68 0x0f $((prev & 0x7f))',
].join(' && ');

// Sets the system clock on the Logic Module and, best-effort, on the Display
// Module over the fixed eth1 link, then persists it to each module's RTC.
app.post('/api/set-rtc', async (req, res) => {
  console.log('Running /api/set-rtc');

  const { iso, timezone } = req.body || {};

  const parsedDate = new Date(iso);
  if (typeof iso !== 'string' || isNaN(parsedDate.getTime())) {
    return res.status(400).json({ status: 'error', message: 'A valid ISO date/time is required.' });
  }

  // Restrict to IANA-zone-safe characters — also keeps this out of any shell
  // command built from it, whether run locally or over SSH.
  if (typeof timezone !== 'string' || !/^[A-Za-z0-9_+\-/]+$/.test(timezone)) {
    return res.status(400).json({ status: 'error', message: 'A valid timezone is required.' });
  }
  try {
    Intl.DateTimeFormat(undefined, { timeZone: timezone });
  } catch {
    return res.status(400).json({ status: 'error', message: `Unrecognized timezone: ${timezone}` });
  }

  const epochSeconds = Math.floor(parsedDate.getTime() / 1000);

  try {
    execFileSync('sudo', ['timedatectl', 'set-timezone', timezone]);
    execFileSync('sudo', ['date', '-u', '--set', `@${epochSeconds}`]);
    console.log(`Logic Module clock set to ${parsedDate.toISOString()} (${timezone})`);
  } catch (error) {
    console.error('Error setting Logic Module clock:', error);
    return res
      .status(500)
      .json({ status: 'error', message: 'Could not set the Logic Module clock.' });
  }

  try {
    execFileSync('sudo', ['sh', '-c', RTC_PERSIST_SCRIPT]);
    console.log('Logic Module RTC written and OSF cleared');
  } catch (error) {
    console.error('Error writing Logic Module RTC:', error);
    return res.status(500).json({
      status: 'error',
      message: 'The Logic Module clock was set, but could not be written to its hardware RTC.',
    });
  }

  // Best-effort: also set the Display Module's clock. Not fatal if it can't be
  // reached — the Logic Module's clock is already set at this point.
  let displaySet = false;
  if (await isDisplayReachable()) {
    try {
      execFileSync('ssh', [...SSH_ARGS_BASE, 'sudo', 'timedatectl', 'set-timezone', timezone]);
      execFileSync('ssh', [...SSH_ARGS_BASE, 'sudo', 'date', '-u', '--set', `@${epochSeconds}`]);
      execFileSync('ssh', [...SSH_ARGS_BASE, `sudo sh -c ${shQuote(RTC_PERSIST_SCRIPT)}`]);
      displaySet = true;
      console.log('Display Module clock set');
    } catch (error) {
      console.error('Error setting Display Module clock (non-fatal):', error.message);
    }
  } else {
    console.log('Display Module not reachable — its clock was not set');
  }

  res.status(200).json({ status: 'success', message: 'Clock set', displaySet });
});

app.get('/load', (req, res) => {
  console.log('Running /load');

  fs.readFile('/home/altronic/NGI3000.FPD', 'utf8', (err, data) => {
    if (err) {
      console.log('Error reading FPD file', err);
      res.sendStatus(404);
    } else {
      console.log('Successfully read FPD file: \n', data);
      res.send(data);
    }
  });
});

app.post(
  '/saveFPDFile',
  upload.single('firingPatternDataFile'),
  withPrune((req, res) => {
    console.log('Running /saveFPDFile');

    try {
      if (!req.file) {
        return res.status(400).json({ status: 'error', error: 'No file uploaded' });
      }

      const targetPath = '/home/altronic/NGI3000.FPD';
      const tempPath = targetPath + '.tmp';

      fs.readFile(req.file.path, (readErr, data) => {
        if (readErr) {
          console.error('Error reading uploaded FPD file from disk:', readErr);
          return res.status(500).json({
            status: 'error',
            error: 'Failed to read uploaded FPD file',
          });
        }

        // Write to a temporary file first
        fs.writeFile(tempPath, data, writeErr => {
          if (writeErr) {
            console.error('Error writing FPD file:', writeErr);
            return res.status(500).json({ status: 'error', error: 'Failed to write FPD file' });
          }

          // Rename the temporary file to the target path
          fs.rename(tempPath, targetPath, renameErr => {
            if (renameErr) {
              console.error('Error renaming FPD file:', renameErr);
              return res.status(500).json({
                status: 'error',
                error: 'Failed to move FPD file into place',
              });
            }

            console.log('FPD file saved successfully');
            res.json({
              status: 'success',
              message: 'FPD file saved successfully',
            });
          });
        });
      });
    } catch (error) {
      console.error('Unexpected error in /saveFPDFile:', error);
      res.status(500).json({ status: 'error', error: 'Unexpected server error' });
    }
  })
);

const getAWIFileList = (dir, ext) => {
  const extLength = !ext ? 0 : ext.length;
  const versionDir = path.join(TEMPLATE_DIR, dir);
  try {
    const files = fs.readdirSync(versionDir);
    const filteredFiles =
      extLength === 0 ? files : files.filter(file => file.slice(-1 * extLength) === ext);
    return filteredFiles;
  } catch (e) {
    return [];
  }
};

app.post('/renameAWIFile', async (req, res) => {
  // Use basename to sanitize paths
  const oldName = path.basename(req.body.oldName);
  const newName = path.basename(req.body.newName);
  const directory = req.body.directory;
  const validRegex = /^[^\\/:*?"<>|]+\.html$/;
  if (!validRegex.test(oldName)) {
    return res.status(400).json({
      status: 'error',
      error: 'old file name invalid',
    });
  }
  if (!validRegex.test(newName)) {
    return res.status(400).json({
      status: 'error',
      error: 'new file name invalid',
    });
  }
  const oldPath = path.join(TEMPLATE_DIR, directory, oldName);
  const newPath = path.join(TEMPLATE_DIR, directory, newName);

  const release = await screensMutex.acquire();
  try {
    if (!fs.existsSync(oldPath)) {
      return res.status(404).json({
        status: 'error',
        error: 'specified AWI file does not exist',
      });
    }
    if (fs.existsSync(newPath)) {
      return res.status(409).json({
        status: 'error',
        error: 'file already exists with specified name',
      });
    }
    fs.rename(oldPath, newPath, renameErr => {
      if (renameErr) {
        console.error('Error renaming AWI file:', renameErr);
        return res.status(500).json({
          status: 'error',
          error: 'Failed to rename AWI template file',
        });
      } else {
        const oldAWIPath = path.join(AWI_DIR, oldName);
        const newAWIPath = path.join(AWI_DIR, newName);
        if (isLiveTemplateFolder(directory) && fs.existsSync(oldAWIPath)) {
          fs.renameSync(oldAWIPath, newAWIPath);
        }
        res.json({
          status: 'success',
          message: 'AWI file renamed successfully',
        });
      }
    });
  } finally {
    release();
  }
});

app.get('/getTemplateScreensFolders', (req, res) => {
  try {
    const folders = fs
      .readdirSync(TEMPLATE_DIR)
      .filter(file => fs.lstatSync(path.join(TEMPLATE_DIR, file)).isDirectory());
    return res.json({ folders: folders });
  } catch (e) {
    res.status(500).json({
      status: 'error',
      message: 'error finding template screen folders',
    });
  }
});

app.get('/getAWIFileList/:dir', (req, res) => {
  const files = getAWIFileList(req.params.dir);
  res.send({ files: files });
});

app.get('/awi/', (req, res) => {
  console.log('Running /awi/');

  res.redirect('/awi/index.html');
});

app.get('/awi/:fname', async (req, res) => {
  console.log('Running /awi/:fname with params:', req.params);

  const hostIP = (req.headers.host || '').split(':')[0];
  const TARGET = 'window.EJECTED_CONNECT_SETTINGS = ';
  // Current RS-485 slave node id, injected into the AWI connect settings so the
  // screen addresses the gateway on the configured slave ID.
  const slaveNodeID = await readRs485SlaveNodeID();

  let patched = false;
  let buf = '';

  const replacementTransform = new Transform();
  replacementTransform._transform = function (data, encoding, done) {
    if (patched) {
      done(null, data);
      return;
    }

    buf += data.toString();
    const i = buf.indexOf(TARGET);

    // Comms settings not yet seen
    if (i === -1) {
      const safe = buf.length - (TARGET.length - 1);
      if (safe > 0) {
        this.push(buf.slice(0, safe));
        buf = buf.slice(safe);
      }
      done();
      return;
    }

    const jsonStart = i + TARGET.length;
    const lineEnd = buf.indexOf('\n', jsonStart);
    if (lineEnd === -1) {
      done();
      return;
    } // rest of line not yet in buffer

    const jsonStr = buf.slice(jsonStart, lineEnd).trimEnd(); // strip any \r
    let replacement = jsonStr;
    try {
      const s = JSON.parse(jsonStr);
      if (hostIP) {
        s.address = hostIP;
        s.deviceAddress = hostIP;
      }
      s.slaveUnitId = slaveNodeID;
      s.deviceSlaveUnitId = slaveNodeID;
      replacement = JSON.stringify(s);
    } catch {
      // unparseable — serve the line unchanged
    }

    this.push(buf.slice(0, jsonStart) + replacement + buf.slice(lineEnd));
    buf = '';
    patched = true;
    done();
  };

  replacementTransform._flush = function (done) {
    if (buf) this.push(buf); // flush remainder if file had no trailing newline
    done();
  };

  const filePath = path.join(AWI_DIR, req.params.fname);
  if (!fs.existsSync(filePath)) {
    return res.status(404).json({
      status: 'error',
      error: 'not found',
    });
  }

  let stream = fs.createReadStream(filePath);
  stream
    .pipe(replacementTransform)
    .on('end', () => {})
    .pipe(res);
});

app.get('/awi_edit/:fname', (req, res) => {
  console.log('Running /awi_edit/:fname with params:', req.params);

  const data = fs.readFileSync(AWI_DIR + req.params.fname, {
    encoding: 'utf8',
    flag: 'r',
  });
  //let str = data
  // Using replace instead of replaceAll for compatibility with older Node.js versions
  let str = data.replace(/localhost/g, '192.168.1.2');
  //let str2 = str
  //let str2 = str.replace('window.EJECTED_LOCKED = true', 'window.EJECTED_LOCKED = false')
  let str2 = str.replace(
    'window.EJECTED = true\nwindow.EJECTED_LOCKED = true',
    'window.EJECTED = false\nwindow.EJECTED_LOCKED = false'
  );
  res.send(str2);
});

app.get('/awi_templates/:folder/:fname', (req, res) => {
  const replacementTransform = new Transform();
  replacementTransform._transform = function (data, encoding, done) {
    // Using replace instead of replaceAll for compatibility with older Node.js versions
    const str = data.toString().replace(/localhost/g, `192.168.1.2`);
    this.push(str);
    done();
  };

  const filePath = path.join(TEMPLATE_DIR, req.params.folder, req.params.fname);
  if (!fs.existsSync(filePath)) {
    return res.status(404).json({
      status: 'error',
      error: 'not found',
    });
  }

  let stream = fs.createReadStream(filePath);
  stream
    .pipe(replacementTransform)
    .on('end', () => {})
    .pipe(res);
});

const LOW_STORAGE_THRESHOLD = 100 * 1024 * 1024; // 100 MB

function getFreeBytes(dirPath) {
  const stats = fs.statfsSync(dirPath);
  return stats.bavail * stats.bsize;
}

app.post('/awi_templates/:folder/:fname', awiUpload.single('file'), async (req, res) => {
  const uploadedPath = req.file.path;
  if (!req.params.fname.toLowerCase().endsWith('.html')) {
    fs.unlinkSync(uploadedPath);
    return res.status(400).json({
      status: 'error',
      error: 'uploaded file not of type .html',
    });
  }

  const baseName = path.basename(req.params.fname, '.html');
  let finalName = `${baseName}.html`;
  let finalPath = path.join(TEMPLATE_DIR, req.params.folder, finalName);

  const release = await screensMutex.acquire();
  try {
    // Collision detection
    let counter = 1;
    while (fs.existsSync(finalPath)) {
      finalName = `${baseName} (${counter}).html`;
      finalPath = path.join(TEMPLATE_DIR, req.params.folder, finalName);
      counter++;
    }

    fs.renameSync(uploadedPath, finalPath);

    // Check disk space
    const freeBytes = getFreeBytes(TEMPLATE_DIR);
    const fileSize = fs.statSync(finalPath).size;
    const isLowStorage = freeBytes < LOW_STORAGE_THRESHOLD;

    const config = readConfigFile();
    const isLiveFolder =
      config.status !== 'error' && config.selectedPickupName === req.params.folder;

    if (fs.existsSync(AWI_DIR) && isLiveFolder) {
      if (freeBytes < fileSize) {
        return res.status(201).json({
          message: 'Upload complete',
          fileName: finalName,
          renamed: finalName !== req.params.fname,
          warning:
            'Template upload successful, but insufficient space to copy to screens directory.',
          freeBytesRemaining: freeBytes,
        });
      }
      replaceLabels(req.params.folder, finalName, config);
    }

    return res.status(201).json({
      message: 'Upload complete',
      fileName: finalName,
      renamed: finalName !== req.params.fname,
      ...(isLowStorage && {
        warning: 'Storage is running low.',
        freeBytesRemaining: freeBytes,
      }),
    });
  } finally {
    release();
  }
});

app.delete('/awi_templates/:folder/:fname', async (req, res) => {
  const release = await screensMutex.acquire();
  try {
    const filePath = path.join(TEMPLATE_DIR, req.params.folder, req.params.fname);
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({
        status: 'error',
        error: 'not found',
      });
    }

    fs.rm(filePath, removeErr => {
      if (removeErr) {
        console.error('Error deleting AWI file:', removeErr);
        return res.status(500).json({
          status: 'error',
          error: 'Failed to delete AWI file',
        });
      } else {
        const awiPath = path.join(AWI_DIR, req.params.fname);
        if (isLiveTemplateFolder(req.params.folder) && fs.existsSync(awiPath)) {
          fs.rmSync(awiPath);
        }
        res.json({
          status: 'success',
          message: 'AWI file deleted successfully',
        });
      }
    });
  } finally {
    release();
  }
});

// ---------------------------------------------------------------------------
// Ethernet / nftables helpers
// ---------------------------------------------------------------------------

// Generates the nftables ruleset for the Logic Module.
// displayProxyIP: the alias on Logic's eth0 that clients use to reach the Display.
// Wi-Fi lives on the Display; the wlan0 drops are a backstop for older Logic CM4s that still
// have a radio, so nothing on Logic is ever reachable over it.
function generateLogicNftables(displayProxyIP) {
  return `#!/usr/sbin/nft -f
# NGI-3000 Logic board — nftables config managed by the config tool.

flush ruleset

table ip nat {
    chain prerouting {
        type nat hook prerouting priority dstnat; policy accept;
        iifname "eth0" ip daddr ${displayProxyIP} dnat to ${DISPLAY_ETH1_IP}
    }

    chain postrouting {
        type nat hook postrouting priority srcnat; policy accept;
        oifname "eth1" ct status dnat snat to ${LOGIC_ETH1_IP}
    }
}

table ip filter {
    chain input {
        type filter hook input priority filter; policy accept;
        # The fc4p bridge (port ${IRIS_FORCE_WRITE_PORT}) bypasses the Modbus gateway and is local-only.
        iifname "eth0" tcp dport ${IRIS_FORCE_WRITE_PORT} drop
        iifname "wlan0" drop
    }

    chain forward {
        type filter hook forward priority filter; policy drop;
        iifname "eth0" tcp dport ${IRIS_FORCE_WRITE_PORT} drop
        iifname "eth0" oifname "eth1" accept
        iifname "eth1" oifname "eth0" ct state related,established accept
    }
}
`;
}

// Generates the nftables ruleset for the Display Module.
// logicProxyIP: the alias on Display's eth0 that clients use to reach the Logic.
// hotspotActive: when true, masquerades Wi-Fi hotspot clients out to the Display's eth0 LAN.
//   NM injects equivalent rules for `ipv4.method shared`, but the `flush ruleset` below wipes
//   them, so they have to live here too.
// TCP sent to any of the Display's own wlan0 addresses (fixed in host mode, DHCP in client
// mode) is DNATed to the Logic so Wi-Fi users reach the config tool. UDP and TCP 53 stay local
// for the hotspot's DHCP/DNS. Port 1479 is dropped on wlan0 both locally and when forwarded.
function generateDisplayNftables(logicProxyIP, hotspotActive = false) {
  const hotspotPostrouting = hotspotActive
    ? `\n        iifname "wlan0" oifname "eth0" masquerade`
    : '';

  const hotspotForward = hotspotActive
    ? `\n        iifname "wlan0" oifname "eth0" accept
        iifname "eth0" oifname "wlan0" ct state related,established accept`
    : '';

  return `#!/usr/sbin/nft -f
# NGI-3000 Display board — nftables config managed by the config tool.

flush ruleset

table ip nat {
    chain prerouting {
        type nat hook prerouting priority dstnat; policy accept;
        iifname "eth0" ip daddr ${logicProxyIP} dnat to ${LOGIC_ETH1_IP}
        iifname "wlan0" fib daddr . iif type local tcp dport != 53 dnat to ${LOGIC_ETH1_IP}
    }

    chain postrouting {
        # Runs before NM's hotspot masquerade, which would otherwise claim DNATed wlan0 traffic
        # and pick a non-eth1 source because NM gives eth1's address link scope.
        type nat hook postrouting priority srcnat - 1; policy accept;
        oifname "eth1" ct status dnat snat to ${DISPLAY_ETH1_IP}${hotspotPostrouting}
    }
}

table ip filter {
    chain input {
        type filter hook input priority filter; policy accept;
        # The fc4p bridge (port ${IRIS_FORCE_WRITE_PORT}) bypasses the Modbus gateway and is local-only.
        iifname "eth0" tcp dport ${IRIS_FORCE_WRITE_PORT} drop
        iifname "wlan0" tcp dport ${IRIS_FORCE_WRITE_PORT} drop
    }

    chain forward {
        type filter hook forward priority filter; policy drop;
        iifname "eth0" tcp dport ${IRIS_FORCE_WRITE_PORT} drop
        iifname "wlan0" tcp dport ${IRIS_FORCE_WRITE_PORT} drop
        iifname "eth0" oifname "eth1" accept
        iifname "eth1" oifname "eth0" ct state related,established accept
        iifname "wlan0" oifname "eth1" ct status dnat accept
        iifname "eth1" oifname "wlan0" ct state related,established accept${hotspotForward}
    }
}
`;
}

// Persists whether each proxy IP is manually overridden.
// The actual proxy IPs themselves are read back from nmcli address2.
const PROXY_CONFIG_PATH = '/home/altronic/comms_proxy_config.json';

function readProxyConfig() {
  try {
    return JSON.parse(fs.readFileSync(PROXY_CONFIG_PATH, 'utf8'));
  } catch {
    return { Disp_Proxy_Manual: 'false', Logic_Proxy_Manual: 'false' };
  }
}

function saveProxyConfig(config) {
  fs.writeFileSync(PROXY_CONFIG_PATH, JSON.stringify(config));
}

// Returns true only for valid dotted-decimal IPv4 strings.
function isValidIPv4(ip) {
  if (!ip) return true; // empty / undefined is acceptable (treated as default)
  try {
    return ipaddr.parse(ip).kind() === 'ipv4';
  } catch {
    return false;
  }
}

const COMMS_DEFAULTS = {
  // Wi-Fi
  WiFi_Host: 'false',
  WiFi_Enabled: 'false',
  WiFi_SSID: 'NGI3000',
  WiFi_Password: 'altronic',
  WiFi_Client_SSID: '',
  WiFi_Client_Password: '',
  // Logic eth0
  Gbt_Eth_Use_DHCP: 'true',
  Gbt_Eth_IP_Address: '192.168.1.2',
  Gbt_Eth_Netmask: '255.255.0.0',
  Gbt_Eth_Gateway: '0.0.0.0',
  // Logic's Display Proxy alias on eth0
  Disp_Proxy_Manual: 'false',
  Disp_Proxy_IP: '192.168.1.3',
  // Display eth0
  Disp_Eth_Use_DHCP: 'true',
  Disp_Eth_IP_Address: '192.168.1.3',
  Disp_Eth_Netmask: '255.255.0.0',
  Disp_Eth_Gateway: '0.0.0.0',
  // Display's Logic Proxy alias on eth0
  Logic_Proxy_Manual: 'false',
  Logic_Proxy_IP: '192.168.1.2',
  // RS485 Modbus (port 1, always a slave in this application)
  RS485_Baud: '9600',
  RS485_Node: '1',
  // RS485_Parity: 'None',
  // RS485_DataBits: '8',
  // RS485_StopBits: '1',
};

app.get('/getComms', async (req, res) => {
  console.log('Running /getComms');
  const comms = await getCommsSettings({ ...COMMS_DEFAULTS });
  res.send(comms);
});

const getCommsSettings = async comms => {
  // --- Logic eth0 ---
  // address1 = Logic's own IP (manual mode) or absent (DHCP mode)
  // address2 = Display Proxy alias (always static, present in both modes)
  try {
    const connections = execSync('sudo nmcli -t -f NAME connection show').toString().split('\n');
    const eth0Exists = connections.includes('eth0');

    if (eth0Exists) {
      const ipv4Method = execSync('sudo nmcli -t -f ipv4.method connection show eth0')
        .toString()
        .replace('ipv4.method:', '')
        .trim();
      comms.Gbt_Eth_Use_DHCP = ipv4Method === 'auto' ? 'true' : 'false';

      const rawAddresses = execSync('sudo nmcli -t -f ipv4.addresses connection show eth0')
        .toString()
        .replace('ipv4.addresses:', '')
        .trim();
      const addrEntries = rawAddresses
        .split(',')
        .map(a => a.trim())
        .filter(Boolean);

      if (comms.Gbt_Eth_Use_DHCP === 'false') {
        // Manual: address1 = Logic IP, address2 = Display proxy alias
        if (addrEntries.length > 0) {
          const [ip, prefix] = addrEntries[0].split('/');
          comms.Gbt_Eth_IP_Address = ip;
          comms.Gbt_Eth_Netmask = ipaddr.IPv4.subnetMaskFromPrefixLength(
            parseInt(prefix, 10)
          ).toNormalizedString();
          const gateway = execSync('sudo nmcli -t -f ipv4.gateway connection show eth0')
            .toString()
            .replace('ipv4.gateway:', '')
            .trim();
          if (gateway) comms.Gbt_Eth_Gateway = gateway;
        }
        if (addrEntries.length > 1) {
          const [proxyIP] = addrEntries[1].split('/');
          comms.Disp_Proxy_IP = proxyIP;
        }
      } else {
        // DHCP: the only static address listed is the Display proxy alias
        if (addrEntries.length > 0) {
          const [proxyIP] = addrEntries[0].split('/');
          comms.Disp_Proxy_IP = proxyIP;
        }
      }
    } else {
      comms.Gbt_Eth_Use_DHCP = 'true';
    }
  } catch (exception) {
    console.error('Error reading Logic eth0:', exception);
  }

  // --- Proxy manual flags (stored in a local config file) ---
  try {
    const proxyConfig = readProxyConfig();
    comms.Disp_Proxy_Manual = proxyConfig.Disp_Proxy_Manual || 'false';
    comms.Logic_Proxy_Manual = proxyConfig.Logic_Proxy_Manual || 'false';
  } catch (exception) {
    console.error('Error reading proxy config:', exception);
  }

  // --- Display eth0 (read via SSH over the fixed eth1 link-local bridge) ---
  // address1 = Display's own IP (manual) or absent (DHCP)
  // address2 = Logic Proxy alias
  comms.displayReachable = false;
  if (await isDisplayReachable()) {
    try {
      const dispConnections = execFileSync(
        'ssh',
        [...SSH_ARGS_BASE, 'sudo nmcli -t -f NAME connection show'],
        { encoding: 'utf8' }
      ).split('\n');
      // SSH succeeded and peer confirmed — Display is reachable over the eth1 link.
      comms.displayReachable = true;
      const dispEth0Exists = dispConnections.includes('eth0');

      if (dispEth0Exists) {
        const dispMethod = execFileSync(
          'ssh',
          [...SSH_ARGS_BASE, 'sudo nmcli -t -f ipv4.method connection show eth0'],
          { encoding: 'utf8' }
        )
          .replace('ipv4.method:', '')
          .trim();
        comms.Disp_Eth_Use_DHCP = dispMethod === 'auto' ? 'true' : 'false';

        const dispRaw = execFileSync(
          'ssh',
          [...SSH_ARGS_BASE, 'sudo nmcli -t -f ipv4.addresses connection show eth0'],
          { encoding: 'utf8' }
        )
          .replace('ipv4.addresses:', '')
          .trim();
        const dispEntries = dispRaw
          .split(',')
          .map(a => a.trim())
          .filter(Boolean);

        if (comms.Disp_Eth_Use_DHCP === 'false') {
          if (dispEntries.length > 0) {
            const [dispIP, dispPrefix] = dispEntries[0].split('/');
            comms.Disp_Eth_IP_Address = dispIP;
            comms.Disp_Eth_Netmask = ipaddr.IPv4.subnetMaskFromPrefixLength(
              parseInt(dispPrefix, 10)
            ).toNormalizedString();
            const dispGateway = execFileSync(
              'ssh',
              [...SSH_ARGS_BASE, 'sudo nmcli -t -f ipv4.gateway connection show eth0'],
              { encoding: 'utf8' }
            )
              .replace('ipv4.gateway:', '')
              .trim();
            if (dispGateway) comms.Disp_Eth_Gateway = dispGateway;
          }
          if (dispEntries.length > 1) {
            const [logicProxyIP] = dispEntries[1].split('/');
            comms.Logic_Proxy_IP = logicProxyIP;
          }
        } else {
          if (dispEntries.length > 0) {
            const [logicProxyIP] = dispEntries[0].split('/');
            comms.Logic_Proxy_IP = logicProxyIP;
          }
        }
      }
    } catch (exception) {
      console.error('Error reading Display eth0 settings:', exception.message);
    }

    // --- Wi-Fi (Display wlan0) ---
    if (comms.displayReachable) {
      readDisplayWiFiSettings(comms);
    }
  }

  // --- RS485 Modbus (MDI-Gateway via Redis) ---
  // Serial params live in the `mdi-settings` hash (port 1). The slave ID is
  // the fixed device's proxy node id, read from its `mdi-device-<id>` hash.
  try {
    const settings = await redisHGetAll('mdi-settings');
    if (settings.rs4851BaudRate) comms.RS485_Baud = String(settings.rs4851BaudRate);
    // if (settings.rs4851Parity) comms.RS485_Parity = String(settings.rs4851Parity);
    // if (settings.rs4851DataBits) comms.RS485_DataBits = String(settings.rs4851DataBits);
    // if (settings.rs4851StopBits) comms.RS485_StopBits = String(settings.rs4851StopBits);
    comms.RS485_Node = await readRs485SlaveNodeID();
  } catch (exception) {
    console.error('Error reading RS485 settings from Redis:', exception.message);
  }

  return comms;
};

app.post('/saveComms', async (req, res) => {
  console.log('Running /saveComms with body:', req.body);

  res.send(await saveCommsToSystem(req.body));
});

// The host-mode Wi-Fi password is sent to the client masked, one mask character per real
// character, so the operator can see a password is set and how long it is without it being
// readable. A value that is still all mask characters when it comes back was never edited.
const PASSWORD_MASK_CHAR = '●';

const maskPassword = password => password.replace(/./g, PASSWORD_MASK_CHAR);

const isMaskedPassword = value =>
  typeof value === 'string' && value.length > 0 && [...value].every(c => c === PASSWORD_MASK_CHAR);

// Single-quotes a value for the Display's shell, which re-parses every command SSH sends.
const shQuote = value => `'${String(value ?? '').replace(/'/g, `'\\''`)}'`;

const displaySsh = command =>
  execFileSync('ssh', [...SSH_ARGS_BASE, command], { encoding: 'utf8' });

// Wi-Fi lives on the Display Module, so every wlan0 operation below runs there over SSH.
const getDisplaywlan0Connections = () => {
  try {
    const lines = displaySsh('sudo nmcli -t -f NAME,DEVICE connection show').split('\n');
    const wlan0Connections = lines.filter(line => line.includes('wlan0'));
    console.log(`Found ${wlan0Connections.length} Display connections associated with 'wlan0'`);
    return wlan0Connections;
  } catch (exception) {
    console.error(exception.message);
    return [];
  }
};

const readDisplayWiFiProfile = (connectionName, field, secret = false) =>
  displaySsh(
    `sudo nmcli ${secret ? '-s ' : ''}-g ${field} connection show ${shQuote(connectionName)}`
  ).trim();

// Reads the PSK off the Display's current wlan0 connection profile. Must be called before
// disconnectDisplaywlan0, which deletes the profile.
const readDisplaywlan0PSK = () => {
  try {
    const wlan0Connections = getDisplaywlan0Connections();
    if (wlan0Connections.length === 0) {
      return null;
    }
    const connectionName = wlan0Connections[0].split(':')[0];
    return readDisplayWiFiProfile(connectionName, '802-11-wireless-security.psk', true);
  } catch (exception) {
    console.error(exception.message);
    return null;
  }
};

const disconnectDisplaywlan0 = errors => {
  try {
    const wlan0Connections = getDisplaywlan0Connections();
    if (wlan0Connections.length > 0) {
      wlan0Connections.forEach(wlan0Info => {
        const connectionName = wlan0Info.split(':')[0];
        console.log(`Deleting Display connection '${connectionName}' associated with 'wlan0'...`);
        displaySsh(`sudo nmcli connection delete ${shQuote(connectionName)}`);
        console.log(`Display connection '${connectionName}' deleted`);
      });
    } else {
      console.log("Display connection 'wlan0' does not exist");
    }
  } catch (exception) {
    console.error(exception.message);
    errors.push(exception.message);
  }
};

// Fills the Wi-Fi fields of `comms` from the Display's wlan0 profile.
const readDisplayWiFiSettings = comms => {
  try {
    const wlan0Connections = getDisplaywlan0Connections();

    if (wlan0Connections.length > 0) {
      const connectionName = wlan0Connections[0].split(':')[0];
      console.log(`Display connection '${connectionName}' associated with 'wlan0' found`);

      const mode = readDisplayWiFiProfile(connectionName, '802-11-wireless.mode');
      comms.WiFi_Enabled = 'true';
      comms.WiFi_Host = mode.includes('ap') ? 'true' : 'false';

      const ssid = readDisplayWiFiProfile(connectionName, '802-11-wireless.ssid');
      const password = readDisplayWiFiProfile(connectionName, '802-11-wireless-security.psk', true);
      if (comms.WiFi_Host === 'true') {
        comms.WiFi_SSID = ssid;
        comms.WiFi_Password = maskPassword(password);
      } else {
        comms.WiFi_Client_SSID = ssid;
        comms.WiFi_Client_Password = password;
      }
    } else {
      comms.WiFi_Enabled = 'false';
    }
  } catch (exception) {
    console.error('Error reading Display Wi-Fi settings:', exception.message);
  }
};

// Recreates the Display's wlan0 profile from the submitted settings. Each mode's commands run
// in a single SSH session so the profile is never left half-configured by a dropped link.
const saveDisplayWiFi = (message, errors) => {
  if (message.WiFi_Enabled !== 'true') {
    disconnectDisplaywlan0(errors);
    return;
  }

  let commands;
  if (message.WiFi_Host === 'true') {
    // An unedited password comes back as mask characters, so recover the stored PSK rather than
    // writing the mask. Read it before disconnectDisplaywlan0 deletes the profile that holds it.
    let hostPassword = message.WiFi_Password;
    if (isMaskedPassword(hostPassword)) {
      hostPassword = readDisplaywlan0PSK();
    }

    if (!hostPassword) {
      // Leaving the connection alone is better than replacing its password with the mask.
      console.error('Could not resolve the Wi-Fi host password - leaving Wi-Fi unchanged');
      errors.push('Could not read the existing Wi-Fi password. Wi-Fi settings were not changed.');
      return;
    }

    commands = [
      `sudo nmcli connection add type wifi ifname wlan0 con-name wlan0 autoconnect yes ssid ${shQuote(message.WiFi_SSID)}`,
      'sudo nmcli connection modify wlan0 wifi.mode ap',
      'sudo nmcli connection modify wlan0 wifi.band bg',
      'sudo nmcli connection modify wlan0 wifi-sec.key-mgmt wpa-psk',
      `sudo nmcli connection modify wlan0 wifi-sec.psk ${shQuote(hostPassword)}`,
      'sudo nmcli connection modify wlan0 ipv4.method shared',
      'sudo nmcli connection modify wlan0 ipv4.addresses 10.1.101.10/24',
      // nftables only filters IPv4, so keep wlan0 IPv4-only.
      'sudo nmcli connection modify wlan0 ipv6.method disabled',
      'sudo nmcli connection up wlan0',
    ];
  } else {
    commands = [
      `sudo nmcli connection add type wifi con-name wlan0 ifname wlan0 ssid ${shQuote(message.WiFi_Client_SSID)}`,
      'sudo nmcli connection modify wlan0 wifi-sec.key-mgmt wpa-psk',
      `sudo nmcli connection modify wlan0 wifi-sec.psk ${shQuote(message.WiFi_Client_Password)}`,
      // Keep wlan0's DHCP routes from capturing traffic that should exit via eth0: no default
      // route, and a high metric so equal-length eth0 routes win. See the eth0 source routing.
      'sudo nmcli connection modify wlan0 ipv4.never-default true',
      'sudo nmcli connection modify wlan0 ipv4.route-metric 700',
      'sudo nmcli connection modify wlan0 ipv6.method disabled',
      'sudo nmcli connection up wlan0',
    ];
  }

  disconnectDisplaywlan0(errors);
  try {
    displaySsh(commands.join(' && '));
    console.log(
      `Display ${message.WiFi_Host === 'true' ? 'host' : 'client'} connection 'wlan0' added`
    );
  } catch (exception) {
    console.error(`Error configuring Display Wi-Fi: ${exception.message}`);
    errors.push(exception.message);
  }
};

// Returns the Display's current wlan0 IPv4 address, preferring the live device address.
const readDisplaywlan0IP = () => {
  const firstAddress = output => {
    const line = output.split('\n').find(l => /^(IP4\.ADDRESS|ipv4\.addresses)/.test(l));
    const [, addr = ''] = (line ?? '').split(':');
    return addr.split(',')[0].split('/')[0].trim();
  };
  try {
    const devIP = firstAddress(
      displaySsh('nmcli -t -f IP4.ADDRESS dev show wlan0 2>/dev/null || true')
    );
    if (devIP) return devIP;
    return firstAddress(
      displaySsh('nmcli -t -f ipv4.addresses connection show wlan0 2>/dev/null || true')
    );
  } catch (exception) {
    console.log('Could not get Display wlan0 IP:', exception.message);
    return '';
  }
};

const saveCommsToSystem = async message => {
  const errors = [];

  // --- RS485 Modbus (MDI-Gateway via Redis) ---
  try {
    await saveRs485ToRedis(message);
  } catch (error) {
    console.error(`Error saving RS485 settings to Redis: ${error.message}`);
    errors.push(error.message);
  }

  // --- Save proxy manual flags ---
  try {
    saveProxyConfig({
      Disp_Proxy_Manual: message.Disp_Proxy_Manual || 'false',
      Logic_Proxy_Manual: message.Logic_Proxy_Manual || 'false',
    });
  } catch (error) {
    console.error('Error saving proxy config:', error);
    errors.push(error.message);
  }

  // Effective proxy IPs: manual override or mirror the other device's actual IP.
  const dispProxyIP =
    message.Disp_Proxy_Manual === 'true' ? message.Disp_Proxy_IP : message.Disp_Eth_IP_Address;
  const logicProxyIP =
    message.Logic_Proxy_Manual === 'true' ? message.Logic_Proxy_IP : message.Gbt_Eth_IP_Address;

  // Validate all IPs before touching any network config.
  const ipChecks = [
    ['Gbt_Eth_IP_Address', message.Gbt_Eth_IP_Address, message.Gbt_Eth_Use_DHCP === 'true'],
    ['Gbt_Eth_Netmask', message.Gbt_Eth_Netmask, false],
    ['Gbt_Eth_Gateway', message.Gbt_Eth_Gateway, message.Gbt_Eth_Use_DHCP === 'true'],
    ['Disp_Proxy_IP', dispProxyIP, false],
    ['Disp_Eth_IP_Address', message.Disp_Eth_IP_Address, message.Disp_Eth_Use_DHCP === 'true'],
    ['Disp_Eth_Netmask', message.Disp_Eth_Netmask, false],
    ['Disp_Eth_Gateway', message.Disp_Eth_Gateway, message.Disp_Eth_Use_DHCP === 'true'],
    ['Logic_Proxy_IP', logicProxyIP, false],
  ];
  for (const [name, value, skip] of ipChecks) {
    if (skip) continue;
    if (!isValidIPv4(value)) {
      const msg = `Invalid IP address for ${name}: ${value}`;
      console.error(msg);
      errors.push(msg);
      return JSON.stringify(errors);
    }
  }

  // Subnet prefix lengths (fall back to /16 if netmask is absent/zero).
  let logicPrefix = 16;
  let dispPrefix = 16;
  try {
    if (message.Gbt_Eth_Netmask && message.Gbt_Eth_Netmask !== '0.0.0.0')
      logicPrefix = ipaddr.IPv4.parse(message.Gbt_Eth_Netmask).prefixLengthFromSubnetMask();
  } catch {
    /* keep fallback */
  }
  try {
    if (message.Disp_Eth_Netmask && message.Disp_Eth_Netmask !== '0.0.0.0')
      dispPrefix = ipaddr.IPv4.parse(message.Disp_Eth_Netmask).prefixLengthFromSubnetMask();
  } catch {
    /* keep fallback */
  }

  // --- Logic eth0 ---
  try {
    const connections = execSync('sudo nmcli connection show', { encoding: 'utf8' });
    if (connections.includes('eth0')) {
      execSync('sudo nmcli connection delete eth0');
      console.log("Logic: connection 'eth0' deleted");
    }
  } catch (exception) {
    console.log(exception.message);
  }

  try {
    if (message.Gbt_Eth_Use_DHCP === 'true') {
      execSync(
        'sudo nmcli connection add type ethernet con-name eth0 ifname eth0 ipv4.method auto'
      );
    } else {
      execSync(
        `sudo nmcli connection add type ethernet con-name eth0 ifname eth0 ip4 ${message.Gbt_Eth_IP_Address}/${logicPrefix} gw4 ${message.Gbt_Eth_Gateway}`
      );
      // Source-based routing: traffic FROM eth0's IP always exits via eth0, even
      // when wlan0's DHCP /24 is more specific than eth0's /${logicPrefix} and
      // would otherwise win longest-prefix-match for 192.168.1.x destinations.
      // Table 100 holds a default route via eth0's gateway; the ip rule selects
      // table 100 for any packet sourced from the eth0 address. NM persists these
      // in the keyfile so they survive reconnects and reboots.
      execSync(
        `sudo nmcli connection modify eth0 ipv4.routes "0.0.0.0/0 ${message.Gbt_Eth_Gateway} 100 table=100"`
      );
      // Table 100 contains ONLY a default route. Without protection, any packet
      // sourced from the eth0 IP (including traffic to the Display over the fixed
      // eth1 link-local link) would match the `from <eth0IP>` rule, hit table 100,
      // and be sent to the eth0 gateway instead of out eth1 — leaving eth1 with a
      // 192.168.x source. The higher-priority (lower number) rule below forces all
      // 169.254.0.0/16 (eth1 point-to-point link) traffic back to the main table so
      // the private inter-board link is never hijacked by source-based routing.
      execSync(
        `sudo nmcli connection modify eth0 ipv4.routing-rules "priority 90 to 169.254.0.0/16 lookup main, priority 100 from ${message.Gbt_Eth_IP_Address}/32 lookup 100"`
      );
    }
    // Append Display Proxy alias as a static second address (works in both DHCP and manual modes).
    execSync(`sudo nmcli connection modify eth0 +ipv4.addresses "${dispProxyIP}/${logicPrefix}"`);
    console.log("Logic: connection 'eth0' configured");
  } catch (exception) {
    console.error(`Error configuring Logic eth0: ${exception.message}`);
    errors.push(exception.message);
  }

  // Write Logic nftables ruleset and reload.
  try {
    execSync('sudo tee /etc/nftables.conf', {
      input: generateLogicNftables(dispProxyIP),
    });
    execSync('sudo systemctl reload nftables');
    console.log('Logic nftables updated');
  } catch (exception) {
    console.error(`Error updating Logic nftables: ${exception.message}`);
    errors.push(exception.message);
  }

  // Bring up the new Logic eth0 connection. Using `connection up` instead of
  // a full NM restart so that eth1 stays up and ip_forward is not reset by NM.
  try {
    execSync('sudo nmcli connection up eth0');
    console.log("Logic: connection 'eth0' brought up");
  } catch (exception) {
    console.error(`Error bringing up Logic eth0: ${exception.message}`);
    errors.push(exception.message);
  }

  // --- Display eth0 (via SSH over the fixed eth1 link-local bridge) ---
  if (await isDisplayReachable()) {
    try {
      execFileSync('ssh', [
        ...SSH_ARGS_BASE,
        'sudo nmcli connection delete eth0 2>/dev/null || true',
      ]);
      console.log("Display: connection 'eth0' deleted (if existed)");
    } catch (exception) {
      console.log('Display eth0 delete (non-fatal):', exception.message);
    }

    try {
      if (message.Disp_Eth_Use_DHCP === 'true') {
        execFileSync('ssh', [
          ...SSH_ARGS_BASE,
          'sudo nmcli connection add type ethernet con-name eth0 ifname eth0 ipv4.method auto',
        ]);
      } else {
        execFileSync('ssh', [
          ...SSH_ARGS_BASE,
          `sudo nmcli connection add type ethernet con-name eth0 ifname eth0 ip4 ${message.Disp_Eth_IP_Address}/${dispPrefix} gw4 ${message.Disp_Eth_Gateway}`,
        ]);
        // Same source-based routing as Logic eth0 above, now that wlan0 lives on the Display.
        execFileSync('ssh', [
          ...SSH_ARGS_BASE,
          `sudo nmcli connection modify eth0 ipv4.routes "0.0.0.0/0 ${message.Disp_Eth_Gateway} 100 table=100" ipv4.routing-rules "priority 90 to 169.254.0.0/16 lookup main, priority 100 from ${message.Disp_Eth_IP_Address}/32 lookup 100"`,
        ]);
      }
      // Append Logic Proxy alias.
      execFileSync('ssh', [
        ...SSH_ARGS_BASE,
        `sudo nmcli connection modify eth0 +ipv4.addresses "${logicProxyIP}/${dispPrefix}"`,
      ]);
      console.log("Display: connection 'eth0' configured");
    } catch (exception) {
      console.error(`Error configuring Display eth0: ${exception.message}`);
      errors.push(exception.message);
    }

    // Write Display nftables ruleset and reload. hotspotActive keeps the hotspot's masquerade,
    // which NM injected and `flush ruleset` would otherwise wipe.
    const hotspotActive = message.WiFi_Enabled === 'true' && message.WiFi_Host === 'true';
    try {
      execFileSync('ssh', [...SSH_ARGS_BASE, 'sudo tee /etc/nftables.conf'], {
        input: generateDisplayNftables(logicProxyIP, hotspotActive),
      });
      execFileSync('ssh', [...SSH_ARGS_BASE, 'sudo systemctl reload nftables']);
      console.log('Display nftables updated');
    } catch (exception) {
      console.error(`Error updating Display nftables: ${exception.message}`);
      errors.push(exception.message);
    }

    // Bring up the new Display eth0 connection. Using `connection up` instead of
    // a full NM restart so that ip_forward is not reset by NM.
    try {
      execFileSync('ssh', [...SSH_ARGS_BASE, 'sudo nmcli connection up eth0']);
      console.log("Display: connection 'eth0' brought up");
    } catch (exception) {
      console.error(`Error bringing up Display eth0: ${exception.message}`);
      errors.push(exception.message);
    }

    // --- Wi-Fi (Display wlan0) ---
    // Last, since recreating wlan0 drops any operator connected over Wi-Fi.
    saveDisplayWiFi(message, errors);
  }

  // Re-read the now-live settings (covers DHCP-assigned addresses too, not
  // just the manual ones just submitted) and push them into iris_go_3000's
  // IP registers. Best-effort: logged, not surfaced as a save error.
  try {
    const liveComms = await getCommsSettings({ ...COMMS_DEFAULTS });
    await pushIPRegistersToIris(liveComms);
  } catch (exception) {
    console.error('Error pushing IP registers to iris_go_3000:', exception.message);
  }

  return errors.length === 0 ? 'OK' : JSON.stringify(errors);
};

function trimColonSlash(stringToTrim) {
  if (stringToTrim) {
    const [, ipWithNetmask] = stringToTrim.split(':');
    if (ipWithNetmask) {
      const [trimmed_ip] = ipWithNetmask.split('/');
      return trimmed_ip;
    }
  }
  return '';
}

app.get('/getAssignedIPInfo', async (req, res) => {
  console.log('Running /getAssignedIPInfo');

  const body = {
    // Logic eth0 (DHCP-assigned values)
    gateway: '',
    netmask: '',
    ip: '',
    // Display wlan0
    wlan0_ip: '',
    // Display eth0 (DHCP-assigned values, fetched via SSH)
    disp_ip: '',
    disp_netmask: '',
    disp_gateway: '',
  };

  try {
    // Get default gateway
    let gateway = '';
    const gateway1 = execSync("nmcli -t -f ipv4.gateway con show eth0 | cut -d ':' -f2")
      .toString('utf8')
      .trim();
    const gateway2 = execSync("nmcli -t -f IP4.GATEWAY dev show eth0 | cut -d ':' -f2")
      .toString('utf8')
      .trim();
    if (gateway1 !== '') {
      gateway = gateway1;
    }
    if (gateway2 !== '') {
      gateway = gateway2;
    }
    body.gateway = gateway;
  } catch (exception) {
    console.log(exception);
  }

  try {
    // Get IP address and netmask for eth0
    const eth0IPOutput1 = execSync('nmcli -t -f ipv4.addresses connection show eth0')
      .toString('utf8')
      .trim();
    const eth0IP1 = trimColonSlash(eth0IPOutput1);
    const eth0IPOutput2 = execSync('nmcli -t -f IP4.ADDRESS dev show eth0').toString('utf8').trim();
    const eth0IP2 = trimColonSlash(eth0IPOutput2);
    let eth0ip = '';
    let eth0IPOutput = '';
    if (eth0IP1 !== '') {
      eth0ip = eth0IPOutput1;
      eth0IPOutput = eth0IPOutput1;
    }
    if (eth0IP2 !== '') {
      eth0ip = eth0IPOutput2;
      eth0IPOutput = eth0IPOutput2;
    }

    if (eth0IPOutput) {
      const [, ipWithNetmask] = eth0IPOutput.split(':');
      const [trimmed_ip, netmask_bits] = ipWithNetmask.split('/');
      body.ip = trimmed_ip;
      body.netmask = ipaddr.IPv4.subnetMaskFromPrefixLength(
        parseInt(netmask_bits)
      ).toNormalizedString();
    } else {
      console.log('No IP address found for eth0');
    }
  } catch (exception) {
    console.log(exception);
  }

  // Get Display eth0 DHCP-assigned IP/netmask/gateway and wlan0 IP via SSH.
  if (await isDisplayReachable()) {
    body.wlan0_ip = readDisplaywlan0IP();
    try {
      const dispAddrOut = execFileSync(
        'ssh',
        [...SSH_ARGS_BASE, 'nmcli -t -f IP4.ADDRESS dev show eth0'],
        { encoding: 'utf8' }
      ).trim();
      // Output: "IP4.ADDRESS[1]:x.x.x.x/prefix"
      const dispAddrLine = dispAddrOut.split('\n').find(l => l.startsWith('IP4.ADDRESS'));
      if (dispAddrLine) {
        const [, dispIPWithPrefix] = dispAddrLine.split(':');
        const [dispIP, dispPrefix] = dispIPWithPrefix.split('/');
        body.disp_ip = dispIP || '';
        if (dispPrefix) {
          body.disp_netmask = ipaddr.IPv4.subnetMaskFromPrefixLength(
            parseInt(dispPrefix, 10)
          ).toNormalizedString();
        }
      }
      const dispGwOut = execFileSync(
        'ssh',
        [...SSH_ARGS_BASE, 'nmcli -t -f IP4.GATEWAY dev show eth0'],
        { encoding: 'utf8' }
      ).trim();
      const dispGwLine = dispGwOut.split('\n').find(l => l.startsWith('IP4.GATEWAY'));
      if (dispGwLine) {
        const [, dispGw] = dispGwLine.split(':');
        body.disp_gateway = dispGw || '';
      }
    } catch (exception) {
      console.log('Could not get Display assigned IP info:', exception.message);
    }
  }

  res.send(body);
});

const findProperty = (text, property, hasEquals = true) => {
  const lines = text.split('\n');
  let startLine = '';
  lines.some(line => {
    const trimmed = line.trim();
    const startIndex = hasEquals
      ? Math.max(trimmed.indexOf(`${property}=`), trimmed.indexOf(`${property} =`))
      : trimmed.indexOf(property);
    if (startIndex === 0) {
      startLine = trimmed;
      return true;
    }
    return false;
  });
  if (startLine === '') {
    return undefined;
  }
  // const startLine = text.slice(startIndex);
  const breakIndex = startLine.indexOf(hasEquals ? '=' : ' ');
  if (breakIndex === -1) {
    return undefined;
  }
  const value = startLine.slice(hasEquals ? breakIndex + 1 : breakIndex);
  return value;
};

// ---------------------------------------------------------------------------
// Combined update bundle (NGI-3000_<ver>.tar, built by packages/NGI-3000_Meta).
// The bundle carries its own installer (install.js); this server only checks the
// bundle, starts the installer as a detached systemd unit, and serves its status.
// ---------------------------------------------------------------------------
const BUNDLE_UPDATE_DIR = '/home/altronic/ngi3000-update';
const BUNDLE_STAGING_DIR = path.join(BUNDLE_UPDATE_DIR, 'staging');
const BUNDLE_STATUS_PATH = path.join(BUNDLE_UPDATE_DIR, 'status.json');
const BUNDLE_LOG_PATH = path.join(BUNDLE_UPDATE_DIR, 'install.log');
const BUNDLE_UNIT = 'ngi3000-bundle-update';
const BUNDLE_FORMAT_VERSION = 1;
// Same path on the Logic and the Display: last ST firmware a bundle flashed on that board.
const ST_RECORD_PATH = '/home/altronic/ngi3000-update/st-firmware.json';
// Same names packages/NGI-3000_Meta/build.sh requires, so a single-ST update can only take
// an image meant for that ST.
const ST_FIRMWARE_NAMES = {
  logic: {
    pattern: /^NGI-3000-Logic-ST_v\d+\.\d+\.\d+\.bin$/,
    example: 'NGI-3000-Logic-ST_v1.2.3.bin',
  },
  display: {
    pattern: /^NGI-3000-Display-ST_v\d+\.\d+\.\d+\.bin$/,
    example: 'NGI-3000-Display-ST_v1.2.3.bin',
  },
};

function checkStFirmwareName(file, target) {
  const { pattern, example } = ST_FIRMWARE_NAMES[target];
  if (!pattern.test(file.originalname || '')) {
    throw bundleError(
      `'${file.originalname}' is not a ${target === 'logic' ? 'Logic' : 'Display'} ST firmware image. The file name must look like ${example}.`
    );
  }
}
const BUNDLE_COMPONENTS = {
  displayST: { ext: '.bin' },
  displayCM4: { ext: '.deb', package: 'ngi-3000-display' },
  logicST: { ext: '.bin' },
  logicCM4: { ext: '.deb', package: 'ngi-3000-logic' },
};
const BUNDLE_ENTRY_NAME = /^[A-Za-z0-9][A-Za-z0-9._-]*$/;
let bundleLaunchInProgress = false;

function isBundleUnitActive() {
  try {
    execFileSync('systemctl', ['is-active', '--quiet', BUNDLE_UNIT], { stdio: 'ignore' });
    return true;
  } catch {
    return false;
  }
}

function bundleError(message, statusCode = 400) {
  const error = new Error(message);
  error.statusCode = statusCode;
  return error;
}

// Rejects legacy single-component updates while a bundle install is running.
const rejectDuringBundleUpdate = (req, res, next) => {
  if (isBundleUnitActive()) {
    res.status(409).json({ message: 'A full system update is in progress.', status: 'error' });
    return;
  }
  next();
};

function sha256OfFile(filePath) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash('sha256');
    fs.createReadStream(filePath)
      .on('data', chunk => hash.update(chunk))
      .on('error', reject)
      .on('end', () => resolve(hash.digest('hex')));
  });
}

// Lists the tar's members and refuses anything but a flat set of regular files.
function listBundleEntries(tarPath) {
  let listing;
  try {
    listing = execFileSync('tar', ['-tvf', tarPath], { encoding: 'utf8' });
  } catch {
    throw bundleError('The selected file is not a valid update bundle (.tar).');
  }
  const entries = [];
  for (const line of listing.split('\n')) {
    if (!line.trim()) continue;
    const name = line.trim().split(/\s+/).pop().replace(/^\.\//, '');
    if (name === '' || name === '.') continue;
    if (line[0] !== '-' || !BUNDLE_ENTRY_NAME.test(name) || entries.includes(name)) {
      throw bundleError(`The update bundle contains an unexpected entry: ${name}`);
    }
    entries.push(name);
  }
  return entries;
}

async function validateBundle(tarPath) {
  const entries = listBundleEntries(tarPath);
  if (!entries.includes('manifest.json')) {
    throw bundleError('The update bundle has no manifest.json.');
  }

  fs.rmSync(BUNDLE_STAGING_DIR, { recursive: true, force: true });
  fs.mkdirSync(BUNDLE_STAGING_DIR, { recursive: true });
  try {
    execFileSync('tar', ['-xf', tarPath, '-C', BUNDLE_STAGING_DIR, '--no-same-owner'], {
      stdio: 'ignore',
    });
  } catch {
    throw bundleError('The update bundle could not be extracted.');
  }

  let manifest;
  try {
    manifest = JSON.parse(fs.readFileSync(path.join(BUNDLE_STAGING_DIR, 'manifest.json'), 'utf8'));
  } catch {
    throw bundleError('The update bundle manifest could not be read.');
  }
  if (manifest.product !== 'NGI-3000') {
    throw bundleError(`This bundle is for '${manifest.product}', not the NGI-3000.`);
  }
  if (!Number.isInteger(manifest.formatVersion) || manifest.formatVersion > BUNDLE_FORMAT_VERSION) {
    throw bundleError(
      'This update bundle needs a newer config tool. Update the Logic Module CM4 software first (Advanced).'
    );
  }

  const checkFile = async (label, entry, ext) => {
    if (!entry || typeof entry.file !== 'string' || !entries.includes(entry.file)) {
      throw bundleError(`The update bundle is missing the ${label} file.`);
    }
    if (ext && path.extname(entry.file).toLowerCase() !== ext) {
      throw bundleError(`The ${label} file in the bundle should be a ${ext} file.`);
    }
    const digest = await sha256OfFile(path.join(BUNDLE_STAGING_DIR, entry.file));
    if (digest !== entry.sha256) {
      throw bundleError(`Checksum mismatch for ${entry.file}. The bundle may be corrupt.`);
    }
  };

  await checkFile('installer', manifest.installer, '.js');
  for (const [id, spec] of Object.entries(BUNDLE_COMPONENTS)) {
    const component = (manifest.components || {})[id];
    await checkFile(id, component, spec.ext);
    if (typeof component.version !== 'string' || !component.version) {
      throw bundleError(`The ${id} entry in the bundle manifest has no version.`);
    }
    if (spec.package) {
      const debPath = path.join(BUNDLE_STAGING_DIR, component.file);
      let pkg;
      let version;
      try {
        pkg = execFileSync('dpkg-deb', ['-f', debPath, 'Package'], { encoding: 'utf8' });
        version = execFileSync('dpkg-deb', ['-f', debPath, 'Version'], { encoding: 'utf8' });
      } catch {
        throw bundleError(`Could not read package information from ${component.file}.`);
      }
      if (pkg.trim().toLowerCase() !== spec.package || version.trim() !== component.version) {
        throw bundleError(`${component.file} does not match the bundle manifest.`);
      }
    }
  }
  return manifest;
}

function readBundleStatus() {
  try {
    return JSON.parse(fs.readFileSync(BUNDLE_STATUS_PATH, 'utf8'));
  } catch {
    return null;
  }
}

function writeBundleStatus(status) {
  const tmp = `${BUNDLE_STATUS_PATH}.server.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(status, null, 2));
  fs.renameSync(tmp, BUNDLE_STATUS_PATH);
}

app.post(
  '/updateBundle',
  upload.single('updateBundle'),
  withPrune(async (req, res) => {
    console.log('Running /updateBundle');

    let uploadedPath;
    try {
      uploadedPath = validateAndGetUploadedFilePath(req.file, '.tar');
      console.log(`Selected update bundle: ${req.file.originalname}`);
    } catch (error) {
      console.error('Uploaded file validation error:', error.message);
      if (req.file?.path) fs.rmSync(req.file.path, { force: true });
      res.status(error.statusCode || 400).json({ message: error.message, status: 'error' });
      return;
    }

    if (bundleLaunchInProgress || isBundleUnitActive()) {
      fs.rmSync(uploadedPath, { force: true });
      res.status(409).json({ message: 'An update is already in progress.', status: 'error' });
      return;
    }
    bundleLaunchInProgress = true;

    try {
      fs.mkdirSync(BUNDLE_UPDATE_DIR, { recursive: true });
      const manifest = await validateBundle(uploadedPath);
      fs.rmSync(uploadedPath, { force: true });
      console.log(`Update bundle ${manifest.bundleVersion} verified`);

      const modbusNode = parseInt(await readRs485SlaveNodeID(), 10) || 1;
      const force = String((req.body || {}).force) === 'true';
      const runId = `${Date.now()}`;

      writeBundleStatus({
        runId,
        state: 'starting',
        bundleVersion: manifest.bundleVersion,
        force,
        startedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        message: 'Starting the installer',
        progress: 0,
        steps: [],
      });

      const installerPath = path.join(BUNDLE_STAGING_DIR, manifest.installer.file);
      const launchArgs = [
        'systemd-run',
        `--unit=${BUNDLE_UNIT}`,
        '--collect',
        '--description=NGI-3000 bundle update',
        `--setenv=NGI_RUN_ID=${runId}`,
        process.execPath,
        installerPath,
        '--modbus-node',
        String(modbusNode),
      ];
      if (force) launchArgs.push('--force');
      console.log(`Launching bundle installer: sudo ${launchArgs.join(' ')}`);
      execFileSync('sudo', launchArgs, { stdio: 'inherit' });

      res.status(200).json({
        message: 'Update started',
        status: 'success',
        runId,
        bundleVersion: manifest.bundleVersion,
      });
    } catch (error) {
      console.error('Error starting bundle update:', error.message);
      fs.rmSync(uploadedPath, { force: true });
      res
        .status(error.statusCode || 500)
        .json({ message: error.message || 'Could not start the update', status: 'error' });
    } finally {
      bundleLaunchInProgress = false;
    }
  })
);

app.get('/updateBundleStatus', (req, res) => {
  const status = readBundleStatus() || { state: 'idle', steps: [] };
  const unitActive = isBundleUnitActive();
  let currentBootId = '';
  try {
    currentBootId = fs.readFileSync('/proc/sys/kernel/random/boot_id', 'utf8').trim();
  } catch {
    // Not available off-target.
  }

  // A run that never reached a terminal state and has no live unit was cut short
  // (power loss, crash). Report it instead of spinning forever.
  if ((status.state === 'running' || status.state === 'starting') && !unitActive) {
    const age = Date.now() - Date.parse(status.updatedAt || status.startedAt || 0);
    if (!(age < 15 * 1000)) {
      status.state = 'error';
      status.error = 'The installer stopped before the update finished.';
      status.message = status.error;
    }
  }

  if (status.state === 'error') {
    try {
      status.logTail = fs.readFileSync(BUNDLE_LOG_PATH, 'utf8').trim().split('\n').slice(-20);
    } catch {
      status.logTail = [];
    }
  }

  res.status(200).json({ ...status, unitActive, currentBootId });
});

app.post(
  '/updateLogicModuleCM4',
  rejectDuringBundleUpdate,
  upload.single('logicModulePackage'),
  withPrune((req, res) => {
    console.log('Running /updateLogicModuleCM4');

    let validatedPath;
    try {
      validatedPath = validateAndGetUploadedFilePath(req.file, '.deb');
      console.log(`Selected update file: ${req.file.originalname}`);
      console.log(`Validated file path: ${validatedPath}`);
    } catch (error) {
      console.error('Uploaded file validation error:', error.message);
      res.status(error.statusCode || 400).json({ message: error.message, status: 'error' });
      return;
    }

    // Verify that the package name is correct and meant for the Logic Module
    try {
      let packageName = execFileSync('dpkg-deb', ['-f', validatedPath, 'Package'], {
        encoding: 'utf8',
      });
      if (!packageName) {
        console.error('Unable to determine package name from the selected .deb file.');
        res.status(400).json({
          message:
            "Unable to determine package name from the selected .deb file. The 'Package' field may be missing or malformed from the package metadata.",
          status: 'error',
        });
        return;
      }
      packageName = packageName.trim().toLowerCase();
      if (packageName !== 'ngi-3000-logic') {
        console.error(
          `Invalid package name '${packageName}' for installation on the Logic Module. Please select the correct Logic Module package for installation.`
        );
        res.status(400).json({
          message: `Invalid package name '${packageName}' for installation on the Logic Module. Please select the correct Logic Module package for installation.`,
          status: 'error',
        });
        return;
      }
    } catch (error) {
      console.error('Error verifying package name', error);
      res.status(500).json({ message: 'Error verifying package name', status: 'error' });
      return;
    }

    // Install the package
    try {
      if (!fs.existsSync(validatedPath)) {
        console.error(`Update file does not exist: ${validatedPath}`);
        res.status(500).json({ message: 'Update file missing', status: 'error' });
        return;
      }

      console.log(`Running 'sudo /home/altronic/updateLogicModuleCM4.sh <uploaded deb>'`);
      execFileSync('sudo', ['/home/altronic/updateLogicModuleCM4.sh', validatedPath], {
        stdio: 'inherit',
      });
      // console.log('Removing old package...');
      // execSync(`sudo apt-get purge -y iris-go`);
      // console.log('Installing new package...');
      // execSync(`sudo dpkg -i ${filePath}`);
      // execSync(`sudo apt-get install -f -y`);
      console.log('Package install started successfully');
      res.status(200).json({ message: 'Package install started successfully', status: 'success' });
      // Don't restart - new install script doesn't require it
      // setTimeout(() => {
      //   try {
      //     execFileSync('sudo', ['reboot'], { stdio: 'ignore' });
      //   } catch (error) {
      //     console.error('Reboot command failed', error);
      //   }
      // }, 5000);
    } catch (error) {
      console.error('Error installing package', error);
      res.status(500).json({ message: 'Error installing package', status: 'error' });
    }
  })
);

app.post(
  '/updateLogicModuleST',
  rejectDuringBundleUpdate,
  upload.single('logicModuleSTFirmware'),
  withPrune((req, res) => {
    console.log('Running /updateLogicModuleST');

    let filePath;
    try {
      filePath = validateAndGetUploadedFilePath(req.file, '.bin');
      checkStFirmwareName(req.file, 'logic');
      console.log(`Selected update file: ${req.file.originalname}`);
    } catch (error) {
      console.error('Uploaded file validation error:', error.message);
      if (req.file?.path) fs.rmSync(req.file.path, { force: true });
      res.status(error.statusCode || 400).json({ message: error.message, status: 'error' });
      return;
    }

    try {
      console.log('Updating ST firmware...');
      console.log('Making sure /home/altronic/usb1 exists...');
      execFileSync('mkdir', ['-p', '/home/altronic/usb1'], {
        stdio: 'inherit',
      });
      console.log('Copying file to directory...');
      execFileSync('cp', [filePath, '/home/altronic/usb1/NGI-3000-CRC.bin'], {
        stdio: 'inherit',
      });
      // A bundle would otherwise assume the ST still runs the firmware it last flashed.
      fs.rmSync(ST_RECORD_PATH, { force: true });
      console.log('File copied, sending curl command to start update...');
      execFileSync('curl', ['http://127.0.0.1:8080/fc/1/6/998/1/27183'], {
        stdio: 'inherit',
      });
      console.log('ST firmware update started successfully');
      res.status(200).json({
        message: 'ST firmware update started successfully',
        status: 'success',
      });
    } catch (error) {
      console.error('Error updating ST firmware', error);
      res.status(500).json({ message: 'ST firmware update error', status: 'error' });
    }
  })
);

app.get('/packageVersion', (req, res) => {
  console.log('Running /packageVersion');

  try {
    const packageNames = ['ngi-3000-logic'];
    let version = '';
    packageNames.some(packageName => {
      try {
        version = execSync(`dpkg-query -W -f='${'${Version}'}\n' ${packageName}`).toString().trim();
        return version.length > 0;
      } catch (error) {
        return false;
      }
    });
    console.log(`Package version found: ${version}`);
    res.status(200).json({ version });
  } catch (error) {
    console.error('Error getting package version', error);
    res.status(500).json({ message: 'Error getting package version', status: 'error' });
  }
});

app.post(
  '/updateDisplayCM4',
  rejectDuringBundleUpdate,
  upload.single('displayPackage'),
  withPrune((req, res) => {
    console.log('Running /updateDisplayCM4');

    const file = req.file;
    const displayIP = DISPLAY_ETH1_IP; // always use the fixed eth1 link-local IP
    const user = 'altronic';
    const displayUpdateScriptPath = '/home/altronic/updateDisplayCM4.sh';
    const displayFilePath = path.posix.join(UPLOADS_DIR, file ? file.filename : '');
    const sshArgsBase = ['-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10'];
    let validatedPath;

    try {
      validatedPath = validateAndGetUploadedFilePath(req.file, '.deb');
      console.log(`Selected update file: ${req.file.originalname}`);
      console.log(`Validated file path: ${validatedPath}`);
    } catch (error) {
      console.error('Uploaded file validation error:', error.message);
      res.status(error.statusCode || 400).json({ message: error.message, status: 'error' });
      return;
    }

    // Verify that the package name is correct and meant for the Display Module CM4
    try {
      let packageName = execFileSync('dpkg-deb', ['-f', validatedPath, 'Package'], {
        encoding: 'utf8',
      });
      if (!packageName) {
        console.error('Unable to determine package name from the selected .deb file.');
        res.status(400).json({
          message:
            "Unable to determine package name from the selected .deb file. The 'Package' field may be missing or malformed from the package metadata.",
          status: 'error',
        });
        return;
      }
      packageName = packageName.trim().toLowerCase();
      if (packageName !== 'ngi-3000-display') {
        console.error(
          `Invalid package name '${packageName}' for installation on the Display Module CM4. Please select the correct Display Module CM4 package for installation.`
        );
        res.status(400).json({
          message: `Invalid package name '${packageName}' for installation on the Display Module CM4. Please select the correct Display Module CM4 package.`,
          status: 'error',
        });
        return;
      }
    } catch (error) {
      console.error('Error verifying package name', error);
      res.status(500).json({ message: 'Error verifying package name', status: 'error' });
      return;
    }

    // Install the package
    try {
      console.log('Display Module update paths:');
      console.log(`  Local validated .deb: ${validatedPath}`);
      console.log(`  Display .deb path:    ${user}@${displayIP}:${displayFilePath}`);
      console.log(`  Installer script:     ${displayUpdateScriptPath}`);

      // Copy the installer script to the Display Module
      console.log('Copying installer script to Display Module...');
      execFileSync(
        'scp',
        [
          ...sshArgsBase,
          '/home/altronic/updateDisplayCM4.sh',
          `${user}@${displayIP}:${displayUpdateScriptPath}`,
        ],
        { stdio: 'inherit' }
      );

      // Set the script permissions
      console.log('Setting script permissions on Display Module...');
      execFileSync(
        'ssh',
        [...sshArgsBase, `${user}@${displayIP}`, 'chmod', '+x', displayUpdateScriptPath],
        { stdio: 'inherit' }
      );

      // Make sure the uploads directory exists on the Display Module
      console.log('Creating uploads directory on Display Module if it does not exist...');
      execFileSync('ssh', [...sshArgsBase, `${user}@${displayIP}`, 'mkdir', '-p', UPLOADS_DIR], {
        stdio: 'inherit',
      });

      // Copy the .deb file to the Display Module
      console.log('Copying .deb file to Display Module...');
      execFileSync(
        'scp',
        [...sshArgsBase, validatedPath, `${user}@${displayIP}:${displayFilePath}`],
        { stdio: 'inherit' }
      );

      // Run the installer script
      console.log(
        `Running installer: ssh ${user}@${displayIP} sudo ${displayUpdateScriptPath} ${displayFilePath}`
      );
      execFileSync(
        'ssh',
        [...sshArgsBase, `${user}@${displayIP}`, 'sudo', displayUpdateScriptPath, displayFilePath],
        { stdio: 'inherit' }
      );
      console.log('Package installed successfully, rebooting Display Module...');
      res.status(200).json({ message: 'Package installed successfully', status: 'success' });
      // Reboot the Display Module
      execFileSync('ssh', [...sshArgsBase, `${user}@${displayIP}`, 'sudo', 'reboot'], {
        stdio: 'ignore',
      });
    } catch (error) {
      console.error('Error installing package', error);
      res.status(500).json({ message: 'Error installing package', status: 'error' });
    }
  })
);

app.post(
  '/updateDisplayST',
  rejectDuringBundleUpdate,
  upload.single('displayModuleSTFirmware'),
  withPrune(async (req, res) => {
    console.log('Running /updateDisplayST');

    let filePath;
    try {
      filePath = validateAndGetUploadedFilePath(req.file, '.bin');
      checkStFirmwareName(req.file, 'display');
      console.log(`Selected update file: ${req.file.originalname}`);
    } catch (error) {
      console.error('Uploaded file validation error:', error.message);
      if (req.file?.path) fs.rmSync(req.file.path, { force: true });
      res.status(error.statusCode || 400).json({ message: error.message, status: 'error' });
      return;
    }

    if (!(await isDisplayReachable())) {
      console.error('Display Module is not reachable over SSH');
      res.status(502).json({ message: 'Display Module is not reachable', status: 'error' });
      return;
    }

    const user = 'altronic';
    const displayUsb1Dir = '/home/altronic/usb1';
    const displayBinPath = `${displayUsb1Dir}/NGI-3000-DISPLAY-CRC.bin`;
    // scp needs its own arg list (SSH_ARGS_BASE ends with the bare user@host, which
    // scp can't use as a positional source/destination argument).
    const scpArgsBase = [
      '-i',
      '/home/altronic/.ssh/id_rsa',
      '-o',
      'BatchMode=yes',
      '-o',
      'ConnectTimeout=10',
    ];

    try {
      console.log('Updating Display ST firmware...');
      console.log('Making sure the Display Module usb1 directory exists...');
      execFileSync('ssh', [...SSH_ARGS_BASE, 'mkdir', '-p', displayUsb1Dir], {
        stdio: 'inherit',
      });
      console.log('Copying file to the Display Module...');
      execFileSync(
        'scp',
        [...scpArgsBase, filePath, `${user}@${DISPLAY_ETH1_IP}:${displayBinPath}`],
        { stdio: 'inherit' }
      );
      execFileSync('ssh', [...SSH_ARGS_BASE, 'rm', '-f', ST_RECORD_PATH], { stdio: 'inherit' });
      console.log('File copied, writing the STBOOT trigger to start the update...');
      // DISP_STBOOT (coredata 40000:3999) forwards across the bridge like any
      // other Display-owned (>=3000) register, so a local write here reaches the
      // Display's bootloader the same way /updateLogicModuleST's 998 reaches the
      // Logic ST. Address is 3998 (coredata register - 1, matching that 999->998
      // pattern) - unverified on bench hardware, confirm before field use.
      execFileSync('curl', ['http://127.0.0.1:8080/fc/1/6/3998/1/27183'], {
        stdio: 'inherit',
      });
      console.log('Display ST firmware update started successfully');
      res.status(200).json({
        message: 'Display ST firmware update started successfully',
        status: 'success',
      });
    } catch (error) {
      console.error('Error updating Display ST firmware', error);
      res.status(500).json({ message: 'Display ST firmware update error', status: 'error' });
    }
  })
);

// Mirror whatever RS485 settings are already in Redis into the gateway's holding
// registers on startup (e.g. after a power cycle). Reuses the same helper as a
// Comms page save so the baud rate goes through its register encoding and the
// write waits for the gateway to actually be online first.
getCommsSettings(COMMS_DEFAULTS)
  .then(comms => syncRs485RegistersToGateway(comms.RS485_Node, comms.RS485_Baud))
  .catch(exception => {
    console.error('Error syncing RS485 registers to gateway on startup:', exception.message);
  });
httpServer.listen(PORT, () => {
  console.log(`Web Server listening on *:${PORT}`);
});
