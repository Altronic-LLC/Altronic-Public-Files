#!/bin/bash
#
# updateLogicModuleCM4.sh — replace the installed NGI-3000-Logic package with a new .deb.
#
# Usage: updateLogicModuleCM4.sh <path-to-new-package.deb>
#
# WHY THE TWO-STAGE HANDOFF
# -------------------------
# This script is invoked from the config tool, i.e. from *inside*
# config_tool.service's cgroup. The package prerm runs
# `systemctl stop config_tool.service` during `apt-get purge`, and systemd
# kills every process in that cgroup — including this script and the
# apt-get/dpkg it spawned. Result: the purge was left half-finished and the
# re-install never ran.
#
# (Note: the purge *deleting this script file* is NOT the problem — bash holds
# an open fd to the script and keeps running after an unlink. The cgroup
# teardown is what killed the update.)
#
# Stage 1 (caller's context): validate args, copy this script and the .deb to
# /tmp, launch stage 2 as a transient systemd unit in its own cgroup, and
# return immediately. The caller should treat exit 0 as "update started",
# not "update finished" — the caller's own service will be stopped mid-update.
#
# Stage 2 (detached unit): purge the old package, install the new one, restart
# the services, and log everything to $LOG_FILE.
#
# RECOVERING FROM A PREVIOUSLY KILLED UPDATE
# ------------------------------------------
# An update killed mid-unpack leaves the dpkg database mid-transaction and
# *.dpkg-new / *.dpkg-tmp staging files on disk (the new file parked next to
# the still-active old one). Stage 2 handles this state: it settles the
# database with `dpkg --configure -a`, purges the package from *any* dpkg
# state (not just 'install ok installed'), verifies the final state after
# install, and sweeps leftover staging files only after a confirmed success.

LOG_FILE="/var/log/ngi-logic-update.log"
UNIT_NAME="ngi-logic-update"

# List of possible package names
package_names=(
    "ngi-3000-logic"
)

# ---------------------------------------------------------------------------
# Stage 1 — runs in the caller's cgroup; hand off to a detached unit and exit.
# ---------------------------------------------------------------------------
if [ -z "$NGI_UPDATE_STAGE2" ]; then
    if [ $# -eq 0 ]; then
        echo "Please provide the file path as an argument."
        exit 1
    fi

    new_package_file_path=$(readlink -f "$1")
    if [ ! -f "$new_package_file_path" ]; then
        echo "Package file not found: $1"
        exit 1
    fi

    if ! command -v systemd-run >/dev/null 2>&1; then
        echo "systemd-run not found; cannot run the update detached."
        exit 1
    fi

    # Stage working copies in /tmp so nothing we depend on lives in a path
    # the purge is about to delete.
    staged_script=$(mktemp /tmp/updateLogicModuleCM4.XXXXXX.sh) || exit 1
    staged_deb=$(mktemp /tmp/ngi-3000-logic.XXXXXX.deb) || exit 1
    cp "$(readlink -f "$0")" "$staged_script"
    cp "$new_package_file_path" "$staged_deb"
    chmod +x "$staged_script"

    echo "Launching detached update unit '$UNIT_NAME' (log: $LOG_FILE)..."
    # --collect garbage-collects the unit even if it fails, so a failed run
    # can't block the next attempt. A *running* update still blocks a second
    # invocation (same unit name), which is what we want.
    if systemd-run --unit="$UNIT_NAME" --collect \
        --description="NGI-3000 Logic package update" \
        --setenv=NGI_UPDATE_STAGE2=1 \
        /bin/bash "$staged_script" "$staged_deb"; then
        echo "Update started. This service will be stopped and restarted;"
        echo "progress is logged to $LOG_FILE."
        exit 0
    else
        echo "Failed to launch detached update unit."
        rm -f "$staged_script" "$staged_deb"
        exit 1
    fi
fi

# ---------------------------------------------------------------------------
# Stage 2 — detached transient unit; immune to prerm's `systemctl stop`.
# ---------------------------------------------------------------------------
exec >>"$LOG_FILE" 2>&1

new_package_file_path="$1"
staged_script_self=$(readlink -f "$0")

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*"; }

# eth0 is the user-configurable Logic<->site network link and is NOT shipped
# by the package, so a routine update no longer touches it - but a purge of
# an *older* package version that still shipped this file would still delete
# it out from under us. Back it up before the purge below and restore
# whatever the user had configured afterward, rather than letting postinst's
# first-install default stand and potentially locking the user out.
NM_ETH0=/etc/NetworkManager/system-connections/eth0.nmconnection
NM_ETH0_BACKUP="/tmp/eth0.nmconnection.pre-update.$$"

if [ -f /var/lib/ngi3000-net/eth0-provisioned ] && [ -f "$NM_ETH0" ]; then
    cp -a "$NM_ETH0" "$NM_ETH0_BACKUP"
fi

cleanup() {
    rm -f "$staged_script_self" "$new_package_file_path" "$NM_ETH0_BACKUP"
}
trap cleanup EXIT

export DEBIAN_FRONTEND=noninteractive

log "=== NGI-3000 Logic update started (package: $new_package_file_path) ==="

# A previously killed update leaves the dpkg database mid-transaction
# (symptoms: *.dpkg-new / *.dpkg-tmp litter, apt refusing to run until the
# state is settled). Do this before anything else.
log "Settling any interrupted dpkg state (dpkg --configure -a)..."
dpkg --configure -a || log "WARNING: dpkg --configure -a reported an error."

# Package name from the .deb itself, with a fallback.
target_pkg=$(dpkg-deb -f "$new_package_file_path" Package 2>/dev/null)
[ -n "$target_pkg" ] || target_pkg="${package_names[0]}"

package_status() {
    dpkg-query -W -f='${db:Status-Status}' "$1" 2>/dev/null
}

# Purge the package if it is present in ANY state — 'half-installed',
# 'unpacked', 'config-files', etc. all count. (Matching only
# "install ok installed" made earlier versions skip the purge on boards
# wounded by a previously interrupted update.)
package_found=false
for pkg in "${package_names[@]}"; do
    status=$(package_status "$pkg")
    if [ -n "$status" ] && [ "$status" != "not-installed" ]; then
        log "Found package $pkg in state '$status'"
        log "Uninstalling $pkg..."
        if ! apt-get purge -y "$pkg"; then
            log "WARNING: purge of $pkg reported an error; continuing with install."
        fi
        package_found=true
        break
    fi
done

if [ "$package_found" != true ]; then
    # Do NOT abort here: an interrupted earlier update leaves the board with
    # the package purged but never re-installed. Installing anyway is the
    # recovery path for exactly that state.
    log "No installed package found to uninstall; proceeding with install."
fi

log "Installing $new_package_file_path..."
if ! dpkg -i "$new_package_file_path"; then
    log "dpkg -i reported an error; attempting dependency fix..."
fi
apt-get install -f -y

# Restore the user's eth0 config if the purge above removed it (only
# possible when the previously-installed version still shipped the file;
# see the backup above). Skip the reload entirely if nothing actually
# changed, so a routine update - which never touches this file anymore -
# doesn't flap the network link.
if [ -f "$NM_ETH0_BACKUP" ] && ! cmp -s "$NM_ETH0_BACKUP" "$NM_ETH0" 2>/dev/null; then
    log "Restoring pre-update eth0 network configuration..."
    cp -a "$NM_ETH0_BACKUP" "$NM_ETH0"
    chmod 600 "$NM_ETH0"
    nmcli connection reload
    nmcli connection up eth0 2>/dev/null || log "WARNING: could not bring eth0 back up after restoring its config."
fi

# postinst only *enables* the services and prerm stopped them — start them
# explicitly so the board is functional without a reboot.
systemctl daemon-reload
for unit in iris_go.service mdi-gateway.service config_tool.service; do
    systemctl restart "$unit" 2>/dev/null || log "WARNING: could not restart $unit"
done

# Verify the result instead of assuming success.
final_status=$(package_status "$target_pkg")
if [ "$final_status" = "installed" ]; then
    # Sweep staging litter (*.dpkg-new / *.dpkg-tmp) left behind by earlier
    # interrupted runs. Only safe after a confirmed good install — a completed
    # dpkg run has already consumed its own staging files, so anything left
    # is an orphan.
    find /home/altronic \( -name '*.dpkg-new' -o -name '*.dpkg-tmp' \) -print -delete 2>/dev/null |
        while read -r stale; do log "Removed stale dpkg staging file: $stale"; done
    log "=== Update SUCCESSFUL: $target_pkg $(dpkg-query -W -f='${Version}' "$target_pkg" 2>/dev/null) installed. ==="
    exit 0
else
    log "=== Update FAILED: $target_pkg is in state '${final_status:-not present}'."
    log "Recover manually over SSH: dpkg --configure -a; dpkg -i <deb>; apt-get install -f -y ==="
    exit 1
fi
