#!/bin/sh
#
# update-boot-config.sh --ensure-line "LINE" [--ensure-line "LINE" ...] \
#                        [--comment-out "PREFIX" ...]
#
# Safely applies our required directives to /boot/firmware/config.txt.
#
# /boot/firmware is the FAT boot partition, which is far more likely to come
# back empty after a torn write (e.g. power loss mid-update) than the root
# filesystem. Editing it in place used to mean a bad update could leave a
# board with a completely empty config.txt - no display/UART/RTC config on
# the next boot. Instead of editing the live file directly, we:
#
#   1. Start from the live config.txt, unless it's already empty - in that
#      case start from the last known-good copy kept at $BASE_COPY.
#   2. Copy that starting point to a scratch file.
#   3. Make the edits against the scratch copy only, never the live file.
#   4. Verify the scratch copy is non-empty before trusting it. If editing
#      it somehow left it empty, redo the edits starting from $BASE_COPY.
#   5. Only once the result checks out, write it to both $BASE_COPY and the
#      live file - so the next update always has a known-good fallback,
#      even if the live file gets corrupted later.

set -e

LIVE_CONFIG=/boot/firmware/config.txt
BASE_COPY=/home/altronic/boot-config.txt
WORK_COPY=$(mktemp /tmp/config.txt.XXXXXX)

ENSURE_LINES=""
COMMENT_PREFIXES=""

while [ $# -gt 0 ]; do
    case "$1" in
        --ensure-line)
            ENSURE_LINES="${ENSURE_LINES}${2}
"
            shift 2
            ;;
        --comment-out)
            COMMENT_PREFIXES="${COMMENT_PREFIXES}${2}
"
            shift 2
            ;;
        *)
            echo "update-boot-config.sh: unknown argument: $1" >&2
            exit 1
            ;;
    esac
done

# Comments out any line starting with each given prefix, and appends any
# ensure-line not already present, in the given file.
apply_edits() {
    target="$1"

    if [ -n "$COMMENT_PREFIXES" ]; then
        printf '%s\n' "$COMMENT_PREFIXES" | while IFS= read -r prefix; do
            [ -n "$prefix" ] || continue
            escaped=$(printf '%s\n' "$prefix" | sed 's/[][\/.^$*]/\\&/g')
            sed -i "s/^${escaped}/#${prefix}/" "$target"
        done
    fi

    if [ -n "$ENSURE_LINES" ]; then
        printf '%s\n' "$ENSURE_LINES" | while IFS= read -r line; do
            [ -n "$line" ] || continue
            grep -q "^${line}" "$target" || echo "$line" >> "$target"
        done
    fi
}

start_from() {
    cp "$1" "$WORK_COPY"
    apply_edits "$WORK_COPY"
}

if [ -s "$LIVE_CONFIG" ]; then
    start_from "$LIVE_CONFIG"
else
    echo "update-boot-config.sh: $LIVE_CONFIG is empty or missing; starting from $BASE_COPY" >&2
    start_from "$BASE_COPY"
fi

if [ ! -s "$WORK_COPY" ]; then
    echo "update-boot-config.sh: edited config.txt came out empty; retrying from $BASE_COPY" >&2
    start_from "$BASE_COPY"
fi

if [ ! -s "$WORK_COPY" ]; then
    echo "update-boot-config.sh: still empty after retry from $BASE_COPY; leaving config.txt untouched" >&2
    rm -f "$WORK_COPY"
    exit 1
fi

cp "$WORK_COPY" "$BASE_COPY" 2>/dev/null || sudo cp "$WORK_COPY" "$BASE_COPY"
cp "$WORK_COPY" "$LIVE_CONFIG" 2>/dev/null || sudo cp "$WORK_COPY" "$LIVE_CONFIG"
sync
rm -f "$WORK_COPY"
