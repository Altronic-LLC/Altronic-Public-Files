#!/bin/bash

if [ $# -eq 0 ]; then
    echo "Please provide the file path as an argument."
    exit 1
fi

new_package_file_path="$1"
if [ ! -f "$new_package_file_path" ]; then
    echo "Package file not found: $new_package_file_path"
    exit 1
fi

export DEBIAN_FRONTEND=noninteractive

# eth0 is the user-configurable Display<->site network link and is NOT
# shipped by the package, so a routine update no longer touches it - but a
# purge of an *older* package version that still shipped this file (the
# "replacing with a different package" branch below) would still delete it
# out from under us. Back it up now and restore whatever the user had
# configured after install, rather than letting postinst's first-install
# default stand and potentially locking the user out.
NM_ETH0=/etc/NetworkManager/system-connections/eth0.nmconnection
NM_ETH0_BACKUP="/tmp/eth0.nmconnection.pre-update.$$"

if [ -f /var/lib/ngi3000-net/eth0-provisioned ] && [ -f "$NM_ETH0" ]; then
    cp -a "$NM_ETH0" "$NM_ETH0_BACKUP"
fi

# Only these package names may be installed or touched by this script.
package_names=(
    "ngi-3000-display"
)

# Name and version from the .deb itself rather than parsed from the filename.
new_package_name=$(dpkg-deb -f "$new_package_file_path" Package 2>/dev/null)
new_package_version=$(dpkg-deb -f "$new_package_file_path" Version 2>/dev/null)

if [ -z "$new_package_name" ]; then
    echo "Could not read a package name from $new_package_file_path; not touching anything." >&2
    exit 1
fi

is_allowed=false
for pkg in "${package_names[@]}"; do
    if [ "$pkg" = "$new_package_name" ]; then
        is_allowed=true
        break
    fi
done

if [ "$is_allowed" != true ]; then
    echo "$new_package_name is not in the allowed package list (${package_names[*]}); not installing or touching anything." >&2
    exit 1
fi

package_status() {
    dpkg-query -W -f='${db:Status-Status}' "$1" 2>/dev/null
}

# Settle any dpkg transaction left mid-flight by a previous interrupted run.
dpkg --configure -a 2>/dev/null || true

# Find whatever's currently installed, in any state - not just fully
# "installed" - so a previously half-finished update still gets handled.
current_package_name=""
current_status=""
for pkg in "${package_names[@]}"; do
    status=$(package_status "$pkg")
    if [ -n "$status" ] && [ "$status" != "not-installed" ]; then
        current_package_name="$pkg"
        current_status="$status"
        break
    fi
done

if [ -z "$current_package_name" ]; then
    echo "No existing package found; installing $new_package_name fresh."
elif [ "$current_package_name" = "$new_package_name" ]; then
    # Same package: let dpkg upgrade it in place. dpkg calls the old prerm
    # with "upgrade" (a no-op in this package) instead of "remove", so
    # services/boot config/initramfs are never torn down mid-update.
    echo "Found $current_package_name ($current_status); upgrading in place."
else
    echo "Found $current_package_name ($current_status); replacing with $new_package_name."
    apt-get purge -y "$current_package_name"
fi

echo "Installing $new_package_file_path..."
dpkg -i "$new_package_file_path" || true
apt-get install -f -y

# Restore the user's eth0 config if it was removed above (only possible when
# the previously-installed version still shipped the file). Skip the reload
# entirely if nothing actually changed, so a routine update - which never
# touches this file anymore - doesn't flap the network link.
if [ -f "$NM_ETH0_BACKUP" ] && ! cmp -s "$NM_ETH0_BACKUP" "$NM_ETH0" 2>/dev/null; then
    echo "Restoring pre-update eth0 network configuration..."
    cp -a "$NM_ETH0_BACKUP" "$NM_ETH0"
    chmod 600 "$NM_ETH0"
    nmcli connection reload
    nmcli connection up eth0 2>/dev/null || echo "WARNING: could not bring eth0 back up after restoring its config." >&2
fi
rm -f "$NM_ETH0_BACKUP"

# Check the installed version, not just the status - a corrupt/unreadable
# .deb can make dpkg -i fail before touching anything, leaving the old
# version "installed" and this script none the wiser without this check.
final_status=$(package_status "$new_package_name")
final_version=$(dpkg-query -W -f='${Version}' "$new_package_name" 2>/dev/null)
if [ "$final_status" = "installed" ] && [ "$final_version" = "$new_package_version" ]; then
    echo "Package installation completed: $new_package_name $final_version"
    exit 0
else
    echo "Installation failed: $new_package_name is '${final_status:-not present}' at version '${final_version:-none}' (expected $new_package_version)." >&2
    exit 1
fi
