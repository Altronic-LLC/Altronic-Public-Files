#!/bin/bash
#
# merge-device-profiles.sh <seed-dump.rdb>
#
# Refreshes Modbus device profiles shipped with a package update without
# clobbering the rest of the live Redis database (RS485 settings and any
# other user-configurable state MDI-Gateway keeps in Redis).
#
# Device profiles aren't user-editable, and new ones (or new registers on
# existing ones) sometimes have to ship with a firmware update. Everything
# else in Redis is live, user-set state and must survive an update untouched.
#
# On a genuinely first install (no live database yet) there's nothing to
# preserve, so the shipped snapshot is installed wholesale. Otherwise, only
# keys whose name contains "deviceProfile" are copied from the shipped
# snapshot into the live database, overwriting any same-named key there;
# every other live key is left alone.
#
# How the merge works: load the shipped snapshot into a throwaway Redis
# instance, then use MIGRATE ... COPY REPLACE to copy just the matching keys
# into the live instance over the wire. This works regardless of whether a
# key is a string, hash, list, etc. - it moves Redis's own serialized
# representation, not a reinterpretation of it - so it doesn't need to know
# the internal shape MDI-Gateway uses for a device profile.

SEED_RDB="$1"
LIVE_RDB=/var/lib/redis/dump.rdb
LIVE_HOST=127.0.0.1
LIVE_PORT=6379
KEY_PATTERN='*deviceProfile*'
TMP_PORT=16399

log() { echo "[merge-device-profiles] $*"; }

if [ -z "$SEED_RDB" ] || [ ! -f "$SEED_RDB" ]; then
    log "No seed dump ($SEED_RDB) found; nothing to do."
    exit 0
fi

if ! command -v redis-server >/dev/null 2>&1 || ! command -v redis-cli >/dev/null 2>&1; then
    log "WARNING: redis-server/redis-cli not found; skipping device profile refresh."
    exit 0
fi

if [ ! -f "$LIVE_RDB" ]; then
    # Fresh board / first install: no live state to preserve.
    log "No existing Redis database found; installing shipped snapshot wholesale."
    systemctl stop redis
    cp "$SEED_RDB" "$LIVE_RDB"
    chown redis:redis "$LIVE_RDB"
    systemctl start redis
    exit 0
fi

TMPDIR=$(mktemp -d /tmp/device-profile-merge.XXXXXX) || exit 1
cleanup() {
    redis-cli -p "$TMP_PORT" shutdown nosave >/dev/null 2>&1 || true
    rm -rf "$TMPDIR"
}
trap cleanup EXIT

cp "$SEED_RDB" "$TMPDIR/dump.rdb"

log "Starting a throwaway Redis instance to read the shipped snapshot..."
redis-server --port "$TMP_PORT" --bind 127.0.0.1 --daemonize yes \
    --dir "$TMPDIR" --dbfilename dump.rdb --save '' --appendonly no \
    --pidfile "$TMPDIR/redis.pid" --logfile "$TMPDIR/redis.log"

ready=false
for _ in $(seq 1 40); do
    if redis-cli -p "$TMP_PORT" ping >/dev/null 2>&1; then
        ready=true
        break
    fi
    sleep 0.25
done

if [ "$ready" != true ]; then
    log "WARNING: throwaway Redis instance did not come up; leaving live device profiles untouched."
    exit 1
fi

mapfile -t KEYS < <(redis-cli -p "$TMP_PORT" --scan --pattern "$KEY_PATTERN")

if [ ${#KEYS[@]} -eq 0 ]; then
    log "No keys matching '$KEY_PATTERN' in the shipped snapshot; nothing to refresh."
    exit 0
fi

log "Refreshing ${#KEYS[@]} device profile key(s) in the live database..."
if redis-cli -p "$TMP_PORT" MIGRATE "$LIVE_HOST" "$LIVE_PORT" "" 0 5000 COPY REPLACE KEYS "${KEYS[@]}"; then
    redis-cli -h "$LIVE_HOST" -p "$LIVE_PORT" SAVE >/dev/null 2>&1 || \
        redis-cli -h "$LIVE_HOST" -p "$LIVE_PORT" BGSAVE >/dev/null 2>&1 || true
    log "Device profile refresh complete."
else
    log "WARNING: MIGRATE failed; live device profiles were not modified."
    exit 1
fi
