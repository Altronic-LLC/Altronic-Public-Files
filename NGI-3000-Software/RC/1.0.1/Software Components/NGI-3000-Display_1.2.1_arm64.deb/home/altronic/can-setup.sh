#!/bin/bash
# can-setup.sh up|down: brings can0 (mcp251xfd on spi0-0) up at the bitrate in
# mdi-settings canBitrate (kbps, default 500), or leaves it down when
# canEnabled is "false". MDI-Gateway's J1939 node and NGI-3000-Display-Forwarder
# read the same fields. Runs as root from ngi-can.service.

IFACE=can0
DEFAULT_KBPS=500

setting() { redis-cli HGET mdi-settings "$1" 2>/dev/null; }

if [ "$1" = "down" ]; then
    ip link set "$IFACE" down 2>/dev/null
    exit 0
fi

# Without Redis the settings are unknown: the user may have disabled CAN or
# chosen another bitrate, so leave the port down rather than guess.
for _ in $(seq 1 30); do
    [ "$(redis-cli ping 2>/dev/null)" = "PONG" ] && break
    sleep 1
done
if [ "$(redis-cli ping 2>/dev/null)" != "PONG" ]; then
    ip link set "$IFACE" down 2>/dev/null
    echo "redis unreachable: CAN settings unknown, $IFACE left down"
    exit 0
fi

enabled=$(setting canEnabled | tr '[:upper:]' '[:lower:]')
if [ "$enabled" = "false" ]; then
    ip link set "$IFACE" down 2>/dev/null
    echo "CAN disabled (canEnabled=false); $IFACE left down"
    exit 0
fi

# The SPI controller can finish probing after this unit starts. A board
# without one is not an error: nothing waits on this unit.
for _ in $(seq 1 30); do
    [ -e "/sys/class/net/$IFACE" ] && break
    sleep 1
done
if [ ! -e "/sys/class/net/$IFACE" ]; then
    echo "$IFACE not present: the CAN controller driver did not probe (dmesg | grep -iE 'mcp25|spi'); CAN unavailable"
    exit 0
fi

ip link set "$IFACE" down 2>/dev/null

kbps=$(setting canBitrate)
case "$kbps" in
    125|250|500|1000) ;;
    *) kbps=$DEFAULT_KBPS ;;
esac

# restart-ms recovers from bus-off on its own, slowly enough that a port
# wired to a bus at the wrong bitrate disturbs it once a second at most; the
# deeper queue absorbs a J1939 transport burst without ENOBUFS.
ip link set "$IFACE" type can bitrate $((kbps * 1000)) restart-ms 1000 || exit 1
ip link set "$IFACE" txqueuelen 128
ip link set "$IFACE" up || exit 1
echo "$IFACE up at $kbps kbit/s"
