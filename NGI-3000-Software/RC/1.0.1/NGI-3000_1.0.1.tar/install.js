#!/usr/bin/env node
'use strict';
// NGI-3000 bundle installer. Ships inside the bundle and is launched by the
// config tool as a detached systemd unit (root), so it survives the config
// tool being stopped/restarted by the Logic CM4 package install.
//
// Order: Display ST -> Display CM4 (only if the Display is reachable),
//        then Logic ST -> Logic CM4, then reboot whatever changed.
//
// Plain Node (no dependencies, Node 12+ syntax) so it runs on any board image.

const fs = require('fs');
const path = require('path');
const net = require('net');
const http = require('http');
const crypto = require('crypto');
const { spawn } = require('child_process');

const env = process.env;
const CONFIG = {
  stagingDir: __dirname,
  updateDir: env.NGI_UPDATE_DIR || '/home/altronic/ngi3000-update',
  homeDir: env.NGI_HOME_DIR || '/home/altronic',
  displayHost: env.NGI_DISPLAY_HOST || '169.254.254.3',
  displayUser: 'altronic',
  sshKey: env.NGI_SSH_KEY || '/home/altronic/.ssh/id_rsa',
  // ssh/scp run as this user so they use its key; empty = current user.
  sshAsUser: env.NGI_SSH_AS_USER !== undefined ? env.NGI_SSH_AS_USER : 'altronic',
  modbusBase: env.NGI_MODBUS_BASE || 'http://127.0.0.1:8080',
  rebootCmd: env.NGI_REBOOT_CMD || 'systemctl reboot',
  bootIdPath: env.NGI_BOOT_ID_PATH || '/proc/sys/kernel/random/boot_id',
  stPollIntervalMs: Number(env.NGI_ST_POLL_MS || 1000),
  stStartTimeoutMs: Number(env.NGI_ST_START_TIMEOUT_MS || 10000),
  stStallTimeoutMs: Number(env.NGI_ST_STALL_TIMEOUT_MS || 5000),
  stOverallTimeoutMs: Number(env.NGI_ST_OVERALL_TIMEOUT_MS || 5 * 60 * 1000),
  rebootDelayMs: Number(env.NGI_REBOOT_DELAY_MS || 3000),
  displayPollMs: Number(env.NGI_DISPLAY_POLL_MS || 1000),
  displayDownTimeoutMs: Number(env.NGI_DISPLAY_DOWN_TIMEOUT_MS || 60 * 1000),
  displayUpTimeoutMs: Number(env.NGI_DISPLAY_UP_TIMEOUT_MS || 4 * 60 * 1000),
};
const STATUS_PATH = path.join(CONFIG.updateDir, 'status.json');
const LOG_PATH = path.join(CONFIG.updateDir, 'install.log');
// Same path on both boards; the Display's copy lives on the Display so it follows that hardware.
const ST_RECORD_PATH = path.join(CONFIG.homeDir, 'ngi3000-update', 'st-firmware.json');
const DISPLAY_ST_RECORD_PATH =
  env.NGI_DISPLAY_ST_RECORD_PATH || '/home/altronic/ngi3000-update/st-firmware.json';

const ST_BOOT_MAGIC = 27183;
const BOOTSTATE = { IDLE: 0, STARTING: 1, PREPARING: 2, FLASHING: 3, DONE: 4, ERROR: 5 };
const BOOTSTATE_TEXT = {
  0: 'Waiting for the bootloader to start',
  1: 'Bootloader starting',
  2: 'Bootloader preparing to flash',
  3: 'Flashing',
};
const ST_TARGETS = {
  logicST: {
    name: 'Logic ST',
    triggerAddr: 998,
    bootstateAddr: 2000,
    progressAddr: 213,
    progressIsFloat32: true,
    binPath: path.join(CONFIG.homeDir, 'usb1', 'NGI-3000-CRC.bin'),
  },
  displayST: {
    name: 'Display ST',
    triggerAddr: 3998,
    bootstateAddr: 3006,
    progressAddr: 3007,
    progressIsFloat32: false,
    binPath: '/home/altronic/usb1/NGI-3000-DISPLAY-CRC.bin',
  },
};

// ---------------------------------------------------------------- args
const args = process.argv.slice(2);
const argValue = name => {
  const i = args.indexOf(name);
  return i >= 0 ? args[i + 1] : undefined;
};
const FORCE = args.indexOf('--force') >= 0;
const MODBUS_NODE = parseInt(argValue('--modbus-node') || '1', 10) || 1;

// ---------------------------------------------------------------- logging/status
fs.mkdirSync(CONFIG.updateDir, { recursive: true });
try {
  fs.renameSync(LOG_PATH, path.join(CONFIG.updateDir, 'install.prev.log'));
} catch (e) {
  // No previous log.
}
function log(msg) {
  const line = `[${new Date().toISOString()}] ${msg}\n`;
  process.stdout.write(line);
  try {
    fs.appendFileSync(LOG_PATH, line);
  } catch (e) {
    // Logging must never break the install.
  }
}

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

const readBootId = () => {
  try {
    return fs.readFileSync(CONFIG.bootIdPath, 'utf8').trim();
  } catch (e) {
    return '';
  }
};

let manifest;
const status = {
  runId: env.NGI_RUN_ID || String(Date.now()),
  state: 'running',
  bundleVersion: '',
  force: FORCE,
  startedAt: new Date().toISOString(),
  updatedAt: '',
  finishedAt: null,
  currentStep: null,
  message: 'Starting update',
  progress: 0,
  error: null,
  displayConnected: null,
  // 'display' | 'logic' while that module is restarting, so the client can explain a lost connection.
  restarting: null,
  warning: null,
  reboot: { logic: false, display: false, bootId: readBootId() },
  steps: [
    {
      id: 'displayST',
      label: 'Display Module ST firmware',
      state: 'pending',
      detail: '',
      progress: 0,
    },
    {
      id: 'displayCM4',
      label: 'Display Module CM4 software',
      state: 'pending',
      detail: '',
      progress: 0,
    },
    { id: 'logicST', label: 'Logic Module ST firmware', state: 'pending', detail: '', progress: 0 },
    {
      id: 'logicCM4',
      label: 'Logic Module CM4 software',
      state: 'pending',
      detail: '',
      progress: 0,
    },
  ],
};

function writeStatus() {
  const counted = status.steps.filter(s => s.state !== 'skipped');
  const done = counted.reduce((sum, s) => sum + (s.state === 'done' ? 100 : s.progress || 0), 0);
  status.progress = counted.length ? Math.round(done / counted.length) : 100;
  status.updatedAt = new Date().toISOString();
  const tmp = `${STATUS_PATH}.${process.pid}.tmp`;
  try {
    fs.writeFileSync(tmp, JSON.stringify(status, null, 2));
    fs.renameSync(tmp, STATUS_PATH);
  } catch (e) {
    log(`WARNING: could not write status: ${e.message}`);
  }
}

const step = id => status.steps.find(s => s.id === id);

function setStep(id, fields) {
  Object.assign(step(id), fields);
  if (fields.state === 'running') status.currentStep = id;
  if (fields.detail) status.message = `${step(id).label}: ${fields.detail}`;
  writeStatus();
}

class StepError extends Error {}

// ---------------------------------------------------------------- process helpers
function run(cmd, cmdArgs, options = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(cmd, cmdArgs, {
      env: Object.assign({}, process.env, options.env || {}),
      stdio: [options.input !== undefined ? 'pipe' : 'ignore', 'pipe', 'pipe'],
    });
    let stdout = '';
    let stderr = '';
    let timer;
    let settled = false;
    if (options.timeoutMs) {
      timer = setTimeout(() => child.kill('SIGKILL'), options.timeoutMs);
    }
    child.stdout.on('data', d => {
      stdout += d;
    });
    child.stderr.on('data', d => {
      stderr += d;
    });
    if (options.input !== undefined) child.stdin.end(options.input);
    child.on('error', err => {
      settled = true;
      clearTimeout(timer);
      reject(err);
    });
    // A daemon restarted by the child can inherit its stdout and keep the pipe open
    // long after the child exits, so 'exit' (plus a short drain) also ends the wait.
    const finish = code => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (code === 0 || options.allowFailure) {
        resolve({ code, stdout, stderr });
      } else {
        const out = (stderr || stdout).trim().split('\n').slice(-5).join(' | ');
        reject(new Error(`${path.basename(cmd)} exited with code ${code}${out ? `: ${out}` : ''}`));
      }
    };
    child.on('exit', code => setTimeout(() => finish(code), 1000));
    child.on('close', finish);
  });
}

const sh = (script, options) => run('/bin/sh', ['-c', script], options);
const shellQuote = s => `'${String(s).replace(/'/g, `'\\''`)}'`;

const asSshUser = (cmd, cmdArgs) =>
  CONFIG.sshAsUser
    ? ['runuser', ['-u', CONFIG.sshAsUser, '--', cmd].concat(cmdArgs)]
    : [cmd, cmdArgs];

// Host-key options mirror the Logic's ssh_config.d drop-in, which may not be installed yet
// when the Display steps run (the Logic CM4 step comes after them).
const SSH_OPTS = () => [
  '-i',
  CONFIG.sshKey,
  '-o',
  'BatchMode=yes',
  '-o',
  'ConnectTimeout=10',
  '-o',
  'StrictHostKeyChecking=no',
  '-o',
  'UserKnownHostsFile=/dev/null',
  '-o',
  'GlobalKnownHostsFile=/dev/null',
  '-o',
  'LogLevel=ERROR',
];

function displaySsh(remoteCommand, options = {}) {
  const [cmd, cmdArgs] = asSshUser(
    'ssh',
    SSH_OPTS().concat([`${CONFIG.displayUser}@${CONFIG.displayHost}`, remoteCommand])
  );
  return run(cmd, cmdArgs, Object.assign({ timeoutMs: 10 * 60 * 1000 }, options));
}

function displayScp(localPath, remotePath) {
  const [cmd, cmdArgs] = asSshUser(
    'scp',
    SSH_OPTS().concat([localPath, `${CONFIG.displayUser}@${CONFIG.displayHost}:${remotePath}`])
  );
  return run(cmd, cmdArgs, { timeoutMs: 10 * 60 * 1000 });
}

function isDisplayReachable(timeoutMs = 2000) {
  return new Promise(resolve => {
    const socket = new net.Socket();
    const done = result => {
      socket.destroy();
      resolve(result);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => done(true));
    socket.once('timeout', () => done(false));
    socket.once('error', () => done(false));
    socket.connect(22, CONFIG.displayHost);
  });
}

function httpGetJson(url, timeoutMs = 3000) {
  return new Promise((resolve, reject) => {
    const req = http.get(url, res => {
      let body = '';
      res.on('data', d => {
        body += d;
      });
      res.on('end', () => {
        if (res.statusCode >= 400) {
          reject(new Error(`HTTP ${res.statusCode} from ${url}`));
          return;
        }
        try {
          resolve(body ? JSON.parse(body) : null);
        } catch (e) {
          resolve(body);
        }
      });
    });
    req.setTimeout(timeoutMs, () => req.destroy(new Error(`Timed out requesting ${url}`)));
    req.on('error', reject);
  });
}

async function readRegister(addr) {
  const data = await httpGetJson(`${CONFIG.modbusBase}/fc/${MODBUS_NODE}/4/${addr}/1`);
  const value = data && data[addr];
  if (typeof value !== 'number')
    throw new Error(`Modbus response did not include register ${addr}`);
  return value;
}

// Logic FWPROG is the high word of a FLOAT32.
function highWordToFloat32(word) {
  const buf = Buffer.alloc(4);
  buf.writeUInt32BE(((word & 0xffff) << 16) >>> 0, 0);
  return buf.readFloatBE(0);
}

function sha256File(filePath) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash('sha256');
    fs.createReadStream(filePath)
      .on('data', d => hash.update(d))
      .on('error', reject)
      .on('end', () => resolve(hash.digest('hex')));
  });
}

// Pulls one helper script out of the bundle's Logic .deb, so the newest copy is used.
async function extractFromLogicDeb(relPath, destPath, fallbackPath) {
  const deb = path.join(CONFIG.stagingDir, manifest.components.logicCM4.file);
  try {
    await sh(
      `dpkg-deb --fsys-tarfile ${shellQuote(deb)} | tar -xO ${shellQuote(`./${relPath}`)} > ${shellQuote(destPath)}`
    );
    if (fs.statSync(destPath).size > 0) {
      fs.chmodSync(destPath, 0o755);
      return destPath;
    }
  } catch (e) {
    log(
      `Could not extract ${relPath} from the Logic package (${e.message}); using installed copy.`
    );
  }
  fs.copyFileSync(fallbackPath, destPath);
  fs.chmodSync(destPath, 0o755);
  return destPath;
}

// ---------------------------------------------------------------- version records
const sameStRecord = (record, component) =>
  !!record && record.version === component.version && record.sha256 === component.sha256;

function readLogicStRecord() {
  try {
    return JSON.parse(fs.readFileSync(ST_RECORD_PATH, 'utf8'));
  } catch (e) {
    return null;
  }
}

function writeLogicStRecord(record) {
  fs.mkdirSync(path.dirname(ST_RECORD_PATH), { recursive: true });
  const tmp = `${ST_RECORD_PATH}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(record, null, 2));
  fs.renameSync(tmp, ST_RECORD_PATH);
}

async function readDisplayStRecord() {
  const result = await displaySsh(`cat ${DISPLAY_ST_RECORD_PATH} 2>/dev/null || true`);
  try {
    return JSON.parse(result.stdout);
  } catch (e) {
    return null;
  }
}

function writeDisplayStRecord(record) {
  const p = DISPLAY_ST_RECORD_PATH;
  return displaySsh(`mkdir -p ${path.posix.dirname(p)} && cat > ${p}.tmp && mv ${p}.tmp ${p}`, {
    input: JSON.stringify(record, null, 2),
  });
}

const stRecordFor = component => ({
  version: component.version,
  sha256: component.sha256,
  bundleVersion: manifest.bundleVersion,
  flashedAt: new Date().toISOString(),
});

async function installedVersionLocal(pkg) {
  const r = await run('dpkg-query', ['-W', '-f=${db:Status-Status} ${Version}', pkg], {
    allowFailure: true,
  });
  const [state, version] = r.stdout.trim().split(' ');
  return state === 'installed' ? version : null;
}

async function installedVersionDisplay(pkg) {
  const r = await displaySsh(
    `dpkg-query -W -f='\${db:Status-Status} \${Version}' ${pkg} 2>/dev/null || true`
  );
  const [state, version] = r.stdout.trim().split(' ');
  return state === 'installed' ? version : null;
}

// ---------------------------------------------------------------- ST flashing
async function flashST(stepId) {
  const target = ST_TARGETS[stepId];
  const writeUrl = `${CONFIG.modbusBase}/fc/1/6/${target.triggerAddr}/1/${ST_BOOT_MAGIC}`;

  let startState = BOOTSTATE.IDLE;
  try {
    startState = await readRegister(target.bootstateAddr);
  } catch (e) {
    log(`Could not read ${target.name} boot state before triggering: ${e.message}`);
  }
  // A DONE/ERROR left over from an earlier attempt must not be mistaken for this run's result.
  const staleTerminal = startState === BOOTSTATE.DONE || startState === BOOTSTATE.ERROR;

  log(
    `Triggering ${target.name} bootloader (${writeUrl}); boot state before trigger: ${startState}`
  );
  await httpGetJson(writeUrl, 5000);

  const startTime = Date.now();
  let lastProgress;
  let lastProgressChange = Date.now();
  let failures = 0;
  let sawActive = false;

  for (;;) {
    if (Date.now() - startTime >= CONFIG.stOverallTimeoutMs) {
      throw new StepError(`${target.name} update timed out waiting for the bootloader to finish.`);
    }
    let bootState;
    let progress;
    try {
      bootState = await readRegister(target.bootstateAddr);
      const raw = await readRegister(target.progressAddr);
      progress = target.progressIsFloat32 ? highWordToFloat32(raw) : Number(raw);
      if (!isFinite(progress)) progress = 0;
      progress = Math.max(0, Math.min(100, progress));
      failures = 0;
    } catch (e) {
      failures += 1;
      log(`${target.name} status poll failed (${failures}): ${e.message}`);
      if (failures >= 3) {
        throw new StepError(`Lost communication with the ${target.name} bootloader.`);
      }
      await sleep(CONFIG.stPollIntervalMs);
      continue;
    }

    const active = bootState >= BOOTSTATE.STARTING && bootState <= BOOTSTATE.FLASHING;
    if (active) sawActive = true;

    if (bootState === BOOTSTATE.DONE && (sawActive || !staleTerminal)) {
      setStep(stepId, { progress: 100, detail: 'Flash complete' });
      return;
    }
    if (bootState === BOOTSTATE.ERROR && (sawActive || !staleTerminal)) {
      throw new StepError(`The ${target.name} bootloader reported an error.`);
    }
    if (!sawActive && Date.now() - startTime >= CONFIG.stStartTimeoutMs) {
      throw new StepError(
        `The ${target.name} bootloader did not start within ${Math.round(CONFIG.stStartTimeoutMs / 1000)} seconds.`
      );
    }

    if (bootState === BOOTSTATE.FLASHING) {
      if (progress !== lastProgress) {
        lastProgress = progress;
        lastProgressChange = Date.now();
      } else if (
        Date.now() - lastProgressChange >=
        (progress === 0 ? 2 : 1) * CONFIG.stStallTimeoutMs
      ) {
        throw new StepError(`The ${target.name} update stalled at ${Math.round(progress)}%.`);
      }
    } else {
      lastProgress = progress;
      lastProgressChange = Date.now();
    }

    const text = BOOTSTATE_TEXT[bootState] || 'Checking bootloader status';
    const shown = bootState === BOOTSTATE.FLASHING ? progress : 0;
    setStep(stepId, {
      progress: Math.round(shown),
      detail: bootState === BOOTSTATE.FLASHING ? `${text} (${Math.round(progress)}%)` : text,
    });
    await sleep(CONFIG.stPollIntervalMs);
  }
}

// ---------------------------------------------------------------- steps
async function installDisplayST() {
  const c = manifest.components.displayST;
  if (!FORCE && sameStRecord(await readDisplayStRecord(), c)) {
    setStep('displayST', { state: 'skipped', detail: `Already at ${c.version}` });
    return false;
  }
  setStep('displayST', { state: 'running', detail: 'Copying firmware to the Display Module' });
  const target = ST_TARGETS.displayST;
  await displaySsh(`mkdir -p ${path.posix.dirname(target.binPath)}`);
  await displayScp(path.join(CONFIG.stagingDir, c.file), target.binPath);
  await flashST('displayST');
  await writeDisplayStRecord(stRecordFor(c));
  setStep('displayST', { state: 'done', progress: 100, detail: `Installed ${c.version}` });
  return true;
}

async function installDisplayCM4() {
  const c = manifest.components.displayCM4;
  const installed = await installedVersionDisplay(c.package);
  if (!FORCE && installed === c.version) {
    setStep('displayCM4', { state: 'skipped', detail: `Already at ${c.version}` });
    return false;
  }
  setStep('displayCM4', {
    state: 'running',
    progress: 10,
    detail: `Copying package ${c.version} to the Display Module`,
  });
  const localScript = await extractFromLogicDeb(
    'home/altronic/updateDisplayCM4.sh',
    path.join(CONFIG.updateDir, 'updateDisplayCM4.sh'),
    path.join(CONFIG.homeDir, 'updateDisplayCM4.sh')
  );
  const remoteDir = '/home/altronic/uploads';
  const remoteScript = '/home/altronic/updateDisplayCM4.sh';
  const remoteDeb = `${remoteDir}/${c.file}`;
  await displaySsh(`mkdir -p ${remoteDir}`);
  await displayScp(localScript, remoteScript);
  await displaySsh(`chmod +x ${remoteScript}`);
  await displayScp(path.join(CONFIG.stagingDir, c.file), remoteDeb);
  setStep('displayCM4', { progress: 40, detail: `Installing package ${c.version}` });
  try {
    const r = await displaySsh(`sudo ${remoteScript} ${shellQuote(remoteDeb)}`);
    log(r.stdout.trim());
  } finally {
    await displaySsh(`rm -f ${shellQuote(remoteDeb)}`, { allowFailure: true }).catch(() => {});
  }
  const after = await installedVersionDisplay(c.package);
  if (after !== c.version) {
    throw new StepError(
      `Display CM4 reports version '${after || 'none'}' after install, expected ${c.version}.`
    );
  }
  setStep('displayCM4', { state: 'done', progress: 100, detail: `Installed ${c.version}` });
  return true;
}

async function installLogicST() {
  const c = manifest.components.logicST;
  if (!FORCE && sameStRecord(readLogicStRecord(), c)) {
    setStep('logicST', { state: 'skipped', detail: `Already at ${c.version}` });
    return false;
  }
  setStep('logicST', { state: 'running', detail: 'Copying firmware' });
  const target = ST_TARGETS.logicST;
  fs.mkdirSync(path.dirname(target.binPath), { recursive: true });
  fs.copyFileSync(path.join(CONFIG.stagingDir, c.file), target.binPath);
  await run('chown', ['-R', 'altronic:altronic', path.dirname(target.binPath)], {
    allowFailure: true,
  }).catch(() => {});
  await flashST('logicST');
  writeLogicStRecord(stRecordFor(c));
  setStep('logicST', { state: 'done', progress: 100, detail: `Installed ${c.version}` });
  return true;
}

async function installLogicCM4() {
  const c = manifest.components.logicCM4;
  const installed = await installedVersionLocal(c.package);
  if (!FORCE && installed === c.version) {
    setStep('logicCM4', { state: 'skipped', detail: `Already at ${c.version}` });
    return false;
  }
  setStep('logicCM4', {
    state: 'running',
    progress: 20,
    detail: `Installing package ${c.version}. The config tool will restart.`,
  });
  // The update script deletes its own script and .deb when it finishes, so hand it copies.
  const script = await extractFromLogicDeb(
    'home/altronic/updateLogicModuleCM4.sh',
    path.join(CONFIG.updateDir, 'updateLogicModuleCM4.run.sh'),
    path.join(CONFIG.homeDir, 'updateLogicModuleCM4.sh')
  );
  const debCopy = path.join(CONFIG.updateDir, `logic-${process.pid}.deb`);
  fs.copyFileSync(path.join(CONFIG.stagingDir, c.file), debCopy);
  // Stage 2 runs the purge/install in-process; this unit is already detached from config_tool.
  const r = await run('/bin/bash', [script, debCopy], {
    env: { NGI_UPDATE_STAGE2: '1' },
    allowFailure: true,
    timeoutMs: 20 * 60 * 1000,
  });
  const after = await installedVersionLocal(c.package);
  if (r.code !== 0 || after !== c.version) {
    const tail = await sh('tail -n 15 /var/log/ngi-logic-update.log', { allowFailure: true }).catch(
      () => ({ stdout: '' })
    );
    log(tail.stdout);
    throw new StepError(
      `Logic CM4 install failed (exit ${r.code}, installed version '${after || 'none'}', expected ${c.version}).`
    );
  }
  setStep('logicCM4', { state: 'done', progress: 100, detail: `Installed ${c.version}` });
  return true;
}

async function verifyBundle() {
  manifest = JSON.parse(fs.readFileSync(path.join(CONFIG.stagingDir, 'manifest.json'), 'utf8'));
  status.bundleVersion = manifest.bundleVersion;
  writeStatus();
  for (const id of ['displayST', 'displayCM4', 'logicST', 'logicCM4']) {
    const c = manifest.components[id];
    if (!c) throw new StepError(`Bundle manifest is missing the ${id} component.`);
    const digest = await sha256File(path.join(CONFIG.stagingDir, c.file));
    if (digest !== c.sha256) throw new StepError(`Checksum mismatch for ${c.file}.`);
  }
}

// ---------------------------------------------------------------- main
async function rebootDisplay() {
  log('Rebooting the Display Module.');
  await displaySsh('sudo reboot', { allowFailure: true, timeoutMs: 15000 }).catch(() => {});
}

// Waits for the Display to drop off and come back so the run only finishes once
// a client connected through the Display's eth0 can reach the config tool again.
async function waitForDisplayRestart() {
  const downBy = Date.now() + CONFIG.displayDownTimeoutMs;
  while (Date.now() < downBy && (await isDisplayReachable(1000))) {
    await sleep(CONFIG.displayPollMs);
  }
  const upBy = Date.now() + CONFIG.displayUpTimeoutMs;
  while (Date.now() < upBy) {
    if (await isDisplayReachable(1000)) {
      log('Display Module is back online.');
      return true;
    }
    await sleep(CONFIG.displayPollMs);
  }
  log('WARNING: the Display Module did not come back online after restarting.');
  return false;
}

function cleanStaging() {
  for (const id of Object.keys(manifest.components)) {
    try {
      fs.unlinkSync(path.join(CONFIG.stagingDir, manifest.components[id].file));
    } catch (e) {
      // Already gone.
    }
  }
}

async function main() {
  log(`=== NGI-3000 bundle install started (force=${FORCE}, modbus node=${MODBUS_NODE}) ===`);
  writeStatus();
  await verifyBundle();
  log(`Bundle ${manifest.bundleVersion} verified.`);

  status.message = 'Checking for the Display Module';
  writeStatus();
  let displayConnected = false;
  for (let attempt = 0; attempt < 3 && !displayConnected; attempt++) {
    displayConnected = await isDisplayReachable();
  }
  status.displayConnected = displayConnected;
  log(`Display Module ${displayConnected ? 'connected' : 'not detected'}.`);

  if (displayConnected) {
    const stChanged = await installDisplayST();
    const cm4Changed = await installDisplayCM4();
    // The Display restart is held until the Logic steps are done (or have failed), so a
    // client connected through the Display's eth0 isn't cut off in the middle of the update.
    status.reboot.display = stChanged || cm4Changed;
    writeStatus();
  } else {
    for (const id of ['displayST', 'displayCM4']) {
      setStep(id, { state: 'skipped', detail: 'Display Module not connected' });
    }
  }

  const logicStChanged = await installLogicST();
  const logicCm4Changed = await installLogicCM4();
  status.reboot.logic = logicStChanged || logicCm4Changed;
  cleanStaging();

  if (status.reboot.display) {
    status.currentStep = null;
    status.restarting = 'display';
    status.message = 'Restarting the Display Module';
    writeStatus();
    await sleep(CONFIG.rebootDelayMs);
    await rebootDisplay();
    if (!(await waitForDisplayRestart())) {
      status.warning =
        'The Display Module did not come back online after restarting. Check its power and network link.';
    }
    status.restarting = null;
  }

  status.state = 'complete';
  status.currentStep = null;
  status.finishedAt = new Date().toISOString();
  const anyChange = status.reboot.logic || status.reboot.display;
  status.message = !anyChange
    ? 'Everything is already up to date.'
    : status.reboot.logic
      ? 'Update complete. Restarting the Logic Module.'
      : 'Update complete.';
  if (status.reboot.logic) status.restarting = 'logic';
  writeStatus();
  log(`=== ${status.message} ===`);

  if (status.reboot.logic) {
    await sleep(CONFIG.rebootDelayMs);
    log(`Rebooting: ${CONFIG.rebootCmd}`);
    await sh(CONFIG.rebootCmd, { allowFailure: true });
  }
}

main().catch(async err => {
  log(`ERROR: ${err.stack || err.message}`);
  const current = status.currentStep && step(status.currentStep);
  if (current) current.state = 'error';
  status.state = 'error';
  status.error = err.message;
  status.message = err.message;
  status.finishedAt = new Date().toISOString();
  // status.reboot.display is only set once both Display steps succeeded, so this never
  // restarts a Display whose own install failed. Give the client a moment to read the error first.
  if (status.reboot.display) {
    status.restarting = 'display';
    status.warning = 'The Display Module is restarting to finish applying its update.';
  }
  writeStatus();
  process.exitCode = 1;
  if (status.reboot.display) {
    await sleep(CONFIG.rebootDelayMs);
    await rebootDisplay();
  }
});
