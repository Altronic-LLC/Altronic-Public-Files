ECHO "current ports are"
$COMportList = [System.IO.Ports.SerialPort]::getportnames() 
ForEach ($COMport in $COMportList) { 
$temp = new-object System.IO.Ports.SerialPort $COMport 
echo $temp.PortName 
$temp.Dispose() 
}

$userport= Read-Host -Prompt 'Input the COM port as COM#'
$port= new-Object System.IO.Ports.SerialPort $userport,1200,None,8,one
$port.open()
$port.Close()
ECHO "COM port may have changed"
ECHO "Waiting for 10 seconds"
Start-Sleep -Seconds 10

ECHO "current COM ports are"
$COMportList = [System.IO.Ports.SerialPort]::getportnames() 
ForEach ($COMport in $COMportList) { 
$temp = new-object System.IO.Ports.SerialPort $COMport 
echo $temp.PortName 
$temp.Dispose() 
}
