#!/bin/bash

# Check if the file path argument is provided
if [ $# -eq 0 ]; then
    echo "Please provide the file path as an argument."
    exit 1
fi

# Define the new package name based on the file name argument
new_package_file_path="$1"
new_package_name=$(basename "$new_package_file_path" | cut -d'_' -f1 | tr '[:upper:]' '[:lower:]')

# List of possible package names
package_names=(
    "$new_package_name"
    "dcpm-scanner"
    "ngi-5000-dcpm"
)

echo "Potential package names: ${package_names[@]}"

is_package_installed() {
    dpkg-query -W -f='${Status}' "$1" 2>/dev/null | grep -q "install ok installed"
}

# Find the currently installed package name
for pkg in "${package_names[@]}"; do
    if is_package_installed "$pkg"; then
        current_package_name="$pkg"
        echo "Found currently installed package: $current_package_name"
        echo "Uninstalling $current_package_name..."
        apt-get purge -y $current_package_name
        package_found=true
        break
    fi
done

if [ "$package_found" != true ]; then
    echo "No package found to uninstall."
    exit 1
fi

echo "Installing $new_package_file_path..."
dpkg -i $new_package_file_path
apt-get install -f -y

echo "Package installation completed."
exit 0