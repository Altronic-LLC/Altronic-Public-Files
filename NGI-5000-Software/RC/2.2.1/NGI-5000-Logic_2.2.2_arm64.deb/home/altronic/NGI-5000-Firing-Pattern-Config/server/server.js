const fs = require('fs');
const fsPromises = require('fs/promises');
const http = require('http');
const crypto = require('crypto');
const path = require('path');
const multer = require('multer');
const express = require('express');
const app = express();
const { execSync, exec, execFileSync } = require('child_process');
const ipaddr = require('ipaddr.js');
const Transform = require('stream').Transform;
const { NodeSSH } = require('node-ssh');

const httpServer = http.createServer(app);

const PORT = process.env.PORT || 80;
httpServer.listen(PORT, () => {
  console.log(`Web Server listening on *:${PORT}`);
});

app.use('/', express.static(path.join(__dirname, '../client/dist')));
app.use(express.json());

const UPLOADS_DIR = '/home/altronic/uploads'; // Directory to store uploaded files
const MAX_UPLOAD_FILES = 8; // Maximum number of uploaded files to keep

// Generate a unique filename for uploaded files
function generateUploadFilename(originalname) {
  const ext = path.extname(originalname || '').toLowerCase();
  const originalNameWithoutExt = path.basename(originalname || '', ext);

  const rand = crypto.randomBytes(8).toString('hex');
  const timestamp = Date.now();

  return `${originalNameWithoutExt}-${timestamp}-${rand}${ext}`;
}

// Ensure uploads directory exists
try {
  if (!fs.existsSync(UPLOADS_DIR)) {
    fs.mkdirSync(UPLOADS_DIR, { recursive: true });
    console.log(`Created uploads directory at ${UPLOADS_DIR}`);
  }
} catch (err) {
  console.error(`Error ensuring uploads directory exists: ${err}`);
}

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, UPLOADS_DIR);
  },
  filename: function (req, file, cb) {
    // Generate a unique file name. The original file name is still available as file.originalname
    cb(null, generateUploadFilename(file.originalname));
  },
});

const upload = multer({ storage: storage });

async function pruneUploadsDir() {
  try {
    const entries = await fsPromises.readdir(UPLOADS_DIR, {
      withFileTypes: true,
    });

    const files = await Promise.all(
      entries
        .filter(file => file.isFile())
        .map(async file => {
          const filePath = path.join(UPLOADS_DIR, file.name);
          const stats = await fsPromises.stat(filePath);
          return { name: file.name, path: filePath, mtime: stats.mtime };
        })
    );

    // Sort files by modification time, newest first
    files.sort((a, b) => b.mtime - a.mtime);

    const filesToDelete = files.slice(MAX_UPLOAD_FILES);
    for (const file of filesToDelete) {
      console.log(`Deleting old upload file: ${file.name}`);
      await fsPromises.unlink(file.path);
    }
  } catch (err) {
    console.error('Error pruning uploads directory:', err);
  }
}

const withPrune = handler => async (req, res) => {
  try {
    await handler(req, res);
  } finally {
    // Prune uploads directory after handling the request
    pruneUploadsDir();
  }
};

// Every 6 hours, prune the uploads directory as a safety measure in case the upload endpoints fail
setInterval(pruneUploadsDir, 6 * 60 * 60 * 1000);

function validateUploadedFilePath(uploadedFilePath, uploadsDir) {
  if (!uploadedFilePath || typeof uploadedFilePath !== 'string') {
    throw new Error('Invalid upload path');
  }

  // Resolve symlinks
  const absoluteUploadsDir = fs.realpathSync(uploadsDir);
  const absoluteUploadedFilePath = fs.realpathSync(uploadedFilePath);

  // Ensure the uploaded file path is within the uploads directory
  if (!absoluteUploadedFilePath.startsWith(absoluteUploadsDir + path.sep)) {
    throw new Error('Uploaded file path is outside of uploads directory');
  }

  // Check that the uploaded file is not a symlink
  const lstat = fs.lstatSync(uploadedFilePath);
  if (lstat.isSymbolicLink()) {
    throw new Error('Uploaded file is a symbolic link');
  }

  // Check that the uploaded file is a regular file and not empty
  const stat = fs.statSync(absoluteUploadedFilePath);
  if (!stat.isFile()) {
    throw new Error('Uploaded file is not a file');
  }
  if (stat.size <= 0) {
    throw new Error('Uploaded file is empty');
  }

  return absoluteUploadedFilePath;
}

function validateAndGetUploadedFilePath(file, expectedExtension) {
  if (!file) {
    const error = new Error('No update file selected');
    error.statusCode = 400;
    throw error;
  }

  const ext = path.extname(file.originalname || '').toLowerCase();
  if (ext !== expectedExtension) {
    const error = new Error(`Invalid file type. Please select a ${expectedExtension} file.`);
    error.statusCode = 400;
    throw error;
  }

  try {
    return validateUploadedFilePath(file.path, UPLOADS_DIR);
  } catch (e) {
    const error = new Error(`Uploaded file validation failed: ${e.message}`);
    error.statusCode = 400;
    throw error;
  }
}

// Wrapper function to use exec with Promises to maintain compatibility with node v12
// If compatibility is not needed, execAsync can be used directly
const execPromise = command => {
  return new Promise((resolve, reject) => {
    exec(command, (err, stdout, stderr) => {
      if (err) {
        reject(err); // Reject if there's an error
      } else {
        resolve(stdout || stderr); // Resolve with output
      }
    });
  });
};

// Save config file
app.post('/configLogicModule', async (req, res) => {
  console.log('Running /configLogicModule');

  const outputModule = req.body.selectedOutputModule
    ? req.body.selectedOutputModule.name
    : undefined;

  if (!outputModule || !['NGI5K', 'CPU2K'].includes(outputModule)) {
    console.log('Invalid output module:', outputModule);
    return res.status(500).json({
      status: 'error',
      message: 'Invalid output module',
      error: 'Output module must be NGI5K or CPU2K',
    });
  }

  // Save config file
  const configPath = '/home/altronic/config.json';
  try {
    await fsPromises.writeFile(configPath, JSON.stringify(req.body));
    console.log('Successfully wrote config file');
  } catch (err) {
    console.error('Error writing config file:', err);
    return res.status(500).json({
      status: 'error',
      message: 'Error writing config file',
      error: err,
    });
  }

  // Prepare screen folder
  console.log('Preparing screens folder...');
  const folderName = outputModule === 'CPU2K' ? 'cpu-2000' : 'ngi-5000';
  const screensDir = '/home/altronic/awi-screens';

  if (fs.existsSync(screensDir)) {
    // NOTE: this function is deprecated, but is necessary for compatibility with node v12.
    // This currently works on newer versions of node, but the recommended syntax is:
    //   fs.rmSync('/home/altronic/awi-screens', { recursive: true, force: true });
    fs.rmdirSync(screensDir, { recursive: true });
  }

  try {
    await fsPromises.mkdir(screensDir, { recursive: true });
    console.log('Screens folder created successfully');
  } catch (err) {
    console.error('Error creating screens folder:', err);
    return res.status(500).json({
      status: 'error',
      message: 'Error creating screens folder',
      error: err,
    });
  }

  try {
    replaceLabels(folderName, req.body);
  } catch (replaceErr) {
    console.error('Error on replace and copy screens:', replaceErr);
    return res.status(500).json({
      status: 'error',
      message: 'Error on replace and copy screens',
      error: replaceErr,
    });
  }

  // Set ownership
  try {
    await fsPromises.chown(screensDir, 1000, 1000);
    console.log('Ownership set successfully');
  } catch (err) {
    console.error('Error setting ownership:', err);
    return res.status(500).json({
      status: 'error',
      message: 'Error setting ownership',
      error: err,
    });
  }

  // Flush filesystem buffer
  try {
    await execPromise('sync');
  } catch (err) {
    console.error('Error flushing filesystem buffer:', err);
    return res.status(500).json({
      status: 'error',
      message: 'Error flushing filesystem buffer',
      error: err,
    });
  }

  console.log('Logic Module configuration process completed successfully');
  res.json({ status: 'success', message: 'Config received' });
});

app.post('/configDCPM', async (req, res) => {
  console.log('Running /configDCPM');

  const outputModule = req.body.selectedOutputModule
    ? req.body.selectedOutputModule.name
    : undefined;
  const configPath = '/home/altronic/config.json';

  if (!outputModule || outputModule !== 'NGI5K') {
    console.log('Output module is not NGI5K, skipping DCPM configuration');
    return res.json({
      status: 'success',
      message: 'Output module is not NGI5K, skipping DCPM configuration',
    });
  }

  // Copy config
  try {
    console.log('Copying config to DCPM...');
    await execPromise(`scp ${configPath} altronic@192.168.1.3:${configPath}`);
    console.log('Config copied successfully');
  } catch (err) {
    console.error('Error copying config to DCPM:', err);
    return res.json({
      status: 'error',
      message: 'Error copying config to DCPM',
      error: err,
    });
  }

  // Restart scanner service
  try {
    console.log('Restarting DCPM scanner service...');
    await execPromise(`ssh altronic@192.168.1.3 "sudo systemctl restart dcpm_scanner.service"`);
    console.log('DCPM scanner service restarted successfully');
  } catch (err) {
    console.error('Error restarting DCPM scanner service:', err);
    return res.json({
      status: 'error',
      message: 'Error restarting DCPM scanner service',
      error: err,
    });
  }

  res.json({ status: 'success', message: 'DCPM config updated' });
});

const replaceLabels = (folderName, body) => {
  const files = fs.readdirSync(`/home/altronic/template-screens/${folderName}`);
  if (!files) {
    console.error(`WARNING: No files present in ${folderName} directory.`);
    return;
  }
  files.forEach(file => {
    const data = fs.readFileSync(`/home/altronic/template-screens/${folderName}/${file}`, 'utf8');
    if (!data) {
      console.error('Error on read template file, data:', data);
      return;
    }
    let text = data;
    if (body && body.firingPatternData) {
      for (let i = 1; i <= body.firingPatternData.fire_a.length * 2; i++) {
        const regex = new RegExp(`\\*C${i}\\*`, 'g');
        const ab = i % 2 === 1 ? 'fire_a' : 'fire_b';
        const angle = body.firingPatternData[ab][Math.floor((i - 1) / 2)].angle;
        const label = body.firingPatternData[ab][Math.floor((i - 1) / 2)].label;
        //Use != instead of !== in case angle is undefined
        if (label && angle != null) {
          text = text.replace(regex, label);
        }
      }
    }
    const fileName = file.slice(0, file.lastIndexOf('.'));
    fs.writeFileSync(`/home/altronic/awi-screens/${fileName}.html`, text);
    fs.chownSync(`/home/altronic/awi-screens/${fileName}.html`, 1000, 1000);
  });
};

// Send config file
app.get('/fetch', (req, res) => {
  console.log('Running /fetch');

  fs.readFile('/home/altronic/config.json', 'utf8', (err, data) => {
    if (err) {
      console.log('Error reading config file', err);
      return res.status(500).json({ status: 'error', message: 'Error reading config file' });
    }

    try {
      const parsedData = JSON.parse(data);
      console.log('Successfully read config file: \n', parsedData);
      res.json(parsedData);
    } catch (parseErr) {
      console.error('Error parsing config file JSON:', parseErr);
      return res.status(500).json({ status: 'error', message: 'Error parsing config file JSON' });
    }
  });
});

app.get('/load', (req, res) => {
  console.log('Running /load');

  fs.readFile('/home/altronic/NGI5000.FPD', 'utf8', (err, data) => {
    if (err) {
      console.log('Error reading FPD file', err);
      res.sendStatus(404);
    } else {
      console.log('Successfully read FPD file: \n', data);
      res.send(data);
    }
  });
});

app.post(
  '/saveFPDFile',
  upload.single('firingPatternDataFile'),
  withPrune((req, res) => {
    console.log('Running /saveFPDFile');

    try {
      if (!req.file) {
        return res.status(400).json({ status: 'error', error: 'No file uploaded' });
      }

      const targetPath = '/home/altronic/NGI5000.FPD';
      const tempPath = targetPath + '.tmp';

      fs.readFile(req.file.path, (readErr, data) => {
        if (readErr) {
          console.error('Error reading uploaded FPD file from disk:', readErr);
          return res.status(500).json({
            status: 'error',
            error: 'Failed to read uploaded FPD file',
          });
        }

        // Write to a temporary file first
        fs.writeFile(tempPath, data, writeErr => {
          if (writeErr) {
            console.error('Error writing FPD file:', writeErr);
            return res.status(500).json({ status: 'error', error: 'Failed to write FPD file' });
          }

          // Rename the temporary file to the target path
          fs.rename(tempPath, targetPath, renameErr => {
            if (renameErr) {
              console.error('Error renaming FPD file:', renameErr);
              return res.status(500).json({
                status: 'error',
                error: 'Failed to move FPD file into place',
              });
            }

            console.log('FPD file saved successfully');
            res.json({
              status: 'success',
              message: 'FPD file saved successfully',
            });
          });
        });
      });
    } catch (error) {
      console.error('Unexpected error in /saveFPDFile:', error);
      res.status(500).json({ status: 'error', error: 'Unexpected server error' });
    }
  })
);

app.get('/awi/', (req, res) => {
  console.log('Running /awi/');

  res.redirect('/awi/index.html');
});

app.get('/awi/:fname', (req, res) => {
  console.log('Running /awi/:fname with params:', req.params);

  const replacementTransform = new Transform();
  replacementTransform._transform = function (data, encoding, done) {
    // Using replace instead of replaceAll for compatibility with older Node.js versions
    const str = data.toString().replace(/localhost/g, `192.168.1.2`);
    this.push(str);
    done();
  };

  let stream = fs.createReadStream('/home/altronic/awi-screens/' + req.params.fname);
  stream
    .pipe(replacementTransform)
    .on('end', () => {})
    .pipe(res);
});

app.get('/awi_edit/:fname', (req, res) => {
  console.log('Running /awi_edit/:fname with params:', req.params);

  const data = fs.readFileSync('/home/altronic/awi-screens/' + req.params.fname, {
    encoding: 'utf8',
    flag: 'r',
  });
  //let str = data
  // Using replace instead of replaceAll for compatibility with older Node.js versions
  let str = data.replace(/localhost/g, '192.168.1.2');
  //let str2 = str
  //let str2 = str.replace('window.EJECTED_LOCKED = true', 'window.EJECTED_LOCKED = false')
  let str2 = str.replace(
    'window.EJECTED = true\nwindow.EJECTED_LOCKED = true',
    'window.EJECTED = false\nwindow.EJECTED_LOCKED = false'
  );
  res.send(str2);
});

app.get('/getComms', (req, res) => {
  console.log('Running /getComms');

  const COMMS_DEFAULTS = {
    WiFi_Host: 'false',
    WiFi_Enabled: 'false',
    WiFi_SSID: 'NGI5000',
    WiFi_Password: 'altronic',
    WiFi_Client_SSID: '',
    WiFi_Client_Password: '',
    Gbt_Eth_Use_DHCP: 'true',
    Gbt_Eth_IP_Address: '192.168.1.1',
    Gbt_Eth_Netmask: '255.255.255.0',
    Gbt_Eth_Gateway: '0.0.0.0',
    RS485_Baud: '9600',
    RS485_Node: '1',
  };
  const comms = getCommsSettings(COMMS_DEFAULTS);
  res.send(comms);
});

const getCommsSettings = comms => {
  //Read data from NetworkManager to set up Wi-Fi and Ethernet
  try {
    const wlan0Connections = getwlan0Connections();

    if (wlan0Connections.length > 0) {
      const wlan0Info = wlan0Connections[0];
      const connectionName = wlan0Info.split(':')[0];
      console.log(`Connection '${connectionName}' associated with 'wlan0' found`);

      const deviceStatus = execSync(
        `sudo nmcli -t -f 802-11-wireless.mode connection show '${connectionName}'`,
        { encoding: 'utf8' }
      );
      const isApMode = deviceStatus.includes('ap');
      comms.WiFi_Enabled = 'true';
      comms.WiFi_Host = isApMode ? 'true' : 'false';

      const ssid = execSync(
        `sudo nmcli -g 802-11-wireless.ssid connection show ${connectionName}`,
        { encoding: 'utf8' }
      ).trim();
      const password = execSync(
        `sudo nmcli -s -g 802-11-wireless-security.psk connection show ${connectionName}`,
        { encoding: 'utf8' }
      ).trim();
      if (comms.WiFi_Host === 'true') {
        comms.WiFi_SSID = ssid;
        const regex = /./g;
        comms.WiFi_Password = password.replace(regex, '\u25cf');
      } else {
        comms.WiFi_Client_SSID = ssid;
        comms.WiFi_Client_Password = password;
      }
    } else {
      comms.WiFi_Enabled = 'false';
    }
  } catch (exception) {
    console.error(exception);
  }

  try {
    const connections = execSync('sudo nmcli -t -f NAME connection show').toString().split('\n');
    const eth0Exists = connections.includes('eth0');

    if (eth0Exists) {
      const ipv4Method = execSync('sudo nmcli -t -f ipv4.method connection show eth0')
        .toString()
        .replace('ipv4.method:', '')
        .trim();
      comms.Gbt_Eth_Use_DHCP = ipv4Method === 'auto' ? 'true' : 'false';

      if (comms.Gbt_Eth_Use_DHCP === 'false') {
        const ipInfo = execSync('sudo nmcli -t -f ipv4.addresses connection show eth0')
          .toString()
          .replace('ipv4.addresses:', '')
          .trim();
        const [ip, prefix] = ipInfo.split('/');
        const gateway = execSync('sudo nmcli -t -f ipv4.gateway connection show eth0')
          .toString()
          .replace('ipv4.gateway:', '')
          .trim();

        comms.Gbt_Eth_IP_Address = ip;
        const prefixNum = parseInt(prefix, 10);
        comms.Gbt_Eth_Netmask =
          ipaddr.IPv4.subnetMaskFromPrefixLength(prefixNum).toNormalizedString();
        if (gateway) comms.Gbt_Eth_Gateway = gateway;
      } else {
        comms.Gbt_Eth_Use_DHCP = 'true';
      }
    } else {
      comms.Gbt_Eth_Use_DHCP = 'true';
    }
  } catch (exception) {
    console.error(exception);
  }
  // Aaron added setting of modbus:
  try {
    const modbusFile = fs.readFileSync('/home/altronic/modbusconfig.json', 'utf8');
    const modbusConfig = JSON.parse(modbusFile);
    comms.RS485_Node = modbusConfig.nodeID;
    comms.RS485_Baud = modbusConfig.baudRate;
  } catch (exception) {
    console.error(exception);
  }

  return comms;
};

app.post('/saveComms', (req, res) => {
  console.log('Running /saveComms with body:', req.body);

  res.send(saveCommsToSystem(req.body));
});

const getwlan0Connections = () => {
  try {
    const connections = execSync('sudo nmcli -t -f NAME,DEVICE connection show', {
      encoding: 'utf8',
    });
    const lines = connections.split('\n');
    const wlan0Connections = lines.filter(line => line.includes('wlan0'));
    console.log(`Found ${wlan0Connections.length} connections associated with 'wlan0'`);
    return wlan0Connections;
  } catch (exception) {
    console.error(exception.message);
    return [];
  }
};

const disconnectwlan0 = errors => {
  try {
    const wlan0Connections = getwlan0Connections();
    if (wlan0Connections.length > 0) {
      wlan0Connections.forEach(wlan0Info => {
        // Get the connection name stored in the first column
        const connectionName = wlan0Info.split(':')[0];
        console.log(`Deleting connection '${connectionName}' associated with 'wlan0'...`);
        execSync(`sudo nmcli connection delete ${connectionName}`);
        console.log(`Connection '${connectionName}' deleted`);
      });
    } else {
      console.log("Connection 'wlan0' does not exist");
    }
  } catch (exception) {
    console.error(exception.message);
    errors.push(exception.message);
  }
};

const saveCommsToSystem = message => {
  const errors = [];
  // initializing a JavaScript object
  let modbusConfig = {
    nodeID: 1,
    baudRate: 9600,
  };
  modbusConfig.nodeID = Number(message.RS485_Node);
  modbusConfig.baudRate = Number(message.RS485_Baud);
  const data = JSON.stringify(modbusConfig);
  // writing the JSON string content to a file
  try {
    fs.writeFileSync('/home/altronic/modbusconfig.json', data);
  } catch (error) {
    console.error(`Error writing modbusconfig.json: ${error}`);
    errors.push(error.message);
  }

  try {
    execSync('sudo sync');
  } catch (exception) {
    console.error(exception);
    errors.push(exception.message);
  }

  try {
    execSync('sudo /usr/bin/systemctl restart mb485_proxy');
  } catch (exception) {
    console.error(exception);
    errors.push(exception.message);
  }

  // Handle Wi-Fi Comms
  if (message.WiFi_Enabled !== 'true') {
    disconnectwlan0(errors);
  } else if (message.WiFi_Host === 'true') {
    disconnectwlan0(errors);
    try {
      execSync(
        `sudo nmcli connection add type wifi ifname wlan0 con-name wlan0 autoconnect yes ssid "${message.WiFi_SSID}"`
      );
      execSync('sudo nmcli connection modify wlan0 wifi.mode ap');
      execSync('sudo nmcli connection modify wlan0 wifi.band bg');
      execSync('sudo nmcli connection modify wlan0 wifi-sec.key-mgmt wpa-psk');
      execSync(`sudo nmcli connection modify wlan0 wifi-sec.psk "${message.WiFi_Password}"`);
      execSync('sudo nmcli connection modify wlan0 ipv4.method shared');
      execSync('sudo nmcli connection modify wlan0 ipv4.addresses 10.1.101.10/24');
      console.log("Host connection 'wlan0' added");
      execSync('sudo nmcli connection up wlan0');
      console.log("Host connection 'hotspot' added successfully");
    } catch (exception) {
      console.error(exception);
      errors.push(exception.message);
    }
  } else {
    disconnectwlan0(errors);
    try {
      execSync(
        `sudo nmcli connection add type wifi con-name wlan0 ifname wlan0 ssid "${message.WiFi_Client_SSID}"`
      );
      execSync(`sudo nmcli connection modify wlan0 wifi-sec.key-mgmt wpa-psk`);
      execSync(`sudo nmcli connection modify wlan0 wifi-sec.psk "${message.WiFi_Client_Password}"`);
      console.log("Client connection 'wlan0' added");
      execSync('sudo nmcli connection up wlan0');
      console.log("Client connection 'wlan0' added successfully");
    } catch (exception) {
      console.error(exception);
      errors.push(exception.message);
    }
  }

  // Handle Ethernet Comms
  try {
    const connections = execSync('sudo nmcli connection show', {
      encoding: 'utf8',
    });
    const eth0Exists = connections.includes('eth0');
    console.log("Connection 'eth0' exists, deleting...");

    if (eth0Exists) {
      execSync('sudo nmcli connection delete eth0');
      console.log("Connection 'eth0' deleted");
    }
  } catch (exception) {
    console.log(exception.message);
  }

  if (message.Gbt_Eth_Use_DHCP === 'true') {
    try {
      execSync(
        'sudo nmcli connection add type ethernet con-name eth0 ifname eth0 ipv4.method auto'
      );
      console.log("Connection 'eth0' added with DHCP");
    } catch (exception) {
      console.error(`Error adding connection 'eth0': ${exception.message}`);
      errors.push(exception.message);
    }
  } else {
    try {
      execSync(
        `sudo nmcli connection add type ethernet con-name eth0 ifname eth0 ip4 ${
          message.Gbt_Eth_IP_Address
        }/${ipaddr.IPv4.parse(message.Gbt_Eth_Netmask).prefixLengthFromSubnetMask()} gw4 ${
          message.Gbt_Eth_Gateway
        }`
      );
      console.log("Connection 'eth0' added");
    } catch (exception) {
      console.error(`Error adding connection 'eth0': ${exception.message}`);
      errors.push(exception.message);
    }
  }

  try {
    execSync('sudo systemctl restart NetworkManager');
  } catch (exception) {
    console.error(exception);
    errors.push(exception.message);
  }

  return errors.length === 0 ? 'OK' : JSON.stringify(errors);
};

function trimColonSlash(stringToTrim) {
  if (stringToTrim) {
    const [, ipWithNetmask] = stringToTrim.split(':');
    if (ipWithNetmask) {
      const [trimmed_ip] = ipWithNetmask.split('/');
      return trimmed_ip;
    }
  }
  return '';
}

app.get('/getAssignedIPInfo', (req, res) => {
  console.log('Running /getAssignedIPInfo');

  const body = {
    gateway: '',
    netmask: '',
    ip: '',
    wlan0_ip: '',
  };

  try {
    // Get default gateway
    let gateway = '';
    const gateway1 = execSync("nmcli -t -f ipv4.gateway con show eth0 | cut -d ':' -f2")
      .toString('utf8')
      .trim();
    const gateway2 = execSync("nmcli -t -f IP4.GATEWAY dev show eth0 | cut -d ':' -f2")
      .toString('utf8')
      .trim();
    if (gateway1 !== '') {
      gateway = gateway1;
    }
    if (gateway2 !== '') {
      gateway = gateway2;
    }
    body.gateway = gateway;
  } catch (exception) {
    console.log(exception);
  }

  try {
    // Get IP address and netmask for eth0
    const eth0IPOutput1 = execSync('nmcli -t -f ipv4.addresses connection show eth0')
      .toString('utf8')
      .trim();
    const eth0IP1 = trimColonSlash(eth0IPOutput1);
    const eth0IPOutput2 = execSync('nmcli -t -f IP4.ADDRESS dev show eth0').toString('utf8').trim();
    const eth0IP2 = trimColonSlash(eth0IPOutput2);
    let eth0ip = '';
    let eth0IPOutput = '';
    if (eth0IP1 !== '') {
      eth0ip = eth0IPOutput1;
      eth0IPOutput = eth0IPOutput1;
    }
    if (eth0IP2 !== '') {
      eth0ip = eth0IPOutput2;
      eth0IPOutput = eth0IPOutput2;
    }

    if (eth0IPOutput) {
      const [, ipWithNetmask] = eth0IPOutput.split(':');
      const [trimmed_ip, netmask_bits] = ipWithNetmask.split('/');
      body.ip = trimmed_ip;
      body.netmask = ipaddr.IPv4.subnetMaskFromPrefixLength(
        parseInt(netmask_bits)
      ).toNormalizedString();
    } else {
      console.log('No IP address found for eth0');
    }
  } catch (exception) {
    console.log(exception);
  }

  try {
    // Get IP address for wlan0
    const wlan0IPOutput1 = execSync('nmcli -t -f ipv4.addresses connection show wlan0')
      .toString('utf8')
      .trim();
    const wlan0IP1 = trimColonSlash(wlan0IPOutput1);
    const wlan0IPOutput2 = execSync('nmcli -t -f IP4.ADDRESS dev show wlan0')
      .toString('utf8')
      .trim();
    const wlan0IP2 = trimColonSlash(wlan0IPOutput2);
    let wlan0IPOutput = '';
    let wlan0ip = '';

    if (wlan0IP1 !== '') {
      wlan0ip = wlan0IPOutput1;
      wlan0IPOutput = wlan0IPOutput1;
    }
    if (wlan0IP2 !== '') {
      wlan0ip = wlan0IPOutput2;
      wlan0IPOutput = wlan0IPOutput2;
    }

    if (wlan0IPOutput) {
      const [, wlan0IPWithNetmask] = wlan0IPOutput.split(':');
      const [wlan0TrimmedIP] = wlan0IPWithNetmask.split('/');
      body.wlan0_ip = wlan0TrimmedIP;
    } else {
      console.log('No IP address found for wlan0');
    }
  } catch (exception) {
    console.log('exception in get IP address for wlan0');
    console.log(exception);
  }

  res.send(body);
});

const findProperty = (text, property, hasEquals = true) => {
  const lines = text.split('\n');
  let startLine = '';
  lines.some(line => {
    const trimmed = line.trim();
    const startIndex = hasEquals
      ? Math.max(trimmed.indexOf(`${property}=`), trimmed.indexOf(`${property} =`))
      : trimmed.indexOf(property);
    if (startIndex === 0) {
      startLine = trimmed;
      return true;
    }
    return false;
  });
  if (startLine === '') {
    return undefined;
  }
  // const startLine = text.slice(startIndex);
  const breakIndex = startLine.indexOf(hasEquals ? '=' : ' ');
  if (breakIndex === -1) {
    return undefined;
  }
  const value = startLine.slice(hasEquals ? breakIndex + 1 : breakIndex);
  return value;
};

app.post(
  '/updateLogicModuleCM4',
  upload.single('logicModulePackage'),
  withPrune((req, res) => {
    console.log('Running /updateLogicModuleCM4');

    let validatedPath;
    try {
      validatedPath = validateAndGetUploadedFilePath(req.file, '.deb');
      console.log(`Selected update file: ${req.file.originalname}`);
      console.log(`Validated file path: ${validatedPath}`);
    } catch (error) {
      console.error('Uploaded file validation error:', error.message);
      res.status(error.statusCode || 400).json({ message: error.message, status: 'error' });
      return;
    }

    // Verify that the package name is correct and meant for the Logic Module
    try {
      let packageName = execFileSync('dpkg-deb', ['-f', validatedPath, 'Package'], {
        encoding: 'utf8',
      });
      if (!packageName) {
        console.error('Unable to determine package name from the selected .deb file.');
        res.status(400).json({
          message:
            "Unable to determine package name from the selected .deb file. The 'Package' field may be missing or malformed from the package metadata.",
          status: 'error',
        });
        return;
      }
      packageName = packageName.trim().toLowerCase();
      if (packageName !== 'ngi-5000-logic') {
        console.error(
          `Invalid package name '${packageName}' for installation on the Logic Module. Please select the correct Logic Module package for installation.`
        );
        res.status(400).json({
          message: `Invalid package name '${packageName}' for installation on the Logic Module. Please select the correct Logic Module package for installation.`,
          status: 'error',
        });
        return;
      }
    } catch (error) {
      console.error('Error verifying package name', error);
      res.status(500).json({ message: 'Error verifying package name', status: 'error' });
      return;
    }

    // Install the package
    try {
      if (!fs.existsSync(validatedPath)) {
        console.error(`Update file does not exist: ${validatedPath}`);
        res.status(500).json({ message: 'Update file missing', status: 'error' });
        return;
      }

      console.log(`Running 'sudo /home/altronic/updateLogicModuleCM4.sh <uploaded deb>'`);
      execFileSync('sudo', ['/home/altronic/updateLogicModuleCM4.sh', validatedPath], {
        stdio: 'inherit',
      });
      // console.log('Removing old package...');
      // execSync(`sudo apt-get purge -y iris-go`);
      // console.log('Installing new package...');
      // execSync(`sudo dpkg -i ${filePath}`);
      // execSync(`sudo apt-get install -f -y`);
      console.log('Package installed successfully, rebooting...');
      res.status(200).json({ message: 'Package installed successfully', status: 'success' });
      // Wait 5 seconds before restarting the device
      setTimeout(() => {
        try {
          execFileSync('sudo', ['reboot'], { stdio: 'ignore' });
        } catch (error) {
          console.error('Reboot command failed', error);
        }
      }, 5000);
    } catch (error) {
      console.error('Error installing package', error);
      res.status(500).json({ message: 'Error installing package', status: 'error' });
    }
  })
);

app.post(
  '/updateCIU',
  upload.single('ciuFirmware'),
  withPrune((req, res) => {
    console.log('Running /updateCIU');

    let filePath;
    try {
      filePath = validateAndGetUploadedFilePath(req.file, '.ciu');
      console.log(`Selected update file: ${req.file.originalname}`);
    } catch (error) {
      console.error('Uploaded file validation error:', error.message);
      res.status(error.statusCode || 400).json({ message: error.message, status: 'error' });
      return;
    }

    try {
      console.log('Starting CIU update...');
      console.log('Copying file to CIU...');
      execFileSync('scp', [filePath, 'altronic@192.168.1.3:/home/altronic/CIU.bin'], {
        stdio: 'inherit',
      });
      console.log('File copied to CIU, sending curl command to start update...');
      execFileSync('curl', ['http://192.168.1.3:8080/fc/1/6/9996/1/999'], {
        stdio: 'inherit',
      });

      res.status(200).json({
        message: 'CIU update completed successfully',
        status: 'success',
      });
    } catch (error) {
      console.error('Error updating CIU', error);
      res.status(500).json({ message: 'CIU update error', status: 'error' });
    }
  })
);

app.post(
  '/updateLogicModuleST',
  upload.single('logicModuleSTFirmware'),
  withPrune((req, res) => {
    console.log('Running /updateLogicModuleST');

    let filePath;
    try {
      filePath = validateAndGetUploadedFilePath(req.file, '.bin');
      console.log(`Selected update file: ${req.file.originalname}`);
    } catch (error) {
      console.error('Uploaded file validation error:', error.message);
      res.status(error.statusCode || 400).json({ message: error.message, status: 'error' });
      return;
    }

    try {
      console.log('Updating ST firmware...');
      console.log('Making sure /home/altronic/usb1 exists...');
      execFileSync('mkdir', ['-p', '/home/altronic/usb1'], { stdio: 'inherit' });
      console.log('Copying file to directory...');
      execFileSync('cp', [filePath, '/home/altronic/usb1/NGI-5000-CRC.bin'], { stdio: 'inherit' });
      console.log('File copied, sending curl command to start update...');
      execFileSync('curl', ['http://192.168.1.2:8080/fc/1/6/998/1/27183'], { stdio: 'inherit' });
      console.log('ST firmware update started successfully');
      res.status(200).json({
        message: 'ST firmware update started successfully',
        status: 'success',
      });
    } catch (error) {
      console.error('Error updating ST firmware', error);
      res.status(500).json({ message: 'ST firmware update error', status: 'error' });
    }
  })
);

app.get('/packageVersion', (req, res) => {
  console.log('Running /packageVersion');

  try {
    const packageNames = ['iris-go', 'ngi-5000-logic'];
    let version = '';
    packageNames.some(packageName => {
      try {
        version = execSync(`dpkg-query -W -f='${'${Version}'}\n' ${packageName}`).toString().trim();
        return version.length > 0;
      } catch (error) {
        return false;
      }
    });
    console.log(`Package version found: ${version}`);
    res.status(200).json({ version });
  } catch (error) {
    console.error('Error getting package version', error);
    res.status(500).json({ message: 'Error getting package version', status: 'error' });
  }
});

app.post(
  '/updateDCPMPower',
  upload.single('dcpmPowerFirmware'),
  withPrune((req, res) => {
    console.log('Running /updateDCPMPower');

    let filePath;
    try {
      filePath = validateAndGetUploadedFilePath(req.file, '.dcpm');
      console.log(`Selected update file: ${req.file.originalname}`);
    } catch (error) {
      console.error('Uploaded file validation error:', error.message);
      res.status(error.statusCode || 400).json({ message: error.message, status: 'error' });
      return;
    }

    try {
      console.log('Starting DCPM power update...');
      console.log('Copying file to DCPM...');
      execFileSync('scp', [filePath, 'altronic@192.168.1.3:/home/altronic/DCPM.bin'], {
        stdio: 'inherit',
      });
      console.log('File copied to DCPM, sending curl command to start update...');
      execFileSync('curl', ['http://192.168.1.3:8080/fc/1/6/9995/1/999'], { stdio: 'inherit' });
      console.log('DCPM power update started successfully');
      res.status(200).json({
        message: 'DCPM power update started successfully',
        status: 'success',
      });
    } catch (error) {
      console.error('Error updating DCPM', error);
      res.status(500).json({ message: 'DCPM update error', status: 'error' });
    }
  })
);

app.post(
  '/updateDCPMCM4',
  upload.single('dcpmPackage'),
  withPrune((req, res) => {
    console.log('Running /updateDCPMCM4');

    const file = req.file;
    const dcpmIP = '192.168.1.3';
    const user = 'altronic';
    const dcpmUpdateScriptPath = '/home/altronic/updateDCPMCM4.sh';
    const dcpmUploadsDir = UPLOADS_DIR;
    const dcpmFilePath = path.posix.join(dcpmUploadsDir, file ? file.filename : '');
    const sshArgsBase = ['-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10'];
    let validatedPath;

    try {
      validatedPath = validateAndGetUploadedFilePath(req.file, '.deb');
      console.log(`Selected update file: ${req.file.originalname}`);
      console.log(`Validated file path: ${validatedPath}`);
    } catch (error) {
      console.error('Uploaded file validation error:', error.message);
      res.status(error.statusCode || 400).json({ message: error.message, status: 'error' });
      return;
    }

    // Verify that the package name is correct and meant for the DCPM CM4
    try {
      let packageName = execFileSync('dpkg-deb', ['-f', validatedPath, 'Package'], {
        encoding: 'utf8',
      });
      if (!packageName) {
        console.error('Unable to determine package name from the selected .deb file.');
        res.status(400).json({
          message:
            "Unable to determine package name from the selected .deb file. The 'Package' field may be missing or malformed from the package metadata.",
          status: 'error',
        });
        return;
      }
      packageName = packageName.trim().toLowerCase();
      if (packageName !== 'ngi-5000-dcpm') {
        console.error(
          `Invalid package name '${packageName}' for installation on the DCPM CM4. Please select the correct DCPM CM4 package for installation.`
        );
        res.status(400).json({
          message: `Invalid package name '${packageName}' for installation on the DCPM CM4. Please select the correct DCPM CM4 package.`,
          status: 'error',
        });
        return;
      }
    } catch (error) {
      console.error('Error verifying package name', error);
      res.status(500).json({ message: 'Error verifying package name', status: 'error' });
      return;
    }

    // Install the package
    try {
      console.log('DCPM update paths:');
      console.log(`  Local validated .deb: ${validatedPath}`);
      console.log(`  DCPM .deb path:     ${user}@${dcpmIP}:${dcpmFilePath}`);
      console.log(`  Installer script:     ${dcpmUpdateScriptPath}`);

      // Copy the installer script to the DCPM
      console.log('Copying installer script to DCPM...');
      execFileSync(
        'scp',
        [
          ...sshArgsBase,
          '/home/altronic/updateDCPMCM4.sh',
          `${user}@${dcpmIP}:${dcpmUpdateScriptPath}`,
        ],
        { stdio: 'inherit' }
      );

      // Set the script permissions
      console.log('Setting script permissions on DCPM...');
      execFileSync(
        'ssh',
        [...sshArgsBase, `${user}@${dcpmIP}`, 'chmod', '+x', dcpmUpdateScriptPath],
        {
          stdio: 'inherit',
        }
      );

      // Make sure the uploads directory exists on the DCPM
      console.log('Creating uploads directory on DCPM if it does not exist...');
      execFileSync('ssh', [...sshArgsBase, `${user}@${dcpmIP}`, 'mkdir', '-p', UPLOADS_DIR], {
        stdio: 'inherit',
      });

      // Copy the .deb file to the DCPM
      console.log('Copying .deb file to DCPM...');
      execFileSync('scp', [...sshArgsBase, validatedPath, `${user}@${dcpmIP}:${dcpmFilePath}`], {
        stdio: 'inherit',
      });

      // Run the installer script
      console.log(
        `Running installer: ssh ${user}@${dcpmIP} sudo ${dcpmUpdateScriptPath} ${dcpmFilePath}`
      );
      execFileSync(
        'ssh',
        [...sshArgsBase, `${user}@${dcpmIP}`, 'sudo', dcpmUpdateScriptPath, dcpmFilePath],
        {
          stdio: 'inherit',
        }
      );
      console.log('Package installed successfully, rebooting DCPM...');
      res.status(200).json({ message: 'Package installed successfully', status: 'success' });
      // Restart the DCPM
      execFileSync('ssh', [...sshArgsBase, `${user}@${dcpmIP}`, 'sudo', 'reboot'], {
        stdio: 'ignore',
      });
    } catch (error) {
      console.error('Error installing package', error);
      res.status(500).json({ message: 'Error installing package', status: 'error' });
    }
  })
);

app.post('/connectDCPM', async (req, res) => {
  console.log('Running /connectDCPM');

  // Verify that we can connect to the DCPM via SSH using key-based authentication
  // Some DCPM installations do not have a public key installed from the factory and still use password authentication
  // In this case, we will connect using password authentication and push the public key to the DCPM

  const host = '192.168.1.3';
  const user = 'altronic';
  const password = 'altronic';
  const sshDir = path.join(process.env.HOME, '.ssh');
  const pubKeyPath = path.join(sshDir, 'id_rsa.pub');

  try {
    // Check DCPM availability before attempting SSH connection
    try {
      console.log(`Pinging DCPM at ${host} to check availability...`);
      execSync(`ping -c 1 -W 1 ${host}`, { stdio: 'ignore' });
    } catch (pingError) {
      console.log(`DCPM at ${host} is unreachable.`);
      throw new Error(`DCPM at ${host} is unreachable: ${pingError.message}`);
    }

    // Add DCPM host to known_hosts to avoid authenticity prompt
    try {
      console.log(`Adding ${host} to known_hosts to avoid authenticity prompt...`);
      execSync(`ssh-keygen -R ${host} -f ${sshDir}/known_hosts`, {
        stdio: 'ignore',
      });
      execSync(`ssh-keyscan -H ${host} >> ${sshDir}/known_hosts`, {
        stdio: 'ignore',
      });
    } catch (hostKeyError) {
      console.error(`Error adding ${host} to known_hosts:`, hostKeyError);
      throw new Error(`Failed to add ${host} to known_hosts: ${hostKeyError.message}`);
    }

    // Check if key-based ssh already works
    try {
      console.log(`Testing key-based SSH login to DCPM at ${host}...`);
      const out = execSync(`ssh -o BatchMode=yes -o ConnectTimeout=5 ${user}@${host} "echo ok"`, {
        stdio: 'pipe',
      });
      if (out.toString().trim() === 'ok') {
        console.log('Key-based login already works');
        return res.json({
          status: 'success',
          message: 'SSH key already installed',
        });
      }
    } catch (e) {
      console.log('Key-based login failed, proceeding with password-based setup...');
    }

    // Connect with password to push the public key
    const ssh = new NodeSSH();
    try {
      await ssh.connect({ host, username: user, password });
      console.log('Connected to DCPM via password.');

      // Ensure .ssh directory exists with correct permissions
      await ssh.execCommand('mkdir -p ~/.ssh && chmod 700 ~/.ssh');

      // Check if public key exists
      if (!fs.existsSync(pubKeyPath)) {
        throw new Error(`Public key not found at ${pubKeyPath}`);
      }
      const publicKey = fs.readFileSync(pubKeyPath, 'utf8').replace(/'/g, "'\\''"); // escape single quotes
      console.log('Copying public key to DCPM authorized_keys...');
      await ssh.execCommand(
        `echo '${publicKey}' >> ~/.ssh/authorized_keys && chmod 600 ~/.ssh/authorized_keys`
      );
    } finally {
      ssh.dispose();
      console.log('Password SSH connection closed.');
    }

    // Verify that key-based login now works
    console.log('Verifying key-based SSH login...');
    const verify = execSync(`ssh -o BatchMode=yes -o ConnectTimeout=5 ${user}@${host} "echo ok"`, {
      stdio: 'pipe',
    });
    if (verify.toString().trim() === 'ok') {
      console.log('SSH key successfully installed and verified!');
      return res.json({
        status: 'success',
        message: 'SSH key installed and verified',
      });
    } else {
      throw new Error('Key-based login verification failed');
    }
  } catch (err) {
    console.error('DCPM SSH connection setup failed:', err);
    return res.status(500).json({
      status: 'error',
      message: 'DCPM SSH connection failed',
      error: err.message,
    });
  }
});
