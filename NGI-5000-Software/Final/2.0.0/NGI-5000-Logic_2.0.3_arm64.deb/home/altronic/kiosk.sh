#!/bin/bash
# Wait for the X server to be ready
export DISPLAY=:0
while ! xset q &>/dev/null; do
  sleep 1
done

while :
do
  chromium-browser --kiosk --force-device-scale-factor=1.4 --compact_on_every_full_gc=true --gc_global=true --predictable_gc_schedule=true --user-data-dir="/tmp/profile2" --window-position=0,0 ~/awi-screens/top.html &
  chromium-browser --kiosk --force-device-scale-factor=1.25 --compact_on_every_full_gc=true --gc_global=true --predictable_gc_schedule=true --user-data-dir="/tmp/profile1" --window-position=0,600  ~/awi-screens/bottom.html &
  sleep 43200
  sudo killall chromium-browser
done