#!/bin/bash
while :
do
inotifywait -e close_write /home/altronic/config.json
cp /home/altronic/config.json /home/altronic/engine_config_go/ngi5000_config.json
cd /home/altronic/engine_config_go/
/home/altronic/engine_config_go/engine_config_go
done
