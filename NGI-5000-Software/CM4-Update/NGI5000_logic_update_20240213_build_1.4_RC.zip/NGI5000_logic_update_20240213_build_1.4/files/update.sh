#!/bin/bash
echo "Beginning update"
echo .
sleep 1
echo "Clearing destination folders"
sudo rm -rf /home/altronic/mb485_proxy
sudo rm -rf /home/altronic/NGI-5000-Firing-Pattern-Config
sudo rm -rf /home/altronic/iris_go
sleep 1
echo "Unzipping folders"
sudo unzip -o -q  './files/*.zip' -d /
if [ -d /home/altronic/'~' ]; then
  sudo killall chromium-browser
  mv /home/altronic/'~' /home/altronic/pf
  rm -rf /home/altronic/pf
  rm -rf /home/altronic/profile1
  rm -rf /home/altronic/profile2
  rm -rf /home/altronic/profiles
fi
if ! [ -f /etc/network/interfaces.d/eth0 ]; then
  sudo cp ./files/eth0 /etc/network/interfaces.d/eth0
fi  
sudo chown -R altronic:altronic /home/altronic
sudo chown altronic:altronic /etc/network/interfaces.d/eth0
#clear
echo "Update Complete!"
sleep 1
echo .
sleep 1
echo .
sleep 1
echo .
read -n 1 -p "Press any key to Reboot: "
sudo reboot now
