#!/bin/bash
lxterminal --command=./files/update.sh
