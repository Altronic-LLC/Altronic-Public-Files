sudo rm -rf /home/altronic/mb485_proxy
sudo rm -rf /home/altronic/NGI-5000-Firing-Pattern-Config
sudo rm -rf /home/altronic/iris_go
sudo unzip -o -q  './files/*.zip' -d /
sudo chown -R altronic:altronic /home/altronic
#clear
echo "Update Complete!"
sleep 1
echo .
sleep 1
echo .
sleep 1
echo .
read -n 1 -p "Press any key to Reboot: "
sudo reboot now
