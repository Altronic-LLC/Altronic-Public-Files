const fs = require('fs')
const http = require('http');
const path = require('path');
const multer = require('multer');
const express = require('express')
const app = express()
const { execSync, exec } = require('child_process');
const ipaddr = require('ipaddr.js');
const Transform = require("stream").Transform


const httpServer = http.createServer(app);

const PORT = process.env.PORT || 80;
httpServer.listen(PORT, () => {
  console.log(`Web Server listening on *:${PORT}`);
});

app.use('/', express.static(path.join(__dirname, '../client/build')));
app.use(express.json());

// Save config file
app.post('/config', (req, res) => {
  const outputModule = req.body.selectedOutputModule ? req.body.selectedOutputModule.name : undefined;
  if(!outputModule || !(outputModule === "NGI5K" || outputModule === "CPU2K")){
    console.log('Error reading output', error)
    res.send('The output module could not be determined.');
    return;
  }

  let error;
  fs.writeFile('/home/altronic/config.json', JSON.stringify(req.body), err => {
    error = err;
  })

  if (error) {
    console.error('Error writing file', error)
    res.send('There was an error writing the file.');
    return;
  }
  console.log('Successfully wrote file')

  let folderName = "ngi-5000";
  if(outputModule == "CPU2K"){
    folderName = "cpu-2000"
  }

  if(fs.existsSync("/home/altronic/awi-screens")){
    // NOTE: this function is deprecated, but is necessary for compatibility with node v12.
    // This currently works on newer versions of node, but the recommended syntax is:
    //   fs.rmSync('/home/altronic/awi-screens', { recursive: true, force: true });
    fs.rmdirSync('/home/altronic/awi-screens', {recursive: true});
  }
  
  fs.mkdirSync("/home/altronic/awi-screens");
  try{
    replaceLabels(folderName, req.body);
  }
  catch(replaceErr){
    console.error("Error on replace and copy screens:", replaceErr)
  }

  // execSync("sudo chown -R altronic:altronic /home/altronic/awi-screens")
  fs.chownSync("/home/altronic/awi-screens", 1000, 1000);
  try{
    execSync("sync");
  }
  catch(exception){
    console.log(exception)
  }
  res.send('Config received');
});

const replaceLabels = (folderName, body) => {
  const files = fs.readdirSync(`/home/altronic/template-screens/${folderName}`)
    if(!files){
      console.error(`WARNING: No files present in ${folderName} directory.`)
      return;
    }
    files.forEach(file => {
      const data = fs.readFileSync(`/home/altronic/template-screens/${folderName}/${file}`, 'utf8');
      if(!data){
        console.error("Error on read template file, data:", data);
        return;
      }
      let text = data;
      if(body && body.firingPatternData){
        for(let i = 1; i <= body.firingPatternData.fire_a.length*2; i++){
          const regex = new RegExp(`\\*C${i}\\*`, "g");
          const ab = i % 2 === 1 ? "fire_a" : "fire_b"
          const angle = body.firingPatternData[ab][Math.floor((i-1)/2)].angle;
          const label = body.firingPatternData[ab][Math.floor((i-1)/2)].label;
          //Use != instead of !== in case angle is undefined
          if(label && angle != null){
            text = text.replace(regex, label)
          }
        }
      }
      const fileName = file.slice(0, file.lastIndexOf('.'));
      fs.writeFileSync(`/home/altronic/awi-screens/${fileName}.html`, text);
      fs.chownSync(`/home/altronic/awi-screens/${fileName}.html`, 1000, 1000);
    })
}


// Send config file
app.get('/fetch', (req, res) => {
  fs.readFile('home/altronic/config.json', 'utf8', (err, data) => {
    if (err) {
      console.log('Error reading file', err)
    } else {
      data = JSON.parse(data);
      console.log('Successfully read file: \n', data)
      res.send(data);
    }
  })
});

app.get('/load', (req, res) => {
  fs.readFile('/home/altronic/NGI5000.FPD', 'utf8', (err, data) => {
    if (err) {
      console.log('Error reading FPD file', err)
      res.sendStatus(404)
    } else {
      console.log('Successfully read file: \n', data)
      res.send(data);
    }
  })
})


app.get("/awi/", (req, res) => {
  res.redirect('/awi/index.html');
})


app.get("/awi/:fname", (req, res) => {
  const replacementTransform = new Transform()
  replacementTransform._transform = function(data, encoding, done) {
      const str = data.toString().replaceAll('localhost', `192.168.1.2`)
      this.push(str)
      done()
  }

  let stream = fs.createReadStream('/home/altronic/awi-screens/'+req.params.fname)
  stream.pipe(replacementTransform)
  .on('end', () => {
  }).pipe(res)
})

app.get("/awi_edit/:fname", (req, res) => {
  const data = fs.readFileSync('/home/altronic/awi-screens/'+req.params.fname,
    { encoding: 'utf8', flag: 'r' });
  //let str = data
  let str = data.replaceAll('localhost', '192.168.1.2')
  //let str2 = str
  //let str2 = str.replace('window.EJECTED_LOCKED = true', 'window.EJECTED_LOCKED = false')
  let str2 = str.replace('window.EJECTED = true\nwindow.EJECTED_LOCKED = true', 'window.EJECTED = false\nwindow.EJECTED_LOCKED = false')
  res.send(str2)
})

app.get('/getComms', (req, res) => {
  const COMMS_DEFAULTS = {
    WiFi_Host: 'false',
    WiFi_Enabled: 'false',
    WiFi_SSID: "NGI5000",
    WiFi_Password: "altronic",
    WiFi_Client_SSID: "",
    WiFi_Client_Password: "",
    Gbt_Eth_Use_DHCP: 'true',
    Gbt_Eth_IP_Address: '192.168.1.1',
    Gbt_Eth_Netmask: '255.255.255.0',
    Gbt_Eth_Gateway: '0.0.0.0',
    RS485_Baud: '9600',
    RS485_Node: '1',
  }
  const comms = getCommsSettings(COMMS_DEFAULTS);
  res.send(comms);
})

const getCommsSettings = (comms) => {
  //Read data from NetworkManager to set up Wi-Fi and Ethernet
  try {
    const wlan0Connections = getwlan0Connections();

    if (wlan0Connections.length > 0) {
      const wlan0Info = wlan0Connections[0];
      const connectionName = wlan0Info.split(':')[0];
      console.log(`Connection '${connectionName}' associated with 'wlan0' found`);

      const deviceStatus = execSync(`sudo nmcli -t -f 802-11-wireless.mode connection show '${connectionName}'`, { encoding: 'utf8' });
      const isApMode = deviceStatus.includes('ap');
      comms.WiFi_Enabled = "true";
      comms.WiFi_Host = isApMode ? "true" : "false";

      const ssid = execSync(`sudo nmcli -g 802-11-wireless.ssid connection show ${connectionName}`, { encoding: 'utf8' }).trim();
      const password = execSync(`sudo nmcli -s -g 802-11-wireless-security.psk connection show ${connectionName}`, { encoding: 'utf8' }).trim();
      if (comms.WiFi_Host === "true") {
        comms.WiFi_SSID = ssid;
        const regex = /./g;
        comms.WiFi_Password = password.replace(regex, "\u25cf");
      } else {
        comms.WiFi_Client_SSID = ssid;
        comms.WiFi_Client_Password = password;
      }
    } else {
      comms.WiFi_Enabled = "false";
    }
  } catch (exception) {
    console.error(exception);
  }

  try {
    const connections = execSync('sudo nmcli -t -f NAME connection show').toString().split('\n');
    const eth0Exists = connections.includes('eth0');

    if (eth0Exists) {
      const ipv4Method = execSync('sudo nmcli -t -f ipv4.method connection show eth0').toString().replace('ipv4.method:', '').trim();
      comms.Gbt_Eth_Use_DHCP = ipv4Method === 'auto' ? 'true' : 'false';
      
      if (comms.Gbt_Eth_Use_DHCP === 'false') {
        const ipInfo = execSync('sudo nmcli -t -f ipv4.addresses connection show eth0').toString().replace('ipv4.addresses:', '').trim();
        const [ip, prefix] = ipInfo.split('/'); 
        const gateway = execSync('sudo nmcli -t -f ipv4.gateway connection show eth0').toString().replace('ipv4.gateway:', '').trim();
        
        comms.Gbt_Eth_IP_Address = ip;
        comms.Gbt_Eth_Netmask = ipaddr.IPv4.subnetMaskFromPrefixLength(prefix).toNormalizedString();
        if (gateway)
          comms.Gbt_Eth_Gateway = gateway;
      } else {
        comms.Gbt_Eth_Use_DHCP = 'true';
      }
    } else {
      comms.Gbt_Eth_Use_DHCP = 'true';
    }
  } catch (exception) {
    console.error(exception);
  }
  // Aaron added setting of modbus:
  try {
    // Include fs module
    const fs = require('fs');
    modbusfile = fs.readFileSync('/home/altronic/modbusconfig.json', 'utf8')
    modbusconfig = JSON.parse(modbusfile);
    comms.RS485_Node = modbusconfig.nodeID;
    comms.RS485_Baud = modbusconfig.baudRate;
  } catch(exception) {
    console.error(exception);
  }
  
  

  return comms;
}

app.post('/saveComms', (req, res) => {
  res.send(saveCommsToSystem(req.body));
})

const getwlan0Connections = () => {
  try {
    const connections = execSync("sudo nmcli -t -f NAME,DEVICE connection show", { encoding: 'utf8' });
    const lines = connections.split('\n');
    const wlan0Connections = lines.filter((line) => line.includes("wlan0"));
    console.log(`Found ${wlan0Connections.length} connections associated with 'wlan0'`);
    return wlan0Connections;
  } catch (exception) {
    console.error(exception.message);
    return [];
  }
}

const disconnectwlan0 = () => {
  try {
    const wlan0Connections = getwlan0Connections();
    if (wlan0Connections.length > 0) {
      wlan0Connections.forEach((wlan0Info) => {
        // Get the connection name stored in the first column
        const connectionName = wlan0Info.split(':')[0];
        console.log(`Deleting connection '${connectionName}' associated with 'wlan0'...`);
        execSync(`sudo nmcli connection delete ${connectionName}`);
        console.log(`Connection '${connectionName}' deleted`);
      });
    } else {
      console.log("Connection 'wlan0' does not exist");
    }
  } catch (exception) {
    console.error(exception.message);
    errors.push(exception.message);
  }
}

const saveCommsToSystem = (message) => {
  const errors = []
  // initializing a JavaScript object
  modbusconfig = {
    nodeID: 1,
    baudRate: 9600,
  };
  modbusconfig.nodeID = Number(message.RS485_Node);
  modbusconfig.baudRate = Number(message.RS485_Baud);
  data = JSON.stringify(modbusconfig);
  // writing the JSON string content to a file
  fs.writeFile("/home/altronic/modbusconfig.json", data, (error) => {
    // throwing the error
    // in case of a writing problem
    if (error) {
      // logging the error
      console.error(error);
      // TODO: do something if there is an error writing
      errors.push(error);
    }
  });

  try {
     execSync("sudo sync");
  }  catch(exception) {
     console.error(exception);
     errors.push(exception.message);	
  }
	
  try {
    execSync("sudo /usr/bin/systemctl restart mb485_proxy")
  } catch(exception) {
    console.error(exception);
    errors.push(exception.message);
  }

  // Handle Wi-Fi Comms
  if (message.WiFi_Enabled !== 'true') {
    disconnectwlan0();
  }
  else if (message.WiFi_Host === 'true') {
    disconnectwlan0();
    try {
      execSync(`sudo nmcli connection add type wifi ifname wlan0 con-name wlan0 autoconnect yes ssid "${message.WiFi_SSID}"`);
      execSync('sudo nmcli connection modify wlan0 wifi.mode ap');
      execSync('sudo nmcli connection modify wlan0 wifi.band bg');
      execSync('sudo nmcli connection modify wlan0 wifi-sec.key-mgmt wpa-psk');
      execSync(`sudo nmcli connection modify wlan0 wifi-sec.psk "${message.WiFi_Password}"`);
      execSync('sudo nmcli connection modify wlan0 ipv4.method shared');
      execSync('sudo nmcli connection modify wlan0 ipv4.addresses 10.1.101.10/24');
      console.log("Host connection 'wlan0' added");
      execSync('sudo nmcli connection up wlan0');
      console.log("Host connection 'hotspot' added successfully");
    } catch(exception) {
      console.error(exception);
      errors.push(exception.message);
    }
  }
  else{
    disconnectwlan0();
    try {
      execSync(`sudo nmcli connection add type wifi con-name wlan0 ifname wlan0 ssid "${message.WiFi_Client_SSID}"`);
      execSync(`sudo nmcli connection modify wlan0 wifi-sec.key-mgmt wpa-psk`);
      execSync(`sudo nmcli connection modify wlan0 wifi-sec.psk "${message.WiFi_Client_Password}"`);
      console.log("Client connection 'wlan0' added");
      execSync("sudo nmcli connection up wlan0");
      console.log("Client connection 'wlan0' added successfully");
    } catch (exception) {
      console.error(exception);
      errors.push(exception.message);
    }
  }

  // Handle Ethernet Comms
  try {
    const connections = execSync("sudo nmcli connection show", { encoding: 'utf8' });
    const eth0Exists = connections.includes('eth0');
    console.log("Connection 'eth0' exists, deleting...");
    
    if (eth0Exists) {
      execSync("sudo nmcli connection delete eth0");
      console.log("Connection 'eth0' deleted");
    }
  } catch (exception) {
    console.log(exception.message);
  }

  if (message.Gbt_Eth_Use_DHCP === "true") {
    try {
      execSync("sudo nmcli connection add type ethernet con-name eth0 ifname eth0 ipv4.method auto");
      console.log("Connection 'eth0' added with DHCP");
    } catch (exception) {
      console.error(`Error adding connection 'eth0': ${exception.message}`);
      errors.push(exception.message);
    }
  } else {
    try {
      execSync(`sudo nmcli connection add type ethernet con-name eth0 ifname eth0 ip4 ${message.Gbt_Eth_IP_Address}/${ipaddr.IPv4.parse(message.Gbt_Eth_Netmask).prefixLengthFromSubnetMask()} gw4 ${message.Gbt_Eth_Gateway}`);
      console.log("Connection 'eth0' added");
    } catch (exception) {
      console.error(`Error adding connection 'eth0': ${exception.message}`);
      errors.push(exception.message);
    }
  }

  try {
    execSync("sudo systemctl restart NetworkManager")
  } catch(exception) {
    console.error(exception);
    errors.push(exception.message);
  }

  
  return errors.length === 0 ? "OK" : JSON.stringify(errors);
}

function trimColonSlash(stringToTrim) {
  if (stringToTrim) {
    const [, ipWithNetmask] = stringToTrim.split(":");
    if (ipWithNetmask) {
      const [trimmed_ip,] = ipWithNetmask.split("/");
        return trimmed_ip
    }
  }
  return ""
}

app.get('/getAssignedIPInfo', (req, res) => {
  const body = {
    gateway: "",
    netmask: "",
    ip: "",
    wlan0_ip: ""
  };

  try {
    // Get default gateway
    let gateway = ""
    const gateway1 = execSync("nmcli -t -f ipv4.gateway con show eth0 | cut -d ':' -f2").toString('utf8').trim();
    const gateway2 = execSync("nmcli -t -f IP4.GATEWAY dev show eth0 | cut -d ':' -f2").toString('utf8').trim();
    if (gateway1 !== "") {
      gateway = gateway1      
    }
    if (gateway2 !== "") {
      gateway = gateway2      
    }
    body.gateway = gateway
  } catch (exception) {
    console.log(exception);
  }

    try {
      // Get IP address and netmask for eth0
      const eth0IPOutput1 = execSync("nmcli -t -f ipv4.addresses connection show eth0").toString('utf8').trim();
      const eth0IP1 = trimColonSlash(eth0IPOutput1);
      const eth0IPOutput2 = execSync("nmcli -t -f IP4.ADDRESS dev show eth0").toString('utf8').trim();
      const eth0IP2 = trimColonSlash(eth0IPOutput2);
      let eth0ip = ""
      let eth0IPOutput = ""
      if (eth0IP1 !== "") {
        eth0ip = eth0IPOutput1
        eth0IPOutput = eth0IPOutput1
      } 
      if (eth0IP2 !== "") {
        eth0ip = eth0IPOutput2
        eth0IPOutput = eth0IPOutput2
      } 




      if (eth0IPOutput) {
        const [, ipWithNetmask] = eth0IPOutput.split(":");
        const [trimmed_ip, netmask_bits] = ipWithNetmask.split("/");
        body.ip = trimmed_ip;
        body.netmask = ipaddr.IPv4.subnetMaskFromPrefixLength(parseInt(netmask_bits)).toNormalizedString();
      } else {
        console.log("No IP address found for eth0");
      }
    } catch (exception) {
      console.log(exception);
    }

  try {
    // Get IP address for wlan0
    const wlan0IPOutput1 = execSync("nmcli -t -f ipv4.addresses connection show wlan0").toString('utf8').trim();
    const wlan0IP1 = trimColonSlash(wlan0IPOutput1);
    const wlan0IPOutput2 = execSync("nmcli -t -f IP4.ADDRESS dev show wlan0").toString('utf8').trim();
    const wlan0IP2 = trimColonSlash(wlan0IPOutput2);
    let wlan0IPOutput = ""
    let wlan0ip = ""

    if (wlan0IP1 !== "") {
      wlan0ip = wlan0IPOutput1
      wlan0IPOutput = wlan0IPOutput1
    } 
    if (wlan0IP2 !== "") {
      wlan0ip = wlan0IPOutput2
      wlan0IPOutput = wlan0IPOutput2
    } 


    if (wlan0IPOutput) {
      const [, wlan0IPWithNetmask] = wlan0IPOutput.split(":");
      const [wlan0TrimmedIP] = wlan0IPWithNetmask.split("/");
      body.wlan0_ip = wlan0TrimmedIP; 
    } else {
      console.log("No IP address found for wlan0");
    }
  } catch(exception){
    console.log("exception in get IP address for wlan0");
    console.log(exception);   
  }

  res.send(body);
});

const findProperty = (text, property, hasEquals = true) => {
  const lines = text.split('\n');
  let startLine = ""
  lines.some((line) => {
    const trimmed = line.trim();
    const startIndex = hasEquals ? Math.max(trimmed.indexOf(`${property}=`), trimmed.indexOf(`${property} =`))
      : trimmed.indexOf(property);
    if(startIndex === 0){
      startLine = trimmed;
      return true;
    }
    return false;
  })
  if(startLine === ""){
    return undefined;
  }
  // const startLine = text.slice(startIndex);
  const breakIndex = startLine.indexOf(hasEquals ? '=' : ' ');
  if(breakIndex === -1){
    return undefined;
  }
  const value = startLine.slice(hasEquals ? breakIndex + 1 : breakIndex);
  return value;
}

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, '/home/altronic/uploads')
  },
  filename: function (req, file, cb) {
    cb(null, file.  originalname)
  }
})

const upload = multer({ storage: storage })

app.post('/updateLogicModule', upload.single('logicModulePackage'), (req, res) => {
  const file = req.file;
  const filePath = path.resolve('home/altronic/uploads', file.originalname);
  if (!file) {
    console.error('No update file selected');
    res.status(400).status({ message: 'No update file selected', status: 'error' });
    return;
  }
  console.log(`Selected update file: ${file.originalname}`);

  // Verify that the file is a .deb file
  if (file.originalname.split('.').pop() !== 'deb') {
    console.error('Invalid file type. Please select a .deb file.');
    res.status(400).json({ message: 'Invalid file type. Please select a .deb file.', status: 'error' });
    return;
  }

  // Install the package
  try {
    console.log(`Running 'sudo /home/altronic/updateLogicModule.sh ${filePath}'`);
    execSync(`sudo /home/altronic/updateLogicModule.sh ${filePath}`);
    // console.log('Removing old package...');
    // execSync(`sudo apt-get purge -y iris-go`);
    // console.log('Installing new package...');
    // execSync(`sudo dpkg -i ${filePath}`);
    // execSync(`sudo apt-get install -f -y`);
    console.log('Package installed successfully, rebooting...');
    res.status(200).json({ message: 'Package installed successfully', status: 'success' });
    // Wait 5 seconds before restarting the device
    setTimeout(() => {
      execSync('sudo reboot');
    }, 5000);
  } catch (error) {
    console.error('Error installing package', error);
    res.status(500).json({ message: 'Error installing package', status: 'error' });
  }
});

app.post('/updateCIU', upload.single('ciuFirmware'), (req, res) => {
  const file = req.file;
  const filePath = path.resolve('/home/altronic/uploads', file.originalname);
  if (!file) {
    console.error('No update file selected');
    res.status(400).status({ message: 'No update file selected', status: 'error' });
    return;
  }
  console.log(`Selected update file: ${file.originalname}`);

  // Verify that the file is a .ciu file
  if (file.originalname.split('.').pop() !== 'ciu') {
    console.error('Invalid file type. Please select a .ciu file.');
    res.status(400).json({ message: 'Invalid file type. Please select a .ciu file.', status: 'error' });
    return;
  }

  try {
    console.log('Starting CIU update...');
    execSync('sudo chmod 600 /home/altronic/.ssh/id_rsa')
    execSync(`scp ${filePath} altronic@192.168.1.3:/home/altronic/CIU.bin`)
    execSync(`curl http://192.168.1.3:8080/fc/1/6/9996/1/999`)
    
    res.status(200).json({ message: 'CIU update completed successfully', status: 'success' });
  } catch (error) {
    console.error('Error updating CIU', error);
    res.status(500).json({ message: 'CIU update error', status: 'error' });
  }
}); 

app.post('/updateST', upload.single('stFirmware'), (req, res) => {
  const file = req.file;
  const filePath = path.resolve('/home/altronic/uploads', file.originalname);
  if (!file) {
    console.error('No update file selected');
    res.status(400).status({ message: 'No update file selected', status: 'error' });
    return;
  }
  console.log(`Selected update file: ${file.originalname}`);

  // Verify that the file is a .bin file
  if (file.originalname.split('.').pop() !== 'bin') {
    console.error('Invalid file type. Please select a .bin file.');
    res.status(400).json({ message: 'Invalid file type. Please select a .bin file.', status: 'error' });
    return;
  }

  try {
    console.log('Updating ST firmware...');
    execSync(`mkdir -p /home/altronic/usb1`)
    execSync(`cp ${filePath} /home/altronic/usb1/NGI-5000-CRC.bin`)
    execSync(`curl http://192.168.1.2:8080/fc/1/6/998/1/27183`)

    res.status(200).json({ message: 'CIU update completed successfully', status: 'success' });
  } catch (error) {
    console.error('Error updating ST firmware', error);
    res.status(500).json({ message: 'ST firmware update error', status: 'error' });
  }
});

app.get('/packageVersion', (req, res) => {
  try {
    const packageNames = ['iris-go', 'ngi-5000-logic'];
    let version = '';
    packageNames.some((packageName) => {
      try {
        version = execSync(`dpkg-query -W -f='${'${Version}'}\n' ${packageName}`).toString().trim();
        return version.length > 0;
      } catch (error) {
        return false;
      }
    });
    console.log(`Package version found: ${version}`);
    res.status(200).json({ version });
  } catch (error) {
    console.error('Error getting package version', error);
    res.status(500).json({ message: 'Error getting package version', status: 'error' });
  }
});


// Added sending DCPM file 6-6-25
app.post('/updateDCPM', upload.single('dcpmFirmware'), (req, res) => {
  const file = req.file;
  const filePath = path.resolve('/home/altronic/uploads', file.originalname);
  if (!file) {
    console.error('No update file selected');
    res.status(400).status({ message: 'No update file selected', status: 'error' });
    return;
  }
  console.log(`Selected update file: ${file.originalname}`);

  // Verify that the file is a .dcpm file
  if (file.originalname.split('.').pop() !== 'bin') {
    console.error('Invalid file type. Please select a dcpm file.');
    res.status(400).json({ message: 'Invalid file type. Please select a dcpm file.', status: 'error' });
    return;
  }

  try {
    console.log('Starting DCPM update...');
    execSync('sudo chmod 600 /home/altronic/.ssh/id_rsa')
    console.log('After sudo chmod 600...');
    execSync(`scp -i /home/altronic/.ssh/id_rsa ${filePath} altronic@192.168.1.3:/home/altronic/DCPM.bin`)
    console.log('After sudo chmod scp...');
    execSync(`curl http://192.168.1.3:8080/fc/1/6/9995/1/999`)
    console.log('After curl...');
    res.status(200).json({ message: 'DCPM update completed successfully', status: 'success' });
  } catch (error) {
    console.error('Error updating DCPM', error);
    res.status(500).json({ message: 'DCPM update error', status: 'error' });
  }
}); 